# @agent-relay-engine/chat-server

엔진을 [채팅 프로토콜](../chat-client/PROTOCOL.md)(HTTP + SSE)에 붙이는 프레임워크 중립 핸들러. `<agent-relay-engine-chat>`·`@agent-relay-engine/chat-client` 가 그대로 붙는다. 의존성은 `@agent-relay-engine/core` 하나이고 HTTP 쪽은 `node:http` 타입만 쓴다.

## 가장 짧은 예제

```ts check
import { createServer } from 'node:http';
import { createEnginePool, createSideChannel, MemorySideStore } from '@agent-relay-engine/core';
import { createClaudeEngine } from '@agent-relay-engine/claude';
import { createChatHandler } from '@agent-relay-engine/chat-server';

const side = createSideChannel(new MemorySideStore(), 'app');
const pool = createEnginePool(createClaudeEngine({ cwd: process.cwd(), namespace: 'app' }, { side }), { maxProcesses: 2 });
const chat = createChatHandler({ pool, side, prefix: '/api' });
createServer(async (req, res) => {
  if (await chat(req, res)) return; // 처리했으면 true
  res.writeHead(404).end();
}).listen(3000);
```

## 개념

### 핸들러

돌려받는 함수에는 다음이 붙어 있다.

- `close()` — SSE 연결을 끝내고 ping 을 멈춘다. 그 뒤 요청은 503. 엔진·풀은 소비자 것이라 닫지 않는다.
- `poolQueued(ev)` — 풀의 `onQueued` 에 이어 준다(풀이 핸들러보다 먼저 만들어지므로): `createEnginePool(engine, { …, onQueued: (ev) => chat.poolQueued(ev) })`. 이어 주지 않으면 화면에 "풀 대기" 표시만 없다.
- `flush()` — [`history`](#대화-기록-저장소-history) 로 쓰는 중인 저장과 밀린 저장이 모두 끝날 때까지 기다리고, 저장이 실패한 채 남은 세션은 한 번 더 쓴다. 시간 제한은 없다([닫기 순서](#닫기-순서)). `history` 가 없으면 바로 끝난다.
- `send(opts)` — 서버 코드가 HTTP 요청 없이 턴을 연다. [서버 코드가 여는 턴](#서버-코드가-여는-턴-send)에 있다.
- `disconnect({params})` — 그 범위의 열린 SSE 를 모두 끊고 끊은 수를 돌려준다. [권한이 바뀔 때](#권한이-바뀔-때-disconnect)에 있다.
- `bootId`, `prefix`, `scopeOf(sessionId)`(메모리의 `{params, context}`).

접두어 밖의 경로, 접두어 안이라도 모르는 경로·메서드는 `false` 를 돌려 다음 미들웨어로 넘긴다. 접두어는 정규화하지 않은 원시 경로(`req.url` 의 `?` 앞)로 맞추고, `.`·`..` 조각(인코딩 포함)·역슬래시·`//` 로 시작하는 경로는 맞지 않는 것으로 본다 — 앞단 라우터가 본 `:projectId` 와 다른 범위로 들어가지 않게. Host·Origin 검사는 하지 않는다 — 루프백 서버라면 `rejectForeign(req.headers.host, req.headers.origin, boundHost)` 를 먼저 부른다(프록시 뒤라면 자기 규칙으로). POST 는 `content-type: application/json` 만 받는다(CORS preflight 강제).

### `:param` 접두어와 범위

접두어 패턴과 파라미터 값의 조합 하나가 **범위**다(같은 `:projectId` 라도 `/…/:projectId/a` 와 `/…/:projectId/b` 는 다른 범위). 범위마다 세션 목록, 이벤트 길(SSE 링·번호), 세션 소유가 나뉜다. `hello.bootId` 는 핸들러 하나에 하나라 범위를 바꿔도 재시작으로 보이지 않고, 이벤트 id 는 범위마다 달라 다른 범위의 `last` 로는 replay 되지 않는다(`replayed:false`). 세션이 없는 범위의 링은 구독이 끝나면 버린다.


**`:param` 값의 디코드 규칙**(1.8.0 문서화, 코드는 `src/prefix.ts`). 접두어는 정규화하지 않은 원시 경로로 맞추고, 각 `:param` 조각은 이렇게 다룬다.

- `decodeURIComponent` 로 디코드한 값이 범위 key 와 모든 훅(`authorize`·`sessionContext`·`identify` 등)의 `params` 가 된다. 그래서 `%61` 과 `a` 는 같은 범위이고 `params` 도 `{id: 'a'}` 로 같다.
- 디코드에 실패하는 조각(`%E0%A4%A` 같은 잘못된 인코딩)은 받지 않는다. 디코드한 값이 빈 문자열이거나 `.`·`..` 이거나 `\` 를 품거나 `/` 를 품어도 받지 않는다(맞지 않는 경로라 다음 미들웨어로 넘어간다).
- `%2F` 는 값 안의 `/` 로 디코드되므로 그 조각도 받지 않는다. 범위 이름이 경로를 가로지르지 못하게 하려는 것이다.
- **대소문자·유니코드 정규화는 그대로다.** `Abc` 와 `abc`, 합친 `é`(U+00E9)와 `e`+결합 악센트(U+0065 U+0301)는 다른 범위가 된다. 정규형만 받으려면 `authorize` 에서 거른다(예: `if (params.projectId !== canonical(params.projectId)) throw new HttpError('모르는 프로젝트', 404)`).
- 다른 범위가 가진 세션 id 로 오면 조회(`/sessions/:id/chat`·`status`)·턴(`POST /chat`)·승인·중지 모두 **404** 다. 403 이 아닌 것은 다른 프로젝트 세션의 존재도 알리지 않으려는 것이다.
- 메모리에 없는 세션 id(재기동 뒤 등)로 `POST /chat` 이 오면 세션 기록의 범위를 보고 다르면 404. 이 패키지 칸이 없는 옛 기록은 고정 접두어(파라미터 없음)의 것으로 본다. 메모리에 없는 세션의 중지·승인은 엔진에 닿지 않고 `{via:'none'}`·`{ok:false}`.
- `/metrics` 는 범위가 있는 접두어(`:param` 이 있다)면 그 범위의 값만 낸다. 응답은 `{counters, pool: {processes, sessions}}` 다.
  - `counters` 는 그 범위 세션의 이벤트만 센다. 관측 이벤트의 `sessionId` 로 이 핸들러 메모리의 세션 범위를 찾으므로, 범위를 찾지 못한 이벤트(메모리에서 내보낸 뒤 늦게 온 것 등)는 세지 않는다. 그 범위의 세션이 메모리에서 모두 사라지면 카운터는 지워질 수 있다(0부터 다시 센다).
  - `pool.sessions` 는 그 범위의 세션만, `pool.processes` 는 그 가운데 프로세스가 있는 수다.
  - 범위로 나눌 수 없는 풀 전체 값(`pool.dropped`)은 내지 않는다.
  - 한 풀을 여러 핸들러가 나눠 쓰면 세션 id 공간을 나눈다(예: 핸들러마다 다른 id 접두어). 클라이언트가 고른 세션 id 가 다른 핸들러의 세션과 같으면 그 세션의 관측 이벤트가 이 핸들러의 범위 카운터에 섞일 수 있다 — 관측 이벤트에는 세션 id 만 있다.
  - 범위가 없는 접두어는 모두 풀 전체 값이다: `{counters, pool: {processes, dropped, sessions}}`. 그 핸들러의 `sessions` 도 그 핸들러가 만든 세션만이다.
  - 풀 전체 값이 필요하면 범위가 없는 접두어의 핸들러를 따로(운영자 전용 경로에) 붙이거나 `pool.snapshot()` 을 직접 읽는다. 범위 핸들러의 `/metrics` 를 아예 내지 않으려면 `metrics: false` 를 준다([설정](#설정)).

#### `resolveSession` 과 잇기

`side` 를 주면 새 세션은 첫 턴보다 먼저 `SessionRecord.ext['chat-server'] = {scope, params, context?}` 를 남긴다. 엔진의 `resolveSession` 은 spawn 때 최신 기록을 받으므로 첫 프로세스부터 범위별 설정을 고를 수 있다.

```ts
import { createChatHandler, sessionScope, HttpError } from '@agent-relay-engine/chat-server';

const engine = createClaudeEngine({
  ...config,
  resolveSession: ({ record }) => {
    const s = sessionScope(record); // {scope, params, context} | undefined
    if (!s) return {};
    return { mcpArgs: ['--project', s.params.projectId!], cwd: projectDir(s.params.projectId!) };
  },
}, { side, spawn, onEvent: tap.push });

const chat = createChatHandler({
  pool, side,
  prefix: '/api/projects/:projectId/chat',
  authorize: async ({ params, req }) => {
    if (!(await canAccess(req, params.projectId!))) throw new HttpError('없는 프로젝트', 404);
  },
  sessionContext: ({ params }) => ({ createdFor: params.projectId }),
});
```

`side` 없이 쓰면 기록에 남지 않는다. 그때는 `chat.scopeOf(sessionId)` 로 메모리의 범위를 읽는다(재기동하면 잃는다).

메모리에 없는 세션을 열 때의 순서는 범위 확인 → `sessionContext` → 범위 기록이다. 다른 범위가 가진 id 면 `sessionContext` 를 부르지 않고 404 로 답한다. 범위 기록 때 한 번 더 확인한다.

재기동 뒤에도 훅 전에 범위를 확인하는 것은 `side` 가 있을 때만이다. `side` 없이(`history` 만) 쓰면 재기동 뒤 범위의 근거가 저장된 스냅샷뿐이라, 메모리에 없는 id 는 확인 전에 `sessionContext` 가 불릴 수 있다(스냅샷의 범위가 다르면 그 대화를 읽지 않는다). 범위 소유를 지켜야 하면 `side` 를 준다.

세션 id 는 서버가 정하게 하거나(`sessionId` 생략) 추측할 수 없는 값을 쓴다. 같은 사이드 채널의 두 핸들러에 같은 새 id 가 동시에 처음 오면 범위 기록의 읽기·쓰기가 원자적이지 않아 둘 다 통과할 수 있다(마지막 확인과 쓰기 사이). 이때는 두 요청 모두 `sessionContext` 가 불릴 수 있다.

### 권한이 바뀔 때 (`disconnect`)

`authorize` 는 SSE 를 연결할 때만 부른다. 이벤트마다 다시 확인하지 않는다. 권한을 거둔 뒤에도 이미 열린 연결은 그 범위의 이벤트를 계속 받으므로, 권한이 바뀌는 시점에 그 범위의 연결을 끊는다.

```ts
// 멤버를 프로젝트에서 뺀 뒤
const n = chat.disconnect({ params: { projectId } }); // 끊은 연결 수
```

- 범위 해석은 `send` 와 같다. `params` 가 접두어의 파라미터와 맞지 않으면 `HttpError`(400)를 던진다. 닫힌 핸들러에서는 0 이다.
- **끊는 것은 범위 key 가 정확히 같은 연결뿐이다.** `authorize` 가 표기 차이(대소문자·유니코드 정규화·앞자리 0)를 같은 프로젝트로 본다면 `/projects/Abc/…` 로 연 연결은 `disconnect({params: {projectId: 'abc'}})` 로 끊기지 않는다. `authorize` 에서 정규 표기만 받는다(예: `if (params.projectId !== canonical(params.projectId)) throw new HttpError('모르는 프로젝트', 404)`).
- **권한 원본(DB 등)을 먼저 바꾸고 그 뒤에 부른다.** `authorize` 를 기다리던 연결이 옛 권한을 읽었다면 `disconnect` 뒤에 붙을 수 있다. 원본을 먼저 바꾸면 그런 연결도 다음 재연결 때 걸러진다.
- 끊긴 클라이언트는 다시 연결하고, 그때 `authorize` 를 다시 거친다. 아직 권한이 있는 사람은 `Last-Event-ID`·`?last=` 로 놓친 이벤트를 replay 받으므로 잃는 것이 없다.
- `authorize` 가 4xx(JSON 응답)로 거부하면 브라우저 `EventSource` 는 자동 재접속을 멈춘다. `chat-client` 의 store 는 `GET /sessions` 로 상태를 확인해 401·403 이면 다시 붙지 않고 `connection:'denied'` 로 멈춘다. 그 밖의 상태(404 포함)는 간격을 늘려 다시 시도한다([재연결 규칙](../chat-client/PROTOCOL.md#재연결-170)). **권한 거부는 `HttpError(…, 401)` 이나 `403` 으로 던진다** — `HttpError` 의 기본 상태 400 은 거부로 보지 않아 클라이언트가 계속 다시 시도한다.
- SSE 는 범위 하나에 한 줄이라(클라이언트가 `sessionId` 로 거른다) 세션 단위로는 끊지 않는다. 세션 하나의 권한을 거둘 때도 그 범위 전체를 끊고, 다시 연결할 때 `authorize` 가 거르게 한다.

### 재전송 중복 판단

같은 `clientMessageId` 의 `POST /chat` 재전송이 두 번 실행되지 않게 막는다. 근거는 두 가지다. 같은 프로세스의 엔진 메모리(최근 입력 목록)와, `side` 를 준 경우 세션 기록의 `SessionRecord.ext['chat-server.sent'].sentClientMessageIds` 다. 뒤의 것은 재기동 뒤에도 남는다.

- 실행이 **시작된** 입력의 cmid 만 남긴다(`core.input` 이 나온 입력, 합쳐진 꼬리 포함). 시작 전에 실패한 입력은 남지 않으므로, 같은 cmid 로 다시 보내면 실제로 실행된다.
- 세션마다 최근 1,000개까지 남기고 오래된 것부터 버린다. 턴이 끝날 때 한 번 쓰고, 입력마다 쓰지 않는다. 메모리에 두는 세션 수는 500개까지(LRU)다. 내보낸 세션은 다음에 쓸 때 기록에서 다시 읽는다.
- 막힌 재전송은 엔진에 넘기지 않고 `202 {sessionId, queued, duplicate:'executed'}` 로 답한다. 영속 목록으로 판단한 것이므로 `executed` 다. 기록에 새 항목이 생기지 않고 SSE 에 `chat` 도 나가지 않는다(상태 `state` 만 한 번 나간다). 같은 cmid 가 이 세션에서 아직 돌거나 큐에 있으면 막지 않고 엔진의 `running`·`queued` 로 답한다.
- 사이드 채널이 없거나 읽기·쓰기가 실패해도 POST 는 막히지 않는다. 그때는 이 프로세스의 메모리 판단만 남는다.
- 이 목록은 대화 기록(`items`)과 따로다. 기록을 재기동 뒤에도 남기려면 [`history`](#대화-기록-저장소-history) 를 준다.

### 서버 코드가 여는 턴 (`send`)

서비스가 HTTP 요청 없이 정해진 지시문으로 턴을 돌릴 때 쓴다(예: 세션을 마칠 때의 정리 턴). 엔진이나 풀을 직접 부르면 그 턴은 화면 기록과 SSE 에 없고, 세션에 범위 기록도 남지 않는다. `send` 는 `POST /chat` 과 같은 길을 탄다.

```ts
const { sessionId, queued, duplicate } = await chat.send({
  params: { projectId: 'p1' },      // 접두어의 :param 값. 고정 접두어면 생략한다
  sessionId,                        // 생략하면 새 세션
  input: '오늘 대화를 요약해 노트에 저장해',   // 문자열 또는 TurnInput
  clientMessageId: `wrapup-${sessionId}`,  // 멱등 키(선택)
});
```

| 옵션 | 뜻 |
|---|---|
| `params` | 접두어의 `:param` 값. 이름이 접두어와 정확히 맞아야 하고, 값은 경로 조각과 같은 규칙(빈 값·`/`·`\\`·`.`·`..` 금지)이다. 파라미터가 없는 접두어면 생략한다 |
| `sessionId` | 생략하면 새 세션을 만든다. 모양은 `POST /chat` 과 같다(`[\w-]{1,100}`) |
| `input` | 문자열(글 한 덩이의 줄임) 또는 `TurnInput`. 빈 입력은 받지 않는다 — `POST /chat` 의 빈 본문(이어서 하기)은 `send` 로 열지 않는다 |
| `clientMessageId` | 멱등 키. `input.clientMessageId` 보다 먼저 본다 |
| `mode` | `'turn'`(기본) 또는 `'inject'`(진행 중 턴에 끼워 넣기) |
| `author` | 보낸 사람 `{id, name?}`. 서버 코드는 신뢰된 쪽이라 그대로 기록한다. `input.author` 보다 먼저 본다. 모양이 잘못되면 `HttpError` 400 |
| `allowImagePaths` | `true` 일 때만 `input` 의 이미지·문서 블록에 path 소스(`source: {type:'path', path}`)를 받는다(1.8.0). 기본은 거부 — 엔진이 그 경로의 서버 파일을 읽어 모델에 보내므로 사용자 입력에서 온 경로를 그대로 넘기면 서버의 아무 파일이나 읽힌다. 거부는 `HttpError` 400 이고 메시지에 경로를 싣지 않는다. 받아도 chat-server 의 기록·SSE 의 사람 글 칸에는 경로가 실리지 않고(엔진의 `core.input` 기록에는 `image-ref.path` 가 남고, 파일을 읽지 못한 오류의 `detail` 에도 경로가 든다) `[이미지]`·`[문서]` 로만 남는다. 문자열·base64 입력은 이 옵션과 무관하다. `POST /chat` 은 본문의 `content` 가 문자열뿐이라 path 소스를 원래 받지 않는다 |
| `toolScope` | 이 턴의 도구 범위(`TurnOptions.toolScope`, 1.8.0). 예: 다른 사람의 세션에 읽기 전용으로 질문을 넣을 때 `'read-only'`. 생략하거나 `'all'` 이면 지금과 같다. 형식이 틀리면 `HttpError` 400 이고, `side` 를 주지 않은 핸들러에서도 400 이다(답 턴이 이어받을 범위를 세션 기록에 남겨야 한다). 아래 [도구 범위](#도구-범위-toolscope) |
| `context` | 세션 기록에 남길 값(`sessionContext` 가 돌려주던 값의 자리). 이 호출이 메모리에 없는 세션을 열 때만 쓰인다 — 새 세션이면 그 값을 남기고, 세션 기록이 이미 있으면(재기동 뒤) 그 값으로 바꾼다. 생략하면 기록에 있던 값을 지킨다. 세션이 이미 메모리에 있으면 무시한다 |

- **같은 길.** 범위 해석, 세션 생성과 범위 기록, `clientMessageId` 중복 판단, 대기열과 끼워 넣기, 기록과 SSE 방송이 `POST /chat` 과 같은 코드다. 돌려주는 값도 `POST /chat` 응답과 같은 모양이다(`{sessionId, queued, duplicate?}`). 턴은 뒤에서 돌고, 결과는 기록과 SSE 로 본다.
- **화면.** 이 턴은 그 범위에 붙은 화면에 보통 턴처럼 나온다. 턴 중에 뜬 승인 카드와 ask 도 같은 범위의 화면(`POST /permission`·`POST /chat` 의 `answer`)에서 평소처럼 답한다.
- **`authorize` 와 `sessionContext` 는 부르지 않는다.** 둘 다 들어온 HTTP 요청(`req`)을 보고 판단하는 훅인데 `send` 에는 요청이 없고, 부르는 쪽이 이미 신뢰된 서버 코드다. 권한은 `send` 를 부르기 전에 서비스가 확인하고, 필요한 문맥은 `context` 로 직접 준다.
- **범위 규칙은 그대로다.** 다른 범위가 가진 `sessionId` 로 보내면 404 로 거부한다(`POST /chat` 과 같이, 메모리에 없는 세션은 `side` 의 세션 기록으로 판단한다). `send` 가 만든 세션은 그 `params` 의 범위에 기록되므로, 화면은 그 범위의 URL 로 조회·구독한다.
- **사람 글 칸.** 입력은 `POST /chat` 처럼 사람 글 칸(`kind:'user'`)으로 남는다. 화면에 다른 글로 보이게 하려면 `TurnInput.display` 를 준다(`{content: [지시문 전체], display: [{type:'text', text:'[세션 정리]'}]}`). `display: []` 면 사람 글 칸을 남기지 않는다.
- **오류.** 거부는 HTTP 경로와 같은 `HttpError` 로 던진다(`status`: 잘못된 인자 400, 다른 범위의 세션 404, `close()` 뒤 503). 그 밖의 예외(사이드 채널 실패 등)는 그대로 던진다. 턴이 시작된 뒤의 실패는 던지지 않고 기록의 `error` 항목과 SSE 로 나온다. 턴이 예외를 던지면 그 항목의 `message` 는 고정 문구 `'서버 오류'` 이고, 원래 예외는 요청이 없으므로 `onError` 대신 `process.emitWarning` 으로 남는다.

#### 도구 범위 (`toolScope`)

- **서버 코드만 정한다.** `POST /chat` 은 본문에서 정해진 칸만 골라 읽으므로 `toolScope` 같은 칸은 무시된다(모르는 칸과 같다). 브라우저 요청에는 범위가 붙지 않는다. 타입 `ToolScope` 는 `@agent-relay-engine/core` 에서 가져온다.
- **ask 의 답 턴은 같은 범위를 이어받는다.** 범위 턴이 낸 질문(ask 는 `'read-only'` 에서도 쓸 수 있다)에 답한 턴은 그 질문을 낸 턴의 범위로 돈다 — 브라우저의 `answer` 도, 서버 `send` 의 `input.answer` 도 같다. 이유: 그 입력에 숨은 프롬프트 주입이 ask 를 내고 다른 사람이 답해, 같은 맥락에서 쓰기 가능한 턴이 열리지 않게 한다. `send` 가 `answer` 와 함께 `toolScope` 를 주면 둘 중 좁은 쪽이다(넓힐 수 없다). 그 답 턴이 낸 질문도 같은 범위를 이어받는다. 끄는 옵션은 없다.
  - 질문을 낸 턴의 범위는 엔진이 실제로 쓴 범위(합치기·끼워 넣기로 좁아진 것 포함)다. 범위는 질문을 기록·방송하기 전에 사이드 채널 세션 기록(`ext['chat-server.ask-scopes']`)에 남는다. 그래서 재기동·history 복원 뒤의 답에도 붙는다. 남기지 못하면 그 질문은 화면에 내지 않고 턴을 서버 오류로 닫는다. 답할 때 세션 기록을 읽지 못하면 409 `{error: '이 질문의 도구 범위를 확인하지 못했다'}` 로 답을 받지 않는다. 범위 없이 열리는 답 턴은 없다.
  - 답 턴을 엔진이 받으면(`core.input`) 그 질문의 항목은 '답함' 묘비가 된다. 같은 질문에 다시 답하면 409 `{error: '이미 답한 질문이다'}` 다(재기동 뒤에도). 기록 모양은 `{entries: [askId, ToolScope | 'answered'][], trimmed?: true}` 이고 1.8.0 개발 중의 옛 모양(`{askId: scope}`)도 읽는다.
  - 항목은 세션당 64개(묘비 포함)까지 두고 오래된 것부터 밀어낸다. 밀어낸 적이 있는 세션(`trimmed`)에서는 범위를 알 수 없는 질문의 답도 409 `'이 질문의 도구 범위를 확인하지 못했다'` 다 — 밀려난 범위 질문을 범위 없이 열지 않게. 이 프로세스가 본 범위 없는 질문의 답은 밀어낸 적이 없는 세션에서만 세션 기록을 읽지 않는다(재기동 전까지, 역시 64개까지). 밀어낸 세션에서는 기록을 먼저 읽고, 기록에 그 질문이 없을 때만 범위 없이 연다. 기록의 `entries` 에 읽을 수 없는 원소가 있으면 밀어낸 세션(`trimmed`)으로 본다. 묘비를 기록에 쓰지 못한 질문은 프로세스가 사는 동안 상한과 상관없이 409 다(1.8.1).
  - **한계: 세션당 핸들러 하나를 전제한다.** 범위·묘비의 메모리 사본과 세션 기록 쓰기 순서는 한 핸들러 안에서만 맞춘다. 같은 세션을 여러 핸들러(프로세스)가 동시에 받으면 한쪽이 본 묘비·범위를 다른 쪽 메모리가 모를 수 있다.
  - **한계: 답 없이 일반 턴으로 넘어가면 범위가 없다.** 질문에 답하지 않고 그 세션에 보통 글을 보내면, 그 턴은 질문을 낸 턴의 범위를 이어받지 않는 범위 없는 새 턴이다(아래 항목).
  - 오류 뒤의 [이어서 하기]와 그 세션의 다음 보통 턴(`POST /chat`·범위 없는 `send`)은 범위 없는 새 턴이다. 이것도 좁혀야 하면 `authorizeAction` 으로 그 세션의 `'send'`·`'resume'` 을 막고 서버 코드가 범위를 붙여 대신 보낸다.
- **판단은 엔진이 한다.** 같은 세션의 진행 중 턴·큐와 합칠 때의 규칙(가장 좁은 범위, 넓히지 않음)은 core 의 [턴 단위 도구 범위](../core/README.md#턴-단위-도구-범위-toolscope)를 따른다. chat-server 는 값을 넓히지 않는다.
- **지킬 수 없으면 오류 항목.** 엔진이 범위를 지킬 수 없으면(capability `'turn-tool-scope'` 없음, 이미 살아 있는 프로세스가 지킬 수 없는 범위 등) 턴을 시작하지 않고 `error(config)` 로 닫는다. `send` 는 던지지 않고, 다른 턴 실패처럼 기록의 `error` 항목(`reason:'config'`)과 SSE 로 나온다. 항목에는 지금처럼 `message`·`reason`·`resumable` 만 실리고 범위 값(`detail`)은 싣지 않는다. 시작하지 못한 입력이라 같은 `clientMessageId` 로 다시 보낼 수 있다.

### 보낸 사람 (`identify`)

여러 사람이 같은 세션을 쓰는 서비스에서 사람 글이 누구의 것인지 남긴다. 신원은 **서버가 정한다** — 클라이언트가 신원을 꾸밀 수 없다.

```ts
createChatHandler({
  pool, prefix: '/api',
  identify: async ({ req, params }) => {
    const user = await sessionUser(req);           // 서비스의 인증
    return user ? { id: user.id, name: user.displayName } : undefined;
  },
});
```

- **조작 경로에서 부른다.** `POST /chat`·`POST /permission`·`POST /stop` 에서 부른다. 조회·SSE 에서는 부르지 않는다. 그 값이 [결정 권한](#결정-권한-authorizeaction) 훅의 `actor` 와 기록의 `decidedBy` 가 된다.
- **`POST /chat`.** 돌려준 값이 그 입력의 `author` 가 되어 사람 글 항목(`kind:'user'`)의 `author?`·`authors?`(합쳐진 입력이면 전부, 입력 순서·id 중복 없음)로 기록되고, SSE `chat` 과 `GET /sessions/:id/chat`, `history` 스냅샷에 그대로 남는다. 엔진의 턴 문맥 `requesters` 에도 실린다(core README).
- **본문의 `author` 는 읽지 않는다.** 클라이언트가 보낸 `author`·`authors` 칸은 무시한다. `identify` 가 없으면 author 를 싣지 않는다(지금과 같다).
- **실패.** `HttpError` 를 던지면 그 상태로 거부한다(세션도 만들지 않는다). 다른 예외와 `{id: 비어 있지 않은 문자열, name?: 문자열}` 이 아닌 반환값은 500 이다(본문은 고정 문구 `{error: '서버 오류'}`, 원래 예외는 `onError` 로 받는다 — 토큰 파싱·인증 저장소의 오류 메시지가 응답에 나가지 않는다) — `authorize` 와 같은 원칙이다. 훅이 `undefined` 를 주면 그 요청은 author 없이 진행한다.
- **`handler.send`.** 서버 코드는 신뢰된 쪽이라 `identify` 를 부르지 않고 `author` 옵션을 그대로 기록한다.
- CLI 에 `[이름]` 접두어를 붙이려면 엔진 설정 `inputAuthorFormat` 을 준다(core README).

### 결정 권한 (`authorizeAction`)

여러 사람이 같은 세션을 쓸 때 누가 턴을 열고, 끼워 넣고, 멈추고, 승인하고, ask 에 답할 수 있는지 정한다. **정책은 소비자가 정한다** — 엔진과 이 패키지는 훅이 허용한 결정만 받는다.

`action` 은 클라이언트가 고른 모양이 아니라 **실제로 일어날 효과**로 정한다. 본문 모양을 바꿔 더 약한 분류로 빠질 수 없다.

| `action` | 경로 | `requestId` | `requesters` |
|---|---|---|---|
| `'send'` | `POST /chat`(새 턴. 돌거나 기다리는 턴이 없을 때의 `mode:'inject'` 도 새 턴이라 여기다) | 없음 | 없음 |
| `'inject'` | `POST /chat`(`mode:'inject'`, 이 세션에 돌거나 기다리는 턴이 있다) | 없음 | 없음 |
| `'resume'` | `POST /chat`(내용이 빈 [이어서 하기]. `mode` 를 버리고 새 턴을 연다 — 도는 턴에 끼워 넣지 않는다) | 없음 | 없음 |
| `'ask-answer'` | `POST /chat`(`answer` 가 있다) | `askId` | 그 질문을 낸 턴의 요청자 |
| `'permission'` | `POST /permission`(ctx 에 `decision: 'allow'\|'deny'` 와 `remember?` 가 더 실린다) | 승인 요청 id | 그 승인을 낸 턴의 요청자 |
| `'stop'` | `POST /stop` | 없음 | 없음 |

- **모양.** `(ctx: {action, sessionId, params, actor?, requestId?, requesters?, req}) => void | Promise<void>`. `actor` 는 `identify` 결과다(없으면 칸이 없다). `sessionId` 는 본문의 id 이고, `POST /chat` 이 id 없이 오면 서버가 새로 지은 id 다(응답의 `sessionId` 와 같다).
- **`resume` 은 `send` 와 같은 권한으로.** 이어서 하기는 새 턴을 시작한다(모델이 일을 이어 간다).
- **`inject` 는 새 턴이 되지 않는다.** 분류는 엔진에 넘기기 직전의 서버 상태로 한다. 훅이 `'inject'` 로 허가한 입력은 엔진에 턴별 `injectFallback: 'reject'` 로 넘긴다 — 그 사이 턴이 끝났거나(중지 직후 등) 백엔드가 끼워 넣지 못하면 엔진이 새 턴으로 열지 않고 거절하고, 서버는 409 `{error: '끼워 넣을 턴이 없다 — send 로 보내라'}` 로 답한다(기록·SSE 에 남지 않는다). 클라이언트는 보통 턴으로 다시 보낸다. 서버는 이 거절을 1초까지 기다리고, 그 뒤 엔진이 늦게 거절하면 보통 오류 항목으로 남는다.
  - **Claude.** Claude 는 끼워 넣기가 턴 안에서 실행될지 보장할 수 없어(CLI 가 다음 턴으로 미룰 수 있다), 권한을 inject 로만 준 경우 끼워 넣기를 거절한다 — 그 프로세스에서 끼워 넣기를 실측하기까지 대부분 409 다. send 로 보내라. Codex 는 steer 가 턴 안에서만 들어가 영향이 없다. 훅이 없으면 지금처럼 엔진 정책(`QueuePolicy.injectFallback`)대로다.
- **같은 질문의 답은 한 번.** 같은 `askId` 의 답이 처리 중이면(접수 ~ 엔진이 받을 때) 다음 답은 409 다. 엔진도 이미 답을 기록한 질문의 답을 `error(ask-mismatch)` 로 거절한다. 그래서 답 턴이 시작된 뒤 실패하면(프로세스 종료 등) 같은 질문에 다시 답할 수 없다 — 모델이 다시 묻게 한다(보통 글이나 [이어서 하기]로).
- **`answer` 의 모양.** `answer` 는 `mode:'inject'` 와 함께 쓸 수 없고 `content` 와 함께 보낼 수 없다(둘 다 400, 훅 전). 답은 엔진의 질문 확인을 거치는 새 턴으로만 간다. 엔진도 도는 턴에 끼워 넣는 답을 `error(input)` 으로 거절한다.
- **ask 답의 기록 확인.** 훅이 있으면 답을 훅보다 먼저 서버 기록으로 거른다: 그 세션 기록에 없는 `askId` 는 404, 이미 답한 질문(ask 항목에 `decidedBy` 가 있다)은 409 다. 같은 `askId` 의 항목이 여럿이면 답한 사람이 없는 항목을 본다. 훅이 없으면 지금처럼 엔진이 판단한다.
- **`permission` 의 `decision`·`remember`.** "거부는 누구나, 허용과 규칙 저장(`remember`, 같은 도구의 다음 요청까지 연다)은 리드만" 같은 정책을 쓴다.
- **`requesters`.** 엔진의 `permission`·`ask` 이벤트에 실린 그 턴의 요청자(author id 들, core README)를 기록 항목에서 찾아 준다. 기록에 없는 요청(모르는 id, 요청자 없는 턴)이면 칸이 없다.
- **`requesters` 가 없을 때.** 요청자 없는 턴(identify 없이 연 턴), 모르는 id, 다른 범위의 세션이 모두 칸 없음으로 온다. "누구나 결정해도 된다"로 읽지 말고 정책에 맞게 판단한다(예: 리드만).
- **ask 권한은 `send` 와 함께.** 모델은 `answer` 없는 보통 글도 답으로 읽는다. 질문에 답할 사람을 제한하려면 질문이 열린 동안의 `send`·`inject` 도 같은 정책으로 막는다.
- **순서.** `authorize` 를 통과하고 본문 검사·`identify` 뒤, 엔진에 넘기기 전에 부른다.
- **거부.** `HttpError` 를 던지면 그 상태로 답하고 엔진에 넘기지 않는다. 거부된 승인 답은 카드를 그대로 열어 둔다 — 다른 사람이 답할 수 있다. 거부된 `POST /chat` 은 세션을 만들지 않는다. 다른 예외는 500 이다(고정 문구 `{error: '서버 오류'}`, 원래 예외는 `onError`).
- **생략하면** 지금처럼 모두 허용한다. `handler.send` 에서는 부르지 않는다(서버 코드는 신뢰된 쪽이다).
- **결정 콜백(`onPermissionDecided`).** 엔진이 승인 요청 하나의 답을 백엔드에 보낼 때(`core.permission_decided`, core README) 한 번 `{sessionId, requestId, toolName, behavior, via, at, decidedBy?}` 로 부른다. `decidedBy` 는 `via` 가 `'human'` 이고 `POST /permission` 의 `identify` 가 신원을 정했을 때만 있다. 거부된 답은 엔진에 가지 않으므로 콜백도 없고, 다음에 받아들여진 답의 사람이 `decidedBy` 가 된다. 콜백이 던지거나 거부해도 기록·SSE·턴은 계속되고 `process.emitWarning` 으로 남는다. payload 모양이 틀린 이벤트(모르는 `via` 등)는 콜백을 부르지 않고 경고만 남긴다. `decidedBy` 는 사본이다. 브라우저로 가는 이벤트는 바뀌지 않는다.
- **`decidedBy` 의 대조(1.8.1).** 서버는 `POST /permission` 이 신원 있는 답을 엔진에 넘길 때마다 그 답의 토큰(사람·`allow`·`deny`)을 적고, `engine.answerPermission` 이 `true`(엔진이 이 답을 받았다)를 돌려준 토큰의 사람만 `decidedBy` 로 붙인다. 엔진이 낸 결정의 `behavior` 가 그 답과 달라도 붙이지 않는다. 같은 요청에 익명 답과 신원 있는 답이 동시에 오면, 익명 답이 받아들여졌을 때 `decidedBy` 가 없다. 받아들여진 토큰이 둘 이상이면(한 요청에 `true` 를 둘 돌려주는 엔진) 누구로도 귀속하지 않는다. `core.permission_decided` 가 그 답들의 `answerPermission` 이 끝나기 전에 오면 콜백은 끝난 뒤에 부른다 — 그래서 콜백이 다른 이벤트보다 늦게 올 수 있다. `answerPermission` 이 기다림(await)을 거쳐 승인 대기표에 닿는 엔진(감싼 엔진 포함)에서도 맞다. 1.8.0 은 먼저 적은 사람을 받아들여진 답으로 보아, 같은 `behavior` 의 익명 답이 이기면 신원 있는 사람을 잘못 붙일 수 있었다.
- **기록(`decidedBy`).** 승인 결말(`outcome`, `allow`·`deny`·`preapproved`)과 ask 항목에 결정한 사람(`identify` 결과)을 `decidedBy` 로 남긴다. 감사용이다. 승인은 SSE `permission-settled` 의 `outcome` 에, ask 는 답 글(`kind:'user'`)의 `answer: {askId, decidedBy?}` 로 SSE `chat` 에 실리고, `GET /sessions/:id/chat`·`history` 스냅샷의 ask 항목에도 남는다. ask 항목의 `decidedBy` 는 엔진이 답 입력을 받은 뒤 `core.input` 의 `answer`(실제로 쓰인 답과 그 입력의 보낸 사람, 합쳐진 턴이면 마지막 입력)로 적고, 처음 적은 값을 덮어쓰지 않는다. `identify` 가 없으면 칸이 없다.

요청자 본인만 승인·답하게 하는 예:

```ts
createChatHandler({
  pool, prefix: '/api', identify,
  authorizeAction: ({ action, actor, requesters }) => {
    if (action !== 'permission' && action !== 'ask-answer') return;
    // 요청자를 모르면 막는다(fail closed)
    if (!requesters?.includes(actor?.id ?? '')) throw new HttpError('요청한 사람만 결정할 수 있다', 403);
  },
});
```

역할로 정하는 예(리드만 중지·승인):

```ts
createChatHandler({
  pool, prefix: '/api/projects/:projectId', identify,
  authorizeAction: async ({ action, actor, params }) => {
    if (action !== 'stop' && action !== 'permission') return;
    const role = actor && (await roleOf(params.projectId!, actor.id)); // 서비스의 권한 저장소
    if (role !== 'lead') throw new HttpError('리드만 할 수 있다', 403);
  },
});
```

### 대화 기록 저장소 (`history`)

기본으로 대화 기록(`items`)은 메모리에만 있다. 재기동하면 열려 있던 화면이 빈 대화가 된다. `history` 를 주면 기록의 스냅샷을 소비자 저장소에 남기고, 메모리에 없는 세션을 처음 쓸 때 다시 읽는다.

```ts
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { ChatHistory, StoredChat } from '@agent-relay-engine/chat-server';

const dirOf = (params: Readonly<Record<string, string>>) => join(root, encodeURIComponent(JSON.stringify(params)));
const read = async (file: string) => JSON.parse(await readFile(file, 'utf8')) as StoredChat;

const history: ChatHistory = {
  async load({ sessionId, params }) {
    return read(join(dirOf(params), `${sessionId}.json`)).catch((err) => {
      if (err.code === 'ENOENT') return undefined; // 저장된 것이 없다
      throw err;
    });
  },
  async save({ sessionId, params }, chat) {
    await mkdir(dirOf(params), { recursive: true });
    await writeFile(join(dirOf(params), `${sessionId}.json`), JSON.stringify(chat));
  },
  // 선택: 재기동 뒤 GET /sessions 에 옛 대화를 낸다
  async list({ params }) {
    const files = await readdir(dirOf(params)).catch(() => []);
    return Promise.all(files.map(async (f) => {
      const { title, createdAt, updatedAt } = await read(join(dirOf(params), f));
      return { sessionId: f.replace(/\.json$/, ''), title, createdAt, updatedAt };
    }));
  },
};

const chat = createChatHandler({ pool, side, prefix: '/api/projects/:projectId/chat', history });
```

`StoredChat` 은 `{title, createdAt, updatedAt, items, scope}` 이고, `items` 는 `GET /sessions/:id/chat` 의 `items` 와 같다. 훅은 `{sessionId, params}` 를 받는다 — 저장소는 둘을 함께 키로 쓴다.

`scope` 는 그 대화를 가진 범위의 key(접두어 패턴 + 파라미터 값)다. 스냅샷을 통째로 저장하고 그대로 돌려주면 된다. `load` 가 돌려준 `scope` 가 요청의 범위와 다르면 서버는 그 대화를 읽지 않는다(아래). `scope` 칸이 없는 값은 견주지 않는다. 접두어 패턴을 바꾸면 key 가 달라지므로, 그때는 저장된 `scope` 를 지우거나 새 값으로 옮긴다.

**`save` 를 부르는 때.** 기록의 칸은 제자리에서 바뀐다(승인 결말 등). 그래서 덧붙이기가 아니라 그 시점의 **전체 스냅샷**을 넘긴다.

- 턴이 끝날 때(정상·오류·중지 모두) 한 번.
- 승인 카드나 ask 카드가 생길 때, 승인 카드의 결말이 정해질 때. 턴이 사람을 기다리며 멈추는 자리라, 그 사이 재기동해도 카드까지의 기록이 남는다.
- 스트리밍 조각, 글·도구 항목마다는 부르지 않는다. 턴 중간에 저장된 스냅샷에는 그때까지 끝난 칸만 있다(조각으로 오는 중인 글은 기록의 칸이 아니다).
- 디바운스 타이머는 없다. 부르는 자리가 위의 확정 시점뿐이라 턴마다 몇 번이고, 한 세션의 저장은 한 번에 하나만 돈다. 쓰는 동안 온 저장 요청은 하나로 합쳐 끝난 뒤 최신 스냅샷으로 다시 쓴다.
- 넘긴 스냅샷은 그 뒤 바뀌지 않는다(칸마다 얕게 베낀 것이다).

**`save` 는 더 새 스냅샷만 덮어쓰게 짜기를 권한다.** 같은 세션의 저장은 한 번에 하나지만, [메모리 축출](#메모리-축출)로 내보낸 세션의 남은 쓰기는 되살린 세션이 5초까지만 기다린다. 그보다 늦게 끝난 옛 `save` 는 더 새 `save` 뒤에 저장소에 커밋될 수 있다. 서버는 그 뒤 최신 스냅샷을 다시 쓰지만, 그 세션이 `maxSessions` 상한으로 다시 내보내졌으면 다시 쓰지 못해 저장소가 옛 기록으로 남는다. 이를 막으려면 저장소에서 비교해 쓴다.

- 기준은 **마지막 항목의 `seq`**(`chat.items.at(-1)?.seq`, 빈 기록은 0)다. 항목이 붙을 때마다 커지고, 늦게 읽은 기록과 합칠 때도 뒤로만 밀린다. 스냅샷에 따로 버전 칸은 없다. `updatedAt` 은 항목이 붙을 때(와 저장된 기록을 읽어 합칠 때)만 바뀌고 칸만 고치는 확정에서는 그대로라 기준으로 쓰지 않는다.
- 저장된 값의 그 `seq` 보다 **크거나 같을 때만** 덮어쓴다. 같을 때도 쓰는 것은 승인 결말처럼 항목을 붙이지 않고 그 자리의 칸만 고치는 확정이 있어서다. 그래서 마지막 `seq` 가 같은 두 스냅샷의 순서는 이 기준으로 가리지 못한다.
- 저장된 기록을 읽지 못한 채 턴을 받은 세션은 빈 기록에서 시작해 `seq` 가 작다. 서버는 그런 세션을 `save` 하지 않으므로 이 조건과 부딪히지 않는다.
  - 남은 쓰기를 기다리다 상한을 넘긴 세션은 그 쓰기가 끝나면 다시 읽어 합친다. 그러면 `seq` 가 저장된 기록 뒤로 이어지고, 그때부터 저장한다.
  - `load` 가 실패했거나 남의 대화(`scope` 가 다르다)인 세션은 그 세션이 메모리에 있는 동안 저장하지 않는다(아래 "훅이 던질 때" 와 같다).
- 비교와 쓰기는 한 번에 한다(트랜잭션, 조건부 갱신 등). 따로 읽고 쓰면 그 사이 다른 쓰기가 끼어든다.
- 저장된 본문을 바깥에서 고쳤으면(항목을 지우는 등) 함께 저장한 기준 값도 맞춘다. 서버는 읽은 기록의 `seq` 가 늘어나는 순서가 아니면 1부터 다시 매기므로, 기준 값만 크게 남으면 그 뒤의 `save` 가 계속 버려진다.

```ts
// 예: SQL 저장소. last_seq 칸에 마지막 항목의 seq 를 함께 저장한다
const lastSeq = chat.items.at(-1)?.seq ?? 0;
await db.query(
  `INSERT INTO chats (params, session_id, last_seq, body) VALUES ($1, $2, $3, $4)
   ON CONFLICT (params, session_id) DO UPDATE SET last_seq = $3, body = $4 WHERE chats.last_seq <= $3`,
  [JSON.stringify(params), sessionId, lastSeq, JSON.stringify(chat)],
);
```

**`load` 를 부르는 때.** 메모리에 없는 세션을 처음 쓸 때 한 번이다.

- 조회(`GET /sessions/:id/chat`·`status`)와 턴(`POST /chat`·`send`)이 메모리에 없는 세션 id 로 올 때. SSE(`GET /events`)는 범위 하나의 길이라 세션 id 가 없으므로 읽지 않는다.
- **범위 검사는 세션 기록(`side`)을 따른다.** 세션 기록의 범위가 요청의 범위와 같을 때만 `load` 를 부른다. 다른 범위면 지금처럼 404 이고 훅은 불리지 않는다.
- 세션 기록이 없는데 저장소에만 있는 대화(`side` 없이 쓰는 경우 포함)는 **조회로는 되살리지 않는다**(404 — 범위를 확인할 기록이 없다). 조회로 되살리려면 `side` 가 필요하고, 그 저장소는 `history` 만큼 오래 남아야 한다.
- `sessionId` 를 준 턴(`POST /chat`·`send`)은 세션 기록이 없어도 범위 기록을 통과한 뒤 `load` 를 부르고, 있으면 그 뒤에 이어 붙인다. 읽지 않고 돌리면 턴 끝의 `save` 가 저장소의 대화를 덮어쓰기 때문이다.
- **저장소는 `params` 와 `sessionId` 를 함께 키로 쓴다.** `sessionId` 만 키로 쓰면 다른 범위가 같은 id 로 왔을 때 남의 대화를 돌려주게 된다. 서버는 스냅샷의 `scope` 로 이것을 막는다 — 요청의 범위와 다르면 조회는 404 이고, 턴은 빈 기록으로 돌되 그 세션은 `save` 하지 않는다. `onError` 는 범위와 id 마다 처음 한 번만 부르고, 조회는 아래의 없는 세션처럼 잠깐 기억해 매번 다시 읽지 않는다. `scope` 칸을 버리고 저장하면 이 검사는 없다.
- 되살리지 못한 조회(세션 기록이 없거나 다른 범위 것, 저장된 대화 없음)는 범위와 id 별로 5초 동안 기억한다. 화면이 없는 세션을 폴링해도 매번 세션 기록과 저장소를 읽지 않는다. 그 id 로 이 핸들러에 세션이 생기면 바로 잊는다. 같은 `side`·저장소를 쓰는 다른 프로세스가 만든 대화는 그만큼 늦게 보일 수 있다. `load` 가 던진 경우는 기억하지 않는다.
- 조회로 되살릴 때 세션 기록 읽기(`side`)가 던지면 `onError`(`op:'load'`)로 알리고 404 로 답한다.
- 서버가 지은 새 세션 id(`sessionId` 생략)는 읽지 않는다.
- 읽은 `items` 뒤에 새 항목이 이어 붙는다(`seq` 는 마지막 항목 다음부터).
- 답을 기다리던 승인 카드는 `outcome: {behavior:'closed'}` 로 닫는다 — 그 요청을 들고 있던 턴은 재기동으로 사라졌다. 사유(`reason`)는 붙이지 않는다. 그래서 재기동 전의 오래된 카드에 늦게 허용으로 답해도 사전 승인으로 남지 않는다(`{ok:false}`).
- 기록이 그 열린 카드로 끝났으면 턴 도중에 끊긴 것이므로 `{kind:'interrupted', via:'signal'}` 항목을 하나 덧붙여 끊김을 보인다. 덧붙인 항목은 다음 `save` 에 들어가 다시 붙지 않는다. 시간 초과·사전 승인·규칙 항목이나 이미 답한 카드로 끝난 기록에는 붙이지 않는다.
- 모양이 잘못된 항목(`kind` 가 문자열이 아님, `seq`·`at` 이 숫자가 아님, `user`·`text` 항목의 `text` 가 문자열이 아님)은 버리고 `onError` 로 알린다.
- 재기동 뒤 조회(GET)가 먼저 와서 되살린 세션은 그 뒤의 `POST /chat` 에서도 `sessionContext` 를 다시 부르지 않는다. 세션 기록의 `context` 를 쓴다. 턴이 먼저 오면 지금처럼 세션을 열 때 한 번 부른다.
- 되살린 세션도 다른 세션처럼 메모리에 계속 남는다. 오래 쓰지 않은 세션을 내보내려면 [메모리 축출](#메모리-축출)을 켠다.
- 되살린 ask 카드에는 시간 제한(TTL)이 없다. 재기동·축출 뒤에도 답할 수 있고, 답은 새 턴으로 돈다(질문을 낸 턴은 이미 없다). 답의 범위·묘비 검사는 [위](#도구-범위-toolscope)와 같고, 답이 그 질문에 맞는지는 엔진의 `recordAnswer` 가 본다.

**목록.** `GET /sessions` 는 메모리의 세션을 낸다. 재기동 뒤에는 열거나 턴을 보낸 세션만 다시 나타난다. 선택 훅 `list({params})` 를 두면 저장소의 대화(`{sessionId, title, createdAt, updatedAt}[]`)를 메모리의 세션과 합쳐 최근 것부터 낸다. 같은 id 는 메모리 쪽이 이긴다. 목록의 대화는 열 때 `load` 한다.

- `list` 구현이 `params` 로 걸러 그 범위의 대화만 돌려준다. 서버도 한 번 더 거른다 — 세션 기록의 범위가 요청의 범위와 어긋나거나 세션 기록이 없는 줄은 내지 않는다(`side` 가 없으면 저장소의 줄은 내지 않는다). 줄마다 세션 기록을 한 번 읽는다.

**훅이 던질 때.** 요청은 막지 않는다(재전송 목록의 영속과 같은 원칙). 오류는 `history.onError(err, {op, params, sessionId?})` 로 받고, 생략하면 `process.emitWarning` 으로 남는다.

- `save` 가 던지면 그 스냅샷은 버린다. 쓰는 사이 새 확정이 와 있었으면 그 스냅샷으로 한 번 더 쓰고, 아니면 다음 확정 시점에 최신 스냅샷으로 다시 쓴다. 그때까지 활동이 없어도 `flush()` 가 한 번 더 써 본다.
- `load` 가 던지거나 모양이 잘못된 값을 돌려주면: 조회는 지금처럼 404 이고 다음 조회가 다시 읽는다. 턴은 빈 기록으로 시작하고, **그 세션은 이 프로세스에서 `save` 하지 않는다** — 읽지 못한 기록을 새 기록으로 덮어쓰지 않으려는 것이다.
- `list` 가 던지면 메모리의 목록만 낸다.

#### 메모리 축출

기본으로 세션은 프로세스가 끝날 때까지 메모리에 남는다. 두 옵션 중 하나라도 주면 오래 쓰지 않은 세션을 메모리에서 내보낸다(옵트인). 내보낸 세션은 다음 조회·턴이 재기동 뒤처럼 되살린다.

- `history` 와 `side` 를 함께 준 핸들러에서만 쓴다. 아니면 `createChatHandler` 가 `TypeError` 를 던진다 — 내보낸 세션의 대화와 범위 기록을 되살릴 곳이 없다. `sessionIdleMs` 는 0보다 큰 수, `maxSessions` 는 0보다 큰 정수다.
- `sessionIdleMs`: 마지막으로 쓴 뒤(조회·턴·승인 등이 그 세션을 찾은 때. 목록·지표처럼 있는지만 보는 요청은 치지 않는다) 이만큼 지난 세션을 내보낸다. 이 값의 절반(최대 1분)마다 훑는다.
- `maxSessions`: 메모리 세션 수의 목표 상한이다. 넘으면 바로 훑어 오래 쓰지 않은 것부터 내보낸다. 최근 10초 안에 쓴 세션과 아래의 내보낼 수 없는 세션은 남으므로 잠시 넘을 수 있다. 특히 쓰는 중인 세션(`history.save` 가 끝나지 않았다)은 상한을 넘어도 내보내지 않는다 — 저장소가 오래 응답하지 않으면 그동안 그런 세션만큼 `maxSessions` 를 넘는다.
- **내보내지 않는 세션.** 도는 턴, 답을 기다리는 승인, 처리 중인 `POST /chat`·`send`·`POST /permission` 이 쥐고 있는 세션, 쓰는 중인 저장, 쓰는 중인 ask 범위 기록, 미룬 결정 콜백, 기록하지 못한 ask 묘비가 있는 세션이다.
- **저장이 실패한 세션.** 내보내기 전에 한 번 더 써 보고, 성공하면 내보낸다. 또 실패하면 남긴다. 다시 쓰기는 5초까지만 기다린다 — 넘으면 다음 세션으로 넘어가고(저장소가 멈춰도 축출이 멈추지 않는다), 그 저장은 뒤에서 계속 돈다. 끝날 때까지 그 세션은 쓰는 중이라 상한을 넘어도 내보내지 않는다. 같은 id 를 되살릴 때 `load` 와 새 기록의 첫 `save` 는 내보낸 세션의 남은 쓰기가 끝난 뒤에 돈다 — 늦게 끝난 옛 쓰기가 새 기록을 덮지 않게. 이 기다림은 5초까지다. 넘으면 `onError`(없으면 `process.emitWarning`)로 알리고 넘어간다. 조회의 `load` 는 읽지 못한 것으로 본다(위의 `load` 실패와 같다 — 404, 다음 조회가 다시 읽는다). 턴이 여는 세션은 빈 기록으로 시작해 저장하지 않다가, 옛 쓰기가 끝나면 한 번 다시 읽어 저장된 기록 뒤에 그 사이 받은 턴을 이어 붙이고(그 항목들의 `seq` 가 뒤로 밀린다 — 그래서 `reload:true` 인 `session` 이벤트를 보내고, 기본 클라이언트는 그 세션 기록을 다시 읽는다) 다시 저장한다. 다시 읽어도 실패하면 지금처럼 저장하지 않는다. 첫 `save` 는 먼저 쓴 뒤 옛 쓰기가 끝나면 최신 스냅샷을 다시 쓴다. 그 다시 쓰기를 기다리는 세션은 상한을 넘지 않는 한 내보내지 않고, 넘으면 경고 뒤 내보낸다 — 옛 쓰기가 영영 끝나지 않아도 메모리가 늘지 않게(그 옛 쓰기가 늦게 끝나면 그 세션의 마지막 기록을 덮는다). 다만 `history.save` 자체가 영영 끝나지 않으면 그 세션은 쓰는 중으로 남고 `flush()` 도 끝나지 않는다 — [닫기 순서](#닫기-순서)대로 타이머와 겨룬다. 다만 `maxSessions` 를 넘었으면 경고(`process.emitWarning`)를 남기고 내보낸다 — 그 세션의 마지막 기록은 잃는다. 저장소가 계속 실패해도 메모리가 끝없이 늘지 않게 하려는 것이다. `load` 가 실패해 저장하지 않는 세션도 같다.
- **잃는 칸.** 메모리에만 있던 칸(`usage`·`capabilities`, 이 프로세스가 본 범위 없는 질문 표시 등)은 재기동처럼 잃는다. 범위 항목과 묘비는 세션 기록에서 다시 읽으므로 되살린 뒤 답의 범위가 넓어지지 않는다.

### 프레임워크에 붙이기

의존성을 더하지 않으므로 아래는 코드 조각이다. 핸들러는 `req.url` 전체 경로로 접두어를 맞추므로 **경로를 떼지 않는 자리**(루트 미들웨어)에 붙인다.

#### Express

```ts
const chat = createChatHandler({ pool, side, prefix: '/api/projects/:projectId/chat' });
// app.use('/api', …) 처럼 경로를 붙이면 req.url 이 잘린다 — 루트에 붙인다(하위 앱이라면 req.url = req.originalUrl 로 되돌려 넘긴다)
app.use((req, res, next) => {
  chat(req, res).then((handled) => handled || next(), next);
});
```

`express.json()` 이 먼저 돌아 본문 스트림을 다 읽고 `req.body` 를 채웠으면 그것을 쓴다(스트림을 읽지 않고 `req.body = {}` 만 넣은 파서면 직접 읽는다). content-type 검사는 그대로지만, 이미 파싱된 객체의 크기 상한은 그 파서의 설정을 따른다(직접 읽을 때만 1 MiB).

#### Fastify

Fastify 는 본문을 먼저 파싱하고 응답을 스스로 관리하므로, 해당 경로에서 `reply.hijack()` 으로 원시 응답을 넘기고 파싱된 본문을 `req.raw.body` 로 건넨다.

```ts
const chat = createChatHandler({ pool, side, prefix: '/api/projects/:projectId/chat' });
fastify.all('/api/projects/:projectId/chat/*', (request, reply) => {
  reply.hijack();
  const raw = Object.assign(request.raw, { body: request.body });
  chat(raw, reply.raw)
    .then((handled) => {
      if (!handled) reply.raw.writeHead(404, { 'content-type': 'application/json' }).end('{"error":"없는 경로"}');
    })
    .catch(() => reply.raw.destroy());
});
```

Fastify 의 JSON 파서는 빈 본문(`content-type: application/json` 에 본문 없음)을 핸들러 전에 400 으로 거부한다. 클라이언트는 언제나 JSON 본문을 보내므로 보통 문제없다.

### 닫기 순서

```ts
chat.close();               // SSE 끝
server.closeAllConnections(); // node:http 라면
await new Promise((r) => server.close(r));
pool.close();
await engine.dispose();
// history 를 쓰면: 마지막 스냅샷의 저장이 끝날 때까지. flush 에는 시간 제한이 없으므로 타이머와 겨룬다
let timer: NodeJS.Timeout | undefined;
await Promise.race([chat.flush(), new Promise((r) => (timer = setTimeout(r, 5_000)))]);
clearTimeout(timer);
```

`history` 의 저장은 뒤에서 돈다. 엔진을 내리면 돌던 턴이 끝나며 마지막 스냅샷이 저장되므로, `dispose` 뒤에 `chat.flush()` 로 그 저장을 기다린 다음 프로세스를 끝낸다. `flush()` 는 `save` 가 끝날 때까지 기다리고 스스로 포기하지 않는다 — 저장소가 멈추면 종료도 멈추므로 위처럼 `Promise.race` 로 상한을 둔다. `close()` 는 저장을 기다리지 않는다.

`answerPermission` 이 끝나기를 기다리며 미뤄 둔 `onPermissionDecided` 콜백은 `close()`·`flush()` 때와, 엔진 `dispose` 로 턴이 끝나거나 턴 스트림이 깨져 끝날 때 바로 부른다(한 번만). 이때 결과를 아직 모르는 답은 빼므로 `decidedBy` 가 없을 수 있다. `flush()` 는 그 콜백이 돌려준 약속까지 기다린다 — 감사 기록을 남기는 콜백이면 종료 전에 `flush()` 를 부른다. `flush()` 는 종료 때만 부른다 — 운영 중에 부르면 아직 결과를 기다리던 콜백이 `decidedBy` 없이 불릴 수 있다.

## 공개 API

<!-- gen:api @agent-relay-engine/chat-server . -->
`@agent-relay-engine/chat-server` — 42개, 공개 API 스냅샷 1.8.5 기준.

| 종류 | 이름 |
|---|---|
| function | `compilePrefix` · `createChatHandler` · `readJson` · `rejectForeign` · `sendJson` · `sessionScope` |
| class | `EventHub` · `HttpError` |
| const | `DEFAULT_BUFFER` · `DEFAULT_PING_MS` · `MAX_BODY` · `SESSION_EXT_KEY` |
| type | `AskAnswerMark` · `AskEvent` · `AskHook` · `AuthorizeActionContext` · `AuthorizeActionHook` · `ChatAccepted` · `ChatAction` · `ChatHandler` · `ChatHandlerOptions` · `ChatHistory` · `ChatHistoryContext` · `ChatItem` · `ChatRequest` · `ChatSendOptions` · `HubOptions` · `IdentifyHook` · `PermissionDecidedHook` · `PermissionDecidedInfo` · `PermissionOutcome` · `PrefixMatch` · `PrefixMatcher` · `RuleSuggestion` · `Scope` · `ScopeParams` · `SessionContextHook` · `SseEvent` · `StoredChat` · `StoredChatSummary` · `StoredScope` · `ToolApproval` |
<!-- /gen -->

## 설정

`createChatHandler(options)`

| 옵션 | 뜻 |
|---|---|
| `pool` \| `engine` | 둘 중 하나. `pool` 이면 턴이 `pool.engine` 으로 돌고(프로세스 상한), `/metrics` 가 켜진다. `engine` 만 주면 `/metrics` 는 처리하지 않는다(false) |
| `metrics` | `boolean`, 기본 `true`. `false` 면 `pool` 을 줘도 `GET /metrics` 를 처리하지 않고 다음 미들웨어로 넘긴다(`engine` 만 줬을 때와 같다). 범위가 있는 접두어의 응답 칸은 [위](#param-접두어와-범위)를 본다 |
| `prefix` | `'/api'` 같은 고정 문자열 또는 `'/api/projects/:projectId/studio'` 같은 `:param` 패턴 |
| `side` | 엔진과 **같은** 사이드 채널. 주면 새 세션의 범위를 세션 기록에 남기고(아래), 늦게 온 허용을 사전 승인으로 남기고, 재전송 중복 판단(아래)을 재기동 뒤에도 잇는다. 범위가 둘 이상이면 꼭 준다 — 없으면 재기동 뒤 다른 범위가 옛 세션 id 로 이어받는 것을 막지 못한다 |
| `authorize` | `({params, req}) => void`. 접두어에 맞은 **모든** 요청(SSE·조회·조작)마다 라우트보다 먼저 부른다. `HttpError` 를 던지면 그 상태로 거부한다. 범위별 권한 검사는 여기나 앞단 미들웨어에서 한다. `send` 에서는 불리지 않는다 |
| `identify` | `({params, req}) => Author \| undefined \| Promise<…>`. `POST /chat`·`/permission`·`/stop` 의 사람을 정한다([보낸 사람](#보낸-사람-identify)). `send` 에서는 불리지 않는다 |
| `authorizeAction` | `({action, sessionId, params, actor?, requestId?, requesters?, req}) => void`. 조작마다 엔진에 넘기기 전에 부른다([결정 권한](#결정-권한-authorizeaction)). 생략하면 모두 허용한다. `send` 에서는 불리지 않는다 |
| `sessionContext` | `({sessionId, params, req}) => value`. 범위 확인을 통과한 새 세션에만, 한 번(다른 범위가 가진 id 면 부르지 않고 404). 권한 검사 자리가 아니다 — 조회·SSE 에서는 불리지 않는다. 값은 세션 기록에 남는다. `HttpError` 를 던지면 그 상태로 `POST /chat` 을 거부한다. `send` 에서는 불리지 않는다 |
| `history` | `{load, save, list?, onError?}`. 대화 기록 저장소([위](#대화-기록-저장소-history)). 생략하면 기록은 메모리에만 있다 |
| `sessionIdleMs` · `maxSessions` | 메모리 축출(옵트인). `history`·`side` 가 있어야 한다([위](#메모리-축출)). 생략하면 축출하지 않는다 |
| `onAsk` | ask 를 기록하기 전에 부른다(답 버튼보다 먼저 끝나야 하는 일) |
| `onPermissionDecided` | `(info) => void \| Promise<void>`. 승인 요청 하나의 답이 백엔드로 간 뒤 한 번. 사람이 정했으면 `decidedBy` 가 붙는다([결정 권한](#결정-권한-authorizeaction)). 던져도 서버는 계속된다 |
| `rememberRules` | 승인 카드에 "항상 허용" 제안을 붙일지. 기본은 엔진에 `rememberRule` 이 있고 정책 파일이 켜져 있을 때 |
| `bufferSize` · `pingMs` | SSE replay 링 크기(범위마다, 기본 500)와 ping 간격(기본 15초) |
| `onError` | `(err, req) => void`. 500 으로 답한 예외를 받는다(로그용). 500 응답 본문은 예외 메시지가 아니라 고정 문구 `{error: '서버 오류'}` 다 — 클라이언트에 보여 줄 문구는 `HttpError` 로 던진다. `HttpError` 의 `cause`(응답에 내지 않음, 예: 규칙 기억 실패 409 의 원인)와 `POST /chat` 이 연 턴이 던진 예외(기록·SSE 에는 `'서버 오류'`)도 여기로 온다. 이 훅이 던져도 응답은 나간다. 엔진이 턴 안에서 낸 `error` 이벤트는 `message`·`reason`·`resumable` 만 기록·SSE 로 간다. 엔진은 소비자 훅(`resolveSession`·`gate` 등)의 예외 글·stderr·소유자 이름을 `message` 에 싣지 않고 `detail` 에 두며(1.7.0), 서버는 `detail` 을 클라이언트로 내지 않는다 — 진단이 필요하면 엔진의 `onEvent` 로 `detail` 을 읽는다 |

## 다른 문서

- [채팅 프로토콜](../chat-client/PROTOCOL.md) — HTTP·SSE 계약
- 참조 구현: [`examples/sse-server`](../../examples/sse-server/) 가 이 패키지로 `/api` 와 `/api/projects/:projectId` 두 접두어를 한 서버에 붙인다(정적 파일·CLI 플래그·가짜/실 모드는 예제 몫).

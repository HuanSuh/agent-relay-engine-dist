# @agent-relay-engine/claude

Claude Code CLI 백엔드다. CLI(`claude -p`, stdin/stdout stream-json)를 세션마다 상주 프로세스로 띄워 [core](../core/README.md) 의 `Engine` 계약대로 턴 단위 이벤트를 낸다. 설명자 이름은 `'claude'` 다. 기준 CLI 버전은 2.1.312 다.

## 가장 짧은 예제

```ts check
import { createSideChannel, MemorySideStore } from '@agent-relay-engine/core';
import { claudeProfiles, createClaudeEngine } from '@agent-relay-engine/claude';

const side = createSideChannel(new MemorySideStore(), 'my-tool');
const engine = createClaudeEngine({ ...claudeProfiles.conversation, cwd: process.cwd(), namespace: 'my-tool' }, { side });

for await (const ev of engine.turn('7b0f5a2e-1c3d-4e5f-8a9b-0c1d2e3f4a5b', '안녕')) {
  if (ev.type === 'text') console.log(ev.text);
}
await engine.dispose();
```

relay 에 넣으려면 `claudeBackend` 를 `createRelayEngine` 의 `backends` 에 넘긴다([core README](../core/README.md#relay-엔진)).

## 설치와 로그인

1. Claude Code CLI 를 설치하고 PATH 에 둔다(기준 2.1.312).
2. 구독 계정으로 로그인한다: `claude` 실행 뒤 `/login`.
3. `claude auth status` 가 `loggedIn: true`, `apiProvider: firstParty`, API 키가 아닌 `authMethod` 를 보여야 한다. 점검(`claudeBackend.detect`)과 relay 의 고르기가 이 명령(`checkClaudeAuthStatus`)을 쓴다. 엔진 자체는 CLI 를 띄운 뒤 init 의 API 키 출처를 보고, 허용 밖이면 그 턴을 `error(auth, resumable:false)` 로 끝낸다.
4. 자식 환경에서는 anthropic 몫의 과금 변수(`ANTHROPIC_API_KEY` 등, `AWS_*`·`VERTEX_REGION_*` 접두 포함)만 지운다. 그래서 이 엔진 아래 MCP 서버는 AWS 자격 증명을 물려받지 못한다(필요하면 서버 `env` 로 준다). OpenAI 키는 남는다. `permissions.auth.allow` 에 `'apiKey'` 를 넣으면 지우지 않는다.

## 개념

### 프로세스와 세션

- 세션 하나에 `claude -p` 프로세스 하나다. 처음 쓰는 세션은 `--session-id`, 대화를 시작한 적 있는 세션(기록 `started`)은 `--resume` 으로 띄운다.
- CLI 는 UUID 세션 id 만 받는다. UUID 가 아닌 id 는 `claudeCliSessionId(id)`(고정 네임스페이스 `CLAUDE_SESSION_NAMESPACE` 의 UUIDv5)로 바꿔 넘긴다. 같은 id 는 늘 같은 UUID 라 이어 가기가 된다. 이벤트·기록에는 준 id 가 그대로 간다.
- 없는 대화를 `--resume` 하면(stderr `No conversation found with session ID: …`) `started` 없이 `error(resume-missing, resumable:false)` 로 끝내고 기록의 `started` 를 되돌린다. 다음 턴은 새 대화다. 이 판정은 stderr 문구가 있을 때만 한다.
- stderr 문구 없이 실행 없는 오류 결과(`error_during_execution`, `num_turns:0`)와 0 아닌 종료만 오면 대화가 있을 수 있다. 이때는 `started` 없이 `error(cli-error, resumable:true)` 로 끝내고 `started` 는 그대로 둔다. detail 은 `{code, signal, stderrTail?, stderrLine?, subtype:'error_during_execution'}` 다.
- `started` 를 되돌린 뒤 `--session-id` 로 연 첫 프로세스가 init 전에 0 아닌 코드로 끝나면, 같은 id 가 CLI 에 남아 거절됐을 수 있다. 오류를 내지 않고 같은 턴을 `--resume <같은 id>` 로 한 번 다시 열고 `ext{claude.session_retry, {from:'session-id', to:'resume'}}` 로 알린다. 다시 연 턴의 `started.resumed` 는 true 다. 두 번째도 실패하면 평소대로 오류다. 다시 연 프로세스는 resume-missing 판정을 하지 않아 `started` 를 또 되돌리지 않는다.
- CLI 는 대화 파일을 cwd 별로 둔다. 이미 시작한 세션의 `cwd` 를 바꾸면 `--resume` 이 대화를 못 찾을 수 있다.

### control 채널과 2단 중지

`claude.useControlChannel:true` 면 stdin 의 비공개 control 채널을 쓴다.

- `stop()` 이 먼저 control interrupt 를 보내고, `interruptGraceMs` 안에 결과가 오면 프로세스를 유지한다(`'control'`). 아니면 프로세스 그룹에 SIGTERM → SIGKILL(`'signal'`).
- ask 결과를 보면 CLI 턴도 interrupt 로 끊는다(질문 뒤 출력이 이어지지 않게).
- 끼워 넣기(`mode:'inject'`) 판별에 쓴다. 입력 replay 가 결과보다 먼저 오면 실제 inject 이고, 결과의 처리한 입력 목록이 2차 근거다. CLI 가 텍스트 턴에서 inject 를 큐잉하면 `accepted{mode:'turn'}` 이 되고 `inject` capability 를 끈다.
- `injectFallback: 'reject'`(턴별 `TurnOptions.injectFallback` 또는 정책 `queue.injectFallback`)인 끼워 넣기는 그 프로세스에서 끼워 넣기가 턴 안에 들어간 것을 실측한 뒤에만 CLI 에 쓴다. 실측 전이면 쓰지 않고 `error(busy)` 로 거절한다. Claude 는 끼워 넣기가 턴 안에서 실행될지 보장할 수 없다(CLI 가 다음 턴으로 미룰 수 있고 `accepted-ack` 만으로는 알 수 없다). 그래서 이 설정이면 끼워 넣기는 대부분 거절된다 — 보통 턴으로 보낸다.
- 실측 뒤에 쓴 줄을 CLI 가 그래도 다음 턴으로 미루면(결과와 경합 등) 그 턴을 바로 멈추고 요청한 스트림을 `error{reason:'busy', detail:{injectFallback:'reject'}}` 로 닫는다. 이미 CLI 에 쓴 줄이라 멈추기 전까지 그 입력이 짧게 실행될 수 있다(도구 호출 포함).

### 모델 바꾸기

`TurnOptions.model`·`SessionOverrides.model`·`EngineConfig.model` 순으로 정한 모델로 띄운다(`--model`). 살아 있는 프로세스의 모델이 이번 턴과 다르면 입력을 쓰기 전에(이전 턴이 끝난 뒤에만) 바꾼다.

- **`useControlChannel:true`.** control `set_model` 을 보내고 `limits.controlRequestMs` 안의 응답을 기다린다. 성공하면 프로세스를 그대로 두고 `ext{core.model, {model, via:'control'}}` 를 낸다. `model` 은 CLI 가 해석한 이름(응답의 `model`, 없으면 요청한 이름)이고 그 턴 `started.model` 도 같다. 기본 모델로 돌아갈 때는 model 칸을 빼고 보낸다.
- **CLI 가 거절하면**(모르는 모델·조직 차단 등) 그 턴은 입력을 보내지 않고 `error(cli-error, resumable:true, detail:{code?, model?})` 로 끝난다. 같은 이름은 `--model` 로도 실패하므로 다시 띄우지 않는다.
- **control 채널을 끄면(기본) 또는 응답이 없으면** 프로세스를 내리고 `--resume --model <새 모델>` 로 같은 대화를 다시 띄운다(`via:'restart'`, 메트릭 `process.restart{reason:'model-changed'}`). 프롬프트 변경 재시작과 같은 장치다.
- 끼워 넣기에는 적용하지 않는다(`core.model{warning:'ignored-inject'}`).

### 도구 승인

| `permissions.approval` | CLI 플래그 | 동작 |
|---|---|---|
| `'none'` | 없음 | CLI 가 묻지 않고 자동 거부한다. 결과의 거부 목록이 `ext{core.permission_denied}` 로 온다 |
| `{kind:'control'}` | `--permission-prompt-tool stdio` | CLI 가 control 채널로 묻고 엔진이 `permission` 이벤트를 낸다. `permission-edit-input` 이 있어 바꾼 `updatedInput` 으로 실행된다 |
| `{kind:'mcpTool', name}` | `--permission-prompt-tool <name>` | 소비자 승인 MCP 도구. 도구는 `{tool_name, input, tool_use_id}` 를 받아 `{behavior:'allow', updatedInput}`·`{behavior:'deny', message}` 를 text JSON 으로 돌려준다. 코어 ask 도구는 이 모양이 아니라 설정 오류다 |

- `allow` 의 `updatedInput` 을 생략하면 요청 입력을 그대로 돌려준다(CLI 는 allow 에 입력이 있어야 실행한다).
- `onPermissionRequest` 훅은 도구 승인 요청만 받는다. 다른 control 요청은 오류로 응답한다. 훅이 던지면 CLI 에 고정 문구(`호스트의 도구 승인 처리가 실패했다`)의 오류 응답을 쓴다. 그 글은 도구 결과로 모델·기록에 남으므로 훅의 원문은 보내지 않고 `ext{core.control, {warning:'hook-error', cause}}`·metric `control.hook_error` 로만 알린다(1.7.0).
- `claude.settingSources` 를 열거나 `claude.strictMcp:false` 면 `approval` 을 정해야 한다(아니면 설정 오류).
- `mode:'auto'`·`acceptEdits` 에서 CLI 가 스스로 허용한 호출은 `permission` 없이 `tool-start`/`tool` 만 온다.

### 턴 단위 도구 범위

`TurnOptions.toolScope` 의 뜻과 공통 규칙은 [core README](../core/README.md#턴-단위-도구-범위-toolscope)에 있다. capability `turn-tool-scope` 가 늘 있다. 이 백엔드에서는 이렇게 지킨다.

- **`'read-only'`.** 살아 있는 프로세스의 도구 목록은 바꿀 수 없어 승인 경로로 지킨다. 이 턴의 `can_use_tool` 은 엔진이 모두 거절한다(사람에게 묻지 않고, `onPermissionRequest` 훅·기억한 규칙·사전 승인보다 먼저). CLI 에는 고정 문구의 `deny` 를 쓰고, `ext{core.permission_denied, {items, reason:'tool-scope'}}` 를 남긴다. 같은 호출은 result 의 거절 목록에서 빼 두 번 알리지 않는다.
- **막히는 것과 아닌 것(실측 2.1.325).** Write·Edit·`rm` 같은 셸 명령·WebFetch 와 하위 에이전트 안의 쓰기는 `can_use_tool` 을 거쳐 막힌다. Read·읽기 전용 셸(`ls`·`cat` 등)·하위 에이전트 띄우기(Agent)·ToolSearch 는 묻지 않고 실행된다.
- **읽기 전용 셸 분류는 CLI 를 믿는다.** 어떤 Bash 명령을 묻지 않고 실행할지는 CLI 가 정하고 엔진은 그 판단을 다시 보지 않는다. CLI 버전마다 분류가 바뀔 수 있어 버전을 올릴 때 다시 실측해야 한다.
- **확인한 내장 도구만(fail-closed).** read-only 턴은 init `tools` 의 내장 도구(`mcp__` 가 아닌 것)가 모두 확인 집합 안에 있어야 시작한다: `Read`·`Glob`·`Grep`·`LS`·`NotebookRead`·`ToolSearch`·`Agent`·`Task`·`Bash`·`BashOutput`·`Write`·`Edit`·`MultiEdit`·`NotebookEdit`·`WebFetch`·`WebSearch`·`TodoWrite`·`AskUserQuestion`(코드의 `SCOPE_VERIFIED_TOOLS`). 부작용이 있는 `KillShell` 은 넣지 않았다. 밖의 도구(환경에 따라 실리는 메시지·예약·알림 등, 승인 경로를 타는지 실측하지 않았다)가 있거나 `tools` 칸이 없으면 `error(config)`(`cause:'unverified-tools'`, `detail.tools` 에 그 이름)다. init 이 입력 전에 와 있으면 입력을 보내지 않고 닫고 프로세스는 그대로 둔다. 입력 뒤에 오면 그 시점에 프로세스를 내려 끊는다. 실측(2.1.325)으로 `--setting-sources ''` 의 CLI 기본 목록에는 확인 밖 도구(CronCreate·SendMessage·Workflow·RemoteTrigger 등 16개)가 실려, 기본 설정(`claude.builtinTools:'default'`)의 살아 있는 세션은 read-only 턴이 늘 `unverified-tools` 다. 아래처럼 확인 집합으로 띄운다.
- **확인 집합으로 띄우기(1.8.0).** `claude.builtinTools:'verified'` 면 세션 프로세스를 처음부터 `--tools <확인 집합의 CLI 이름>` 으로 띄워 살아 있는 세션이 read-only 턴을 받는다. read-only 분기와 `consult` 기본(새 프로세스)은 이 칸이 `'default'` 여도 늘 이렇게 띄운다. 넘기는 이름은 2.1.325 실측 이름 13개다: `Read`·`Glob`·`Grep`·`Bash`·`Write`·`Edit`·`Agent`·`ToolSearch`·`WebFetch`·`WebSearch`·`NotebookEdit`·`AskUserQuestion`·`TodoWrite`. 그 버전의 init `tools` 는 `Bash`·`Edit`·`Glob`·`Grep`·`NotebookEdit`·`Read`·`Task`·`ToolSearch`·`WebSearch`·`Write` 가 된다 — `Agent` 는 `Task` 로 보이고, `WebFetch`·`AskUserQuestion`·`TodoWrite` 는 그 버전 목록에 없지만 넣어도 실패하지 않는다. 실측하지 않은 `LS`·`NotebookRead`·`MultiEdit`·`BashOutput` 은 넣지 않는다. CLI 가 `--tools` 를 무시해 확인 밖 도구가 남으면 지금처럼 `unverified-tools` 다(fail-closed). `--tools` 는 뒤 인자를 먹지만 엔진은 프롬프트를 stdin 으로 주므로 상관없다.
- **하위 에이전트.** read-only 턴(또는 그 안의 하위 에이전트)에서 띄운 Agent·Task 의 `tool_use_id` 를 프로세스에 기억한다. `can_use_tool` 에는 부모 칸이 없어(실측) 하위 에이전트 줄의 `parent_tool_use_id` 로 소속을 잇는다. 그 소속의 승인 요청은 턴이 끝난 뒤(백그라운드 실행)나 다음 `'all'` 턴에 와도 거절한다. 그 프로세스에 read-only 턴에서 띄운 Agent 가 한 번이라도 있었으면, 소속을 모르는 요청(그 `tool_use` 줄을 보지 못한 요청)은 턴 유무·범위와 무관하게 거절한다. **대가**: 그 프로세스에서는 다음 `'all'` 턴에서도 소속 미상 요청이 승인되지 않는다 — 백그라운드 에이전트가 남아 있는 동안 승인이 실패할 수 있다. 프로세스를 내리면(`evict`·재시작) 기록이 사라진다.
- **지킬 수 없는 설정(fail-closed).** 승인 경로를 거치지 않고 실행되는 도구가 생기는 설정이면 read-only 턴을 띄우지 않고 `error(config)` 로 닫는다. `detail.cause` 는 `'allowed-tools'`(`permissions.allowedTools` 에 엔진 ask 도구와 Read·Glob·Grep·LS·NotebookRead·ToolSearch 밖의 항목, 정책 파일 포함), `'mode'`(`dontAsk`·`default`·`plan` 밖), `'approval'`(`{kind:'mcpTool'}` — 소비자 승인 도구가 엔진 밖에서 허용한다), 엔진 ask 도구(`mcp__core__ask`)는 엔진이 ask 서버를 띄울 때만 예외다. `'setting-sources'`(`claude.settingSources` 가 비어 있지 않다 — 사용자 설정의 허용 규칙), `'extra-args'`(`claude.extraArgs` 가 비어 있지 않다 — 엔진이 모르는 플래그가 승인 경로를 열 수 있다)다. 끼워 넣기로 진행 중 턴을 좁히려 할 때도 같은 설정이면 끼워 넣지 않고 `QueuePolicy.injectFallback` 으로 보낸다(새 턴이 `error(config)` 로 닫힌다). 같은 세션의 `'all'` 턴은 그대로 돈다.
- **이름 `core` 예약.** ask 서버를 띄우지 않는 설정(`coreToolsSpec` 없음·`coreToolsHost`·`ask.enabled:false`)에서도 `mcpServers` 에 `core` 가 있으면 설정 오류다.
- **한계.** `coreToolsHost` 로 ask 도구 이름을 바꾸면 그 이름은 위 예외 목록에 없다 — 미리 허용하면 `'allowed-tools'`, 아니면 read-only 턴에서 ask 승인이 거절된다(닫힌 쪽).
- **승인 창 없음.** `approval:'none'` 이면 `can_use_tool` 이 오지 않고 CLI 가 스스로 거절한다. 그 거절은 result 의 거절 목록으로 `reason` 없이 온다.
- **끼워 넣기.** 진행 중 턴에 더 좁은 범위의 입력을 끼워 넣으면 그 줄을 CLI 에 쓰기 직전부터 그 턴의 승인 요청을 거절하고(답을 기다리던 요청도 답을 쓰기 직전에 다시 본다) `ext{core.tool_scope, {scope, via:'inject'}}` 를 낸다. 끼운 입력이 다음 턴으로 밀려 CLI 가 이어 시작한 턴도 그 범위다.
- **`'none'`·`{allow}`.** 띄울 때의 도구 목록(`--tools`, `claude.builtinTools`)으로만 지킬 수 있어 살아 있는 프로세스의 턴에는 `error(config)`(`cause:'live-process'`)다. 세션 분기(아래)에서 띄울 때 받는다.

### 세션 분기 (`fork`·`consult`)

뜻과 공통 규칙은 [core README](../core/README.md#세션-분기와-물어보기-forkconsult)에 있다. capability `session-fork` 가 늘 있다.

- **띄우는 법.** 분기 세션의 첫 프로세스를 `--resume <원본 CLI 세션 id> --fork-session` 으로 띄운다. `--session-id` 는 붙이지 않는다(그 조합은 실측하지 않았다). CLI 가 정한 새 id(첫 `init` 의 `session_id`)를 세션 기록 `ext.claude.cliSessionId` 에 남기고, 이후 프로세스는 `--resume <그 id>` 로 띄운다. 원본이 분기 세션이면 그 분기의 CLI id 를 이어받는다. 실측(2.1.325): 새 id 가 생기고, 맥락을 이어받고, 원본 transcript 는 바뀌지 않는다.
- **복사 시점은 분기 세션의 첫 턴이다.** CLI 는 `init` 을 입력 뒤에 내므로 `fork()` 는 기록(`ext.claude.forkFrom`)만 한다. 첫 턴은 원본의 도는 턴이 끝나기를 기다리고, 첫 `init` 까지 원본의 다음 턴 시작을 붙잡는다. `fork()` 와 첫 턴 사이에 원본이 더 진행됐으면 그만큼 포함된다.
- **CLI 가 분기를 따르지 않으면** — init 의 `session_id` 가 비었거나 원본 id 와 같으면 받지 않는다. 그 턴은 `error(internal, cause:'fork-not-honoured')` 로 닫고 프로세스를 내린 뒤에 원본 큐를 놓는다(원본 대화에 더 이어 쓰지 않는다). init 은 입력 뒤에 오므로 **그 입력 한 줄은 이미 원본 transcript 에 남았을 수 있다**(원본을 이어 가면 모델이 그 줄을 본다). 그 분기 세션은 닫힌다 — 원본 id 를 지우고 기록 `ext.claude.forkRefused` 를 남겨, 다음 턴(재기동 뒤 포함)은 다시 `--fork-session` 을 시도하지 않고 CLI 를 띄우지 않은 채 같은 `error(internal, resumable:false, cause:'fork-not-honoured')` 로 닫는다. 새로 분기하려면 다른 id 로 `fork` 한다. 그 기록을 쓰지 못하면 metric `fork.refuse_persist_failed` 를 낸다(1.8.1) — 이 엔진 안에서는 메모리로 닫힌 채이고, 재기동한 엔진은 다시 분기를 시도한다.
- **첫 턴이 init 전에 끝나면** 그 턴은 실패하고 세션은 시작되지 않은 채 남는다. 다음 턴이 다시 분기한다. 원본 대화가 CLI 에 없으면 `error(resume-missing, '분기할 원본 대화가 CLI 에 없다')` 이고, 맥락 없는 새 대화(`--session-id`)로 바꾸지 않는다.
- **범위.** `'read-only'` 는 위의 턴 승인 경로 그대로이고, 띄울 때 내장 도구를 확인 집합으로 좁힌다(`builtinTools:'verified'`, `started.permissions.backend` 에도 그렇게 실린다). 엔진 칸이 이미 `'none'`·`'verified'` 이거나 `claude.extraArgs` 에 `--tools` 가 있으면 그대로 둔다(뒤의 경우는 `extra-args` 로 거절된다). MCP 서버는 거르지 않는다. `'none'` 은 `--tools ''`(보장 검사 strict)로 띄우고 MCP 설정(엔진 ask 서버 포함)을 넘기지 않으며 미리 허용을 비운다. `{allow}` 는 목록의 내장 도구만 `--tools a,b` 로(엔진 칸 `'verified'` 대신 이 목록이다), 목록에 `mcp__<서버>__…` 가 있는 MCP 서버만 넘기고 미리 허용은 목록 안의 것만 남긴다. 남긴 서버의 다른 도구는 승인 경로에서 거절한다. 범위는 띄울 때마다 같은 도구 목록이다(재시작·퇴출·새 엔진).
- **fail-closed.** 분기 세션의 턴은 init `tools` 에 범위 밖 도구가 있으면(`'none'` 은 어떤 도구든) `error(config, outside-scope)` 다. `'none'` 은 도구가 없어 `mode`·`allowedTools` 를 보지 않지만 `approval:{mcpTool}`(승인 도구 서버를 넘기지 않는다)·`claude.settingSources`·`claude.extraArgs` 는 그대로 거절한다. `{allow}` 는 정책 파일의 기억한 규칙도 미리 허용으로 보므로 목록 밖 도구의 규칙이 있으면 그 분기의 턴은 `'allowed-tools'` 다. `{allow}` 는 위의 read-only 우회 검사를 하되, 미리 허용은 목록 안의 도구(`Bash(git:*)` 는 `Bash`)면 받는다. `input.imageDelivery` 가 file 이면 Read 가 필요해 `'none'` 분기의 턴은 설정 오류다.
- **디스크 잔존.** CLI 에 디스크에 남기지 않는 분기 옵션이 없어 `consult` 로 정리해도 분기 transcript 는 CLI 저장소(사용자 홈의 Claude 프로젝트 폴더)에 남는다.
- **인자 파일·세션 설정.** 시스템 프롬프트·MCP 설정 파일(`claude.argFiles`, 세션별 `claude.argFiles`)과 `resolveSession` 병합은 일반 세션과 같은 길이다. `fork` 의 `overrides` 에는 `claude` 칸을 줄 수 없다. 분기 범위는 그 결과 위에 적용돼 세션 설정으로 넓힐 수 없다.

### 오류 분류

CLI 가 오류로 끝낸 턴은 `cli-error` 다. 사용 한도·문맥 초과·서버 오류(`usage-limit`·`context`·`upstream`)를 아직 가리지 않는다. 그래서 relay 의 `fallback.onUsageLimit` 은 이 백엔드에서 발동하지 않는다. 다른 사유는 [대응표](../../docs/BACKENDS.md#오류-사유)에 있다.

프로세스가 끝난 턴은 `error(exit)` 다. detail 은 `{code, signal, stderrTail?, stderrLine?}` 이다. `stderrTail` 은 stderr 의 마지막 2,048자를 줄 경계로 자르고 앞뒤 공백을 지운 값이고, stderr 가 비었으면 칸이 없다. message 는 종료 설명만이다. stderr 마지막 줄은 `stderrLine`(200자 상한)에 있고 message 에는 싣지 않는다(1.7.0).

### 이 백엔드의 ext

| ns | payload | 언제 |
|---|---|---|
| `claude.session_retry` | `{from:'session-id', to:'resume'}` | resume-missing 뒤 `--session-id` 가 init 전에 끝나 같은 턴을 `--resume` 으로 다시 열었다(started 뒤, 다시 연 것도 실패하면 error 앞) |

### MCP 서버와 도구

- CLI 는 MCP 도구를 지연 로딩한다. 모델이 MCP 도구를 쓰기 전에 `ToolSearch` 를 부르고, 엔진은 이것도 `tool-start`/`tool`(`kind:'other'`)로 낸다. 감추려면 `ev.name === 'ToolSearch'` 를 접는다. MCP 서버가 붙었는지는 `started.mcpServers` 로 본다(코어 ask 서버는 `{name:'core', status:'connected'}`).
- **연결 보장 검사(`mcpServersCheck`).** 엔진은 넘긴 서버(`mcpServers`, 세션 덮어쓰기, 코어 도구 서버)가 init 의 `mcp_servers` 에 `connected` 로 있는지 턴마다 본다. 기준은 [아래](#mcp-연결-보장-검사).
- CLI 는 MCP 도구 이름의 `[^A-Za-z0-9_-]` 를 `_` 로 바꿔 부른다. `McpServerSpec.tools` 에 원래 이름을 적으면 `originalName` 을 단다.
- CLI 는 stdio 서버를 **자기 cwd 에서** 띄운다. 경로와 로더(`tsx` 등)는 절대 경로로 준다.
- **MCP 설정은 파일로 넘긴다.** 설정 전체(http `headers` 의 인증 토큰, stdio `env` 값)가 CLI 인자에 실리면 같은 사용자의 `ps` 에 보인다. 엔진은 설정을 임시 폴더(0700)의 `mcp.json`(0600)에 쓰고 `--mcp-config <경로>` 로 경로만 넘긴다(Windows 는 기본 권한). 파일과 폴더는 그 프로세스의 첫 `system/init` 을 받는 즉시 지운다(1.8.0). CLI 는 init 뒤 이 파일을 다시 읽지 않는다(실측, 같은 프로세스의 다음 턴·MCP 연결에 영향이 없다). init 없이 끝나는 경로(기동 직후 종료, 첫 init 전 `dispose`)는 프로세스가 끝날 때(턴 사이 재시작, 자체 종료, `dispose`) 지운다. 두 번 지워도 안전하다. 프로세스가 `dispose` 없이 끝나도 `process.once('exit')` 에서 최선으로 지운다. MCP 서버가 없으면 파일도 `--mcp-config` 도 없다. 끄는 칸은 없다. SIGKILL·처리하지 않은 종료 신호로 죽으면 `exit` 정리가 돌지 않아, init 전에 죽은 프로세스의 파일이 임시 폴더에 남을 수 있다 — 종료 신호 핸들러에서 `removeLiveArgFiles()`(아래, 1.8.1)나 `engine.dispose()` 를 부르고, 엔진을 띄울 때 `cleanupStaleMcpConfigFiles()` 를 한 번 부른다(아래). 파일을 쓰지 못하면 그 턴은 `error(config, resumable)` 로 끝나고 프로세스를 띄우지 않는다. `buildClaudeArgs` 를 직접 부를 때 `writeMcpConfigFile(config, {sessionId, turnId})` 가 돌려준 파일을 `ctx.mcpConfig` 로 주고, 다 쓰면 `file.remove()` 를 부른다. 안 주면 예전처럼 설정 JSON 이 인자에 실려 비밀이 `ps` 에 보인다 — `mcpConfig` 를 준다. 실제 claude 2.1.325 로 `--mcp-config` 에 0600 파일 경로를 주면 MCP 서버가 `connected` 로 붙는 것을 확인했다. Linux 에서 `XDG_RUNTIME_DIR` 가 내 소유의 진짜 폴더(symlink 아님)이고 그룹·타인 권한이 없으면 임시 폴더를 그 아래에 먼저 만든다(디스크에 덜 남는다). 아니면 `os.tmpdir()` 이다.
- **시스템 프롬프트도 파일로 넘긴다(1.8.0).** `systemPrompt` 를 `--append-system-prompt <글>` 로 넘기면 지시문이 같은 OS 의 다른 사용자 `ps`·`/proc/<pid>/cmdline` 에 보인다. 엔진은 프롬프트를 MCP 설정과 같은 임시 폴더의 `system-prompt.txt`(0600)에 쓰고 `--append-system-prompt-file <경로>` 로 경로만 넘긴다. 끄는 칸은 없다. CLI 는 기동 때 한 번 읽으므로 첫 `system/init` 직후 폴더째 지운다(실측 2.1.325: 지운 뒤 다음 턴, `/compact` 뒤, 하위 에이전트 실행 뒤에도 지시가 남는다). init 없이 끝나는 경로의 정리는 MCP 설정 파일과 같다. 프롬프트가 비었으면 파일도 플래그도 없다. `systemPrompt` 가 함수면 값이 바뀔 때 다시 띄우면서(`core.restart{reason:'prompt-changed'}`) 새 파일을 쓴다. 이 플래그가 없는 오래된 CLI 는 기동에서 실패한다(2.1.325 에서 확인). 쓰지 못하면 그 턴은 `error(config)`(message `시스템 프롬프트 파일을 쓰지 못했다`, 원인은 `detail.cause`)로 끝난다. `buildClaudeArgs` 를 직접 부를 때 `ctx.systemPromptFile: {path}` 를 주면 파일 경로로, 안 주면 예전처럼 글을 인자에 싣는다.
- **인자 파일의 소유·모드(`claude.argFiles`, 1.8.0).** CLI 를 엔진과 다른 OS 사용자로 띄울 때(예: `sudo -u` 로 감싼 spawn) 그 사용자가 MCP 설정·프롬프트 파일을 읽을 수 있게 `{mode?, uid?, gid?, dir?}` 를 준다. 기본은 지금과 같다(엔진 프로세스 소유, 파일 0600·폴더 0700). 파일은 `O_CREAT|O_EXCL|O_NOFOLLOW` 로 새로 열어(미리 놓인 파일·symlink 는 거절) 그 fd 에 `fchmod`·`fchown` 한 뒤 내용을 쓴다. 폴더는 언제나 엔진 소유로 두고 `gid` 만 따른다 — CLI 사용자가 공용 임시 폴더의 폴더 항목을 소유하면 이름을 바꿔 엔진의 쓰기·삭제를 다른 곳으로 돌릴 수 있어서다. 폴더 mode 는 소유자 rwx 에, 파일 mode 에 그룹 읽기가 있으면 그룹 x, `uid` 를 주면 기타 x 만 더한다(목록·쓰기는 주지 않는다. 파일 경로는 argv 로 안다): 0o640+gid → 0o710, uid 만 → 0o701. 그룹·기타 쓰기(0o022)나 기타 접근(0o007)이 들거나 소유자 읽기(0o400)가 빠진 mode, `gid` 만 주면서 그룹 읽기(0o040)가 없는 mode, `gid` 없이 그룹 읽기를 준 mode(엔진의 기본 그룹이 읽게 된다), 정수가 아닌 값은 엔진 생성에서 설정 오류다. uid·gid 중 하나만 주면 다른 쪽은 그대로다(uid 만 주면 `fchown` 에 gid -1 대신 지금 파일의 gid 를 명시한다 — macOS 는 `fchown(fd, uid, -1)` 을 `EPERM` 으로 거절한다). uid·gid 는 0 ~ 0xFFFFFFFE 다(0xFFFFFFFF 는 chown 에서 '안 바꿈' 이라 받지 않는다). 소유를 바꿀 권한이 없거나, 바꾼 뒤 `fstat`·`lstat` 으로 본 소유·mode 가 기대와 다르면 만든 것을 폴더째 지우고 CLI 를 띄우지 않으며 그 턴은 `error(config)` 로, 원인(`EPERM` 등)은 `detail.cause` 에 담긴다. 내용은 한 번의 write 로 끝나지 않을 수 있어 끝까지 이어 쓰고 크기를 확인한다. 정리 함수가 쓰는 표식 파일은 엔진 소유 0600 으로 두고 만든 프로세스의 pid 를 적는다.
  - **어디에 만드나(`dir`).** 기본 위치(XDG_RUNTIME_DIR, macOS 의 사용자 tmpdir)는 그 사용자만 들어가는 0700 폴더라 다른 사용자인 CLI 가 열지 못한다. 그래서 uid·gid 를 주면 XDG_RUNTIME_DIR 를 건너뛰고 `os.tmpdir()` 를 쓰고, 다른 곳이 필요하면 `dir`(절대 경로)을 준다. `dir` 은 실제 경로(realpath, `..`·symlink 를 푼 것)로 판정한다. 그 폴더와 **모든 상위 폴더가 root 또는 엔진(euid) 소유**여야 하고, 그룹·기타 쓰기가 있으면 sticky 여야 한다(신뢰 소유의 sticky 폴더, 예: `/tmp`). 아니면 쓰기·정리 모두 거절한다. 만들기·정리는 검사한 실제 경로에서만 하고, 만든 폴더는 symlink 를 따르지 않는 fd 로 열어 mode·그룹을 정하며, 파일을 쓰기 직전마다 그 폴더가 바뀌지 않았는지(dev·ino) 확인한다. uid·gid 를 주면 엔진 생성 때(그리고 매번 쓰기 전에) 그 폴더와 위의 모든 폴더를 CLI 사용자(uid, 아니면 gid)가 지나갈(x) 수 있는지 보고, 막히면 막는 경로를 넣어 설정 오류로 알린다. macOS 에서 uid·gid 를 주려면 보통 `dir` 이 필요하다(예: `/tmp` 아래 엔진 소유 0o711 폴더, 또는 상위 폴더까지 root·엔진 소유이고 남이 쓸 수 없는 `/var/lib/<서비스>/args`). 그 사용자의 다른 그룹은 엔진이 알 수 없어 gid 로만 본다.
  - **권한은 mode 비트만 본다.** 확장 ACL(`chmod +a`, `setfacl`)로 남에게 쓰기를 준 폴더는 판정에서 보이지 않으므로 `dir` 이나 그 상위로 쓰지 않는다.
  - **무엇이 보이나.** 내용은 파일 mode 로 보호된다. 폴더와 파일이 있다는 것과 크기는 다른 사용자에게 보일 수 있다(uid 방식은 기타 x 를 연다). 그것도 숨겨야 하면 gid 방식(파일 0o640 + gid, 폴더 0o710)을 쓴다.

  ```ts check
  import type { EngineConfig } from '@agent-relay-engine/core';
  import '@agent-relay-engine/claude';

  // CLI 를 uid 1001 로 띄우는 데몬: 파일은 그 사용자 소유 0600.
  // dir 은 상위 폴더까지 root·엔진 소유이고 남이 쓸 수 없으며, 그 사용자가 지나갈 수 있는(x) 곳이어야 한다
  export const asOtherUser: Partial<EngineConfig> = { claude: { argFiles: { uid: 1001, gid: 1001, dir: '/var/lib/agent-relay/args' } } };
  ```

- **세션별 인자 파일(`resolveSession` 의 `claude.argFiles`, 1.8.1).** 한 엔진을 여러 세션이 함께 쓰고 세션마다 CLI 를 다른 OS 사용자로 띄우면, `resolveSession` 이 돌려주는 `claude: { argFiles }` 로 그 세션의 `{mode?, uid?, gid?, dir?}` 를 준다(타입 `ClaudeSessionOverrides`). 세션마다 다른 uid 를 주면 세션끼리 서로의 MCP 설정·프롬프트 파일을 읽지 못한다(gid 를 함께 쓰면 그 그룹이 다른 세션 파일도 읽는다 — uid 로 나눈다).
  - **통째로 바꾼다.** 세션 값은 엔진 `claude.argFiles` 를 키별로 섞지 않고 통째로 바꾼다 — 세션 값에 없는 칸은 엔진 값이 아니라 기본값이다(예: 엔진 `mode: 0o640, gid` 에 세션 `{uid}` 만 주면 mode 는 기본 0600 이고 gid 는 엔진 값을 쓰지 않아 파일이 만들어진 그룹 그대로다).
  - **검사는 엔진 칸과 같다.** mode 제약, uid·gid 상한, `dir` 의 신뢰 판정(실제 경로, 상위 폴더까지 root·엔진 소유, 공용 쓰기면 sticky), CLI 사용자의 지나가기를 매 턴 본다. 틀리면 그 턴은 CLI 를 띄우지 않고 `error(config, '세션 설정 실패')` 이고 검사 글은 `detail.cause` 에 있다. 소유를 바꾸지 못하면 지금처럼 쓰다 만 폴더를 지우고 `error(config)` 다(fail-closed).
  - **`argFiles` 만 받는다.** `claude` 칸의 다른 값(`settingSources`·`strictMcp`·`extraArgs`·`builtinTools` 등)을 주면 `error(config)` 다. 세션 설정으로 다른 보안 설정을 넓히지 못한다. `fork` 의 `overrides` 에는 `claude` 칸을 줄 수 없다(`ForkError(input)`) — 분기 세션도 새 세션 id 로 `resolveSession` 을 부르므로 거기서 준다.
  - **바뀌면 다시 띄운다.** 같은 세션의 값이 바뀌면 다음 턴 전에 같은 대화로 다시 띄우고 `core.restart{reason:'config-changed'}` 를 낸다. 이전 프로세스의 폴더는 만들 때의 위치·식별(dev·ino, 엔진 소유)로 지운다 — 새 값과 섞이지 않는다.
  - **relay.** `createRelayEngine` 은 Claude 엔진에 `claude` 칸만 넘기고, 고를 때의 설정 검사(`validateConfig`)도 세션 값을 합친 설정으로 본다. 단독 Codex 엔진에 `claude` 칸을 주면 설정 오류다.
  - **남은 폴더 정리.** 세션마다 `dir` 이 다르면 `cleanupStaleMcpConfigFiles({ argFiles })` 를 쓰는 `dir` 마다 부른다. 이 프로세스가 지금 쓰는 폴더는 어느 `dir` 에 있든 두고 지운다.

  ```ts check
  import type { EngineConfig } from '@agent-relay-engine/core';
  import '@agent-relay-engine/claude';

  // 세션마다 다른 OS 사용자. uidOf 는 소비자가 정한다(세션 → uid)
  declare function uidOf(sessionId: string): number;
  export const perSession: Partial<EngineConfig> = {
    resolveSession: ({ sessionId }) => ({ claude: { argFiles: { uid: uidOf(sessionId), dir: '/var/lib/agent-relay/args' } } }),
  };
  ```

- **종료 신호 때 정리(`removeLiveArgFiles`, 1.8.1).** 인자 파일 폴더는 init 뒤와 프로세스 종료 때 지우고, `dispose` 없이 끝나도 `process.once('exit')` 에서 지운다. 하지만 SIGTERM·SIGINT 로 끝나면 `exit` 가 돌지 않아 init 전 폴더(MCP 토큰 포함)가 다음 정리까지 남는다. 엔진은 신호 처리기를 직접 걸지 않는다 — Node 는 신호 처리기가 하나라도 있으면 기본 종료를 하지 않아 소비자 종료 흐름과 부딪힌다. 대신 소비자의 신호 처리기 안에서 `removeLiveArgFiles()` 를 부른다. 이 프로세스가 만들어 아직 지우지 않은 폴더만 평소와 같은 확인 규칙(만든 그 폴더의 dev·ino, 엔진 소유)으로 동기로 지우고, 지운 수를 돌려주며 던지지 않는다. 살아 있는 CLI 가 아직 init 전이면 파일을 읽지 못하므로 종료 직전에만 부른다.

  ```ts check
  import { removeLiveArgFiles } from '@agent-relay-engine/claude';

  for (const sig of ['SIGTERM', 'SIGINT'] as const) {
    process.once(sig, () => {
      removeLiveArgFiles(); // 동기. 비밀이 든 인자 파일을 먼저 지운다
      process.exit(128 + (sig === 'SIGTERM' ? 15 : 2)); // 또는 engine.dispose() 뒤 기존 종료 흐름
    });
  }
  ```

- **남은 설정 폴더 정리(`cleanupStaleMcpConfigFiles`, 1.8.0).** 이전 프로세스가 SIGKILL 등으로 죽어 남긴 `are-mcp-*` 폴더를 지우고 지운 수를 돌려준다. 설정 파일을 쓰는 곳(신뢰 검사를 통과한 `XDG_RUNTIME_DIR`, 아니면 `os.tmpdir()`)에서 찾고, **엔진이 만든 표식 파일(`.are-engine`, 내 uid 소유, symlink 아님)이 있고 폴더가 symlink 가 아니며 mtime 이 `olderThanMs`(기본 10분, 하한 60초)보다 오래된 폴더만** 지운다. 표식에 적힌 pid 의 프로세스가 살아 있으면(다른 엔진 프로세스가 쓰는 중) 둔다. 다만 표식의 만든 시각이 24시간을 넘었으면 pid 가 재사용됐을 수 있어 살아 있다고 보지 않는다. 찾는 곳은 쓰는 곳과 같은 판정(실제 경로, 상위 폴더까지 root·엔진 소유, 공용 쓰기면 sticky)을 통과해야 하고, 아니면 아무것도 지우지 않는다. `claude.argFiles` 를 쓰면 같은 값을 `cleanupStaleMcpConfigFiles({ argFiles })` 로 넘긴다. 엔진이 쓰는 곳(`dir`, 아니면 uid·gid 일 때 `os.tmpdir()`)을 찾는다. 폴더도 내 uid 소유여야 하고(`argFiles` 를 줘도 폴더 uid 는 바뀌지 않는다), 표식이 하드 링크(nlink 2 이상)면 표식으로 보지 않는다. 표식이 없는 폴더는 이름이 같아도 둔다. 1.8.0 이전 버전이 남긴 폴더(표식 없음)는 지우지 않는다. 이 프로세스가 지금 쓰는 폴더는 두고, 던지지 않는다. 기본 위치는 호출할 때의 환경(`XDG_RUNTIME_DIR`)을 따르므로 이전 실행과 위치가 다르면 `dir` 로 준다. `buildClaudeArgs` 로 직접 띄운다면 기동부터 init 까지가 `olderThanMs` 를 넘지 않게 한다. 옵션 `{olderThanMs?: number, dir?: string, argFiles?: ClaudeOptions['argFiles']}`.

  ```ts
  import { cleanupStaleMcpConfigFiles, createClaudeEngine } from '@agent-relay-engine/claude';

  cleanupStaleMcpConfigFiles(); // 엔진을 띄울 때 한 번. 지운 수를 돌려준다
  const engine = createClaudeEngine(config, deps);
  ```

- 턴 문맥 창구(core README 의 [MCP 서버에서 턴 문맥 읽기](../core/README.md#mcp-서버에서-턴-문맥-읽기))는 CLI 프로세스 env 의 `AGENT_RELAY_ENGINE_CONTEXT`·`_CONTEXT_TOKEN` 으로 알린다. stdio 서버가 CLI env 를 물려받으므로 `--mcp-config` 에는 싣지 않는다. 서버가 받는 `_meta["claudecode/toolUseId"]` 는 stream-json 의 `tool_use.id` 이고, 엔진은 그 tool_use 를 읽을 때(서브에이전트 안 포함) 이 id 를 턴에 잇는다.

```ts check
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import type { McpServerSpec } from '@agent-relay-engine/core';

// 빌드 없이 TypeScript 를 tsx 로 돌린다(개발·테스트)
const tsx = pathToFileURL(createRequire(import.meta.url).resolve('tsx')).href;
export const source: McpServerSpec = { command: process.execPath, args: ['--import', tsx, fileURLToPath(new URL('../src/mcp/bin.ts', import.meta.url))] };
// 빌드한 JS 를 node 로 돌린다(배포)
export const dist: McpServerSpec = { command: process.execPath, args: [fileURLToPath(new URL('../dist/mcp/bin.js', import.meta.url))] };
```

### MCP 연결 보장 검사

CLI 를 다시 띄웠을 때 MCP 서버가 붙지 않으면 모델은 도구 없이 턴을 돈다. 생각만 하고 끝나도 턴은 정상 종료다. `claude.mcpServersCheck` 는 이 상태를 턴이 시작될 때 잡는다.

```ts check
import type { EngineConfig } from '@agent-relay-engine/core';

// 도구가 없으면 일할 수 없는 구성: 붙지 않은 서버가 있으면 그 턴을 시작하지 않는다
export const mcpRequired: Partial<EngineConfig> = { claude: { mcpServersCheck: 'strict' } };
```

- **기대 서버.** 그 프로세스에 실제로 넘긴 서버 이름 전부다. 설정의 `mcpServers`, `resolveSession` 이 덮어쓴 `mcpServers`, 코어 도구 서버(`core`)가 든다. `strictMcp:false` 로 붙은 사용자·프로젝트 서버는 보지 않는다. 넘긴 서버가 없으면 검사하지 않는다.
- **어긋남.** init 의 `mcp_servers` 에 그 이름이 없거나(`status:'missing'` 으로 적는다) 상태가 `connected` 가 아닌 것(`failed`·`needs-auth`·`pending` 등)이다. print 모드의 CLI 는 연결을 기다린 뒤 init 에 최종 상태를 싣는다.
- **도구 없는 서버(`status:'no-tools'`).** CLI 는 `tools/list` 가 오류인 서버도 `connected` 로 알린다. 그래서 `connected` 여도 init 의 `tools` 에 `mcp__<서버>__` 로 시작하는 도구가 하나도 없으면 어긋남으로 본다(서버 이름은 CLI 가 도구 이름에 쓰는 정규화를 거친 것으로 맞춘다). init 에 `tools` 칸이 없으면 이 판정은 하지 않는다. 서버를 통째로 거부한 규칙(`permissions.disallowedTools` 의 `mcp__<서버>` 또는 `mcp__<서버>__*`, 정책 파일의 것 포함)이 있는 서버도 하지 않는다. 모든 서버를 거부하는 `mcp__*` 면 어느 서버도 하지 않는다 — 거부한 도구는 연결된 서버라도 init 의 `tools` 에서 빠지기 때문이다. 이름이 다른 서버 이름의 앞부분인 서버(`a` 와 `a__b` 가 함께 있을 때의 `a`, init 에만 알려진 `a__b` 포함)도 `a__b` 의 것으로 센 도구가 있으면 하지 않는다 — `mcp__a__b__x` 가 `a` 의 도구 `b__x` 인지 `a__b` 의 도구 `x` 인지 이름만으로는 가릴 수 없기 때문이다. 이런 도구는 `a__b` 의 것으로 센다. 다음 구성은 `'strict'` 에서 `no-tools` 로 막히므로 `'warn'` 을 쓴다.
  - 도구를 하나도 등록하지 않는 서버(리소스·프롬프트만 내는 서버 등)를 넘긴다.
  - 도구 하나만 거부한 규칙(`mcp__<서버>__<도구>`)으로 그 서버의 도구를 모두 막는다(도구가 하나뿐인 서버 등). 도구 단위 규칙은 판정에서 빼 주지 않는다 — 빼 주면 `tools/list` 실패를 놓친다.
  - CLI 설정 파일(`.claude/settings.json` 등의 `permissions.deny`)로 MCP 도구를 거부한다(`settingSources` 를 연 구성). 엔진은 설정 파일의 규칙을 보지 못한다.
- **`'warn'`(기본).** 턴은 그대로 간다. `started` 뒤에 `core.config{warning:'mcp-not-connected', servers:[{name, status}]}` 를 낸다(도구 없는 서버도 이 경고에 `status:'no-tools'` 로 든다). 같은 프로세스에서 목록(이름·상태)이 앞서 알린 것과 같으면 다시 내지 않고, 바뀌면 다시 낸다. 다시 붙은 것은 따로 알리지 않는다. 모두 붙었다가 다시 끊기면 같은 목록이어도 다시 낸다.
- **`'strict'`.** 그 턴의 출력을 내지 않고 프로세스를 내린 뒤 `error(reason:'config', resumable:true, detail:{mcp, status, servers:[{name, status}]})` 로 닫는다. `mcp`·`status` 는 첫 어긋난 서버다. 다음 턴은 프로세스를 새로 띄워 다시 연결하므로 같은 입력을 다시 보내면 된다. init 은 user 메시지 처리 시작에 오므로 입력은 이미 CLI 에 나갔을 수 있다([내장 도구 끄기](#내장-도구-끄기)의 끊기와 같다).
- **`mcp_servers` 칸이 없는 init.** 판정하지 못한다. `'warn'`·`'strict'` 모두 막지 않고 프로세스마다 한 번 `core.config{warning:'unverified', fields:['claude.mcpServersCheck']}` 를 낸다.
- **init 보다 먼저 온 출력.** 그 시점에는 판정하지 않는다. 같은 턴에 뒤늦게 init 이 오면 그때 보되, 이미 출력을 내보낸 턴이라 `'strict'` 도 끊지 않고 `mcp-not-connected` 경고만 낸다. 다음 턴의 init 부터 다시 `'strict'` 로 막는다.
- **입력 전에 닫힌 턴.** 이번 턴에 새로 띄운 프로세스가 입력을 받기 전에 턴이 닫히면(예: 답 턴의 `ask-mismatch`, 띄우는 사이 온 `stop()` 의 `error(stopped)`, 입력을 쓰기 직전의 control 중지로 닫힌 `interrupted`) 엔진은 그 프로세스를 내린다. 턴 문맥 없이 뜬 MCP 서버는 도구 목록을 내지 못했을 수 있어, 다음 턴이 도구 없는 프로세스를 물려받지 않게 한다. 앞 턴부터 살아 있던 프로세스는 그대로 둔다. 이 동작은 `mcpServersCheck` 값과 무관하다.
- **드러냄.** `started.permissions.backend.mcpServersCheck` 가 `'warn' | 'strict'` 다. 도구 없이 끝난 턴 자체는 `ext{core.empty_turn}` 으로도 알 수 있다([core README](../core/README.md#engineevent--턴-하나의-스트림)).

### 내장 도구 끄기

`claude: { builtinTools: 'none' }` 이면 CLI 를 `--tools ''` 로 띄운다. 실측(2.1.322)으로 init 의 `tools` 에는 `mcp__<서버>__<도구>` 이름만 남고, `ToolSearch` 를 포함한 내장 도구가 모두 빠진다. MCP 도구는 지연 로딩 없이 바로 호출된다. 셸을 쓰라고 해도 모델은 셸이 없다고 답한다.

```ts check
import type { EngineConfig } from '@agent-relay-engine/core';

// MCP 도구만 쓰는 구성. 턴 문맥 토큰은 셸 도구로 읽힐 수 있으므로, 셸을 끈 이 구성이 권장이다
export const mcpOnly: Partial<EngineConfig> = { claude: { builtinTools: 'none' } };
```

`claude: { builtinTools: 'verified' }` 면 승인 경로를 타는지 확인한 내장 도구만으로 띄운다(목록은 [턴 단위 도구 범위](#턴-단위-도구-범위)). 기본 목록의 메시지·예약·알림 같은 도구가 빠지고, 살아 있는 세션이 read-only 턴을 받을 수 있다. 보장 검사는 `'none'` 과 같은 규칙으로 하되, 확인 집합 밖 내장 도구가 남았을 때 실패한다(`detail:{builtinTools:'verified', unexpected}`) — read-only 턴은 그보다 `unverified-tools` 가 먼저다. 아래 규칙 중 `'none'` 이 Read 를 끄기 때문에 생기는 것(이미지 file 전달 금지, 권한 칸의 내장 이름이 무의미)은 `'verified'` 에 해당하지 않는다.

- **권장 설정.** 턴 문맥 창구의 토큰(`AGENT_RELAY_ENGINE_CONTEXT_TOKEN`)은 셸 도구로 읽힐 수 있다. 서버가 턴 문맥을 쓰고 모델이 도구만 부르면 되는 구성이라면 `'none'` 을 준다. 기본(`'default'`)은 지금 동작과 같다.
- **보장은 `--tools` 가 한다.** 엔진은 init 의 `tools` 로 그것이 지켜졌는지 확인하고, 어긋나면 그 턴을 즉시 끊는다. init 은 user 메시지 처리 시작에 오므로, 사용자 입력은 확인 전에 CLI 에 이미 나갔을 수 있다. 끊기는 control 중지를 거치지 않고 프로세스를 바로 내린다(SIGTERM). 그 턴의 남은 출력(assistant·tool_use)은 이벤트로 내지 않고 `error(reason:'config', resumable:false, detail:{builtinTools:'none', unexpected:[…]})` 하나로 닫는다(`'verified'` 면 `builtinTools:'verified'`). 재사용 프로세스에서는 이전 턴의 init 으로 `started` 가 먼저 나갈 수 있으나, 내용은 같은 방식으로 끊긴다.
- **tools 칸이 없는 init.** 확인할 수 없으므로 막지 않는다. 대신 프로세스마다 한 번 `core.config{warning:'unverified', fields:['claude.builtinTools']}` 를 낸다.
- **init 앞 출력.** 그 턴의 init 보다 먼저 assistant·tool_use·tool_result·stream 줄이 오면 확인하지 못한 것이다. 기본(`'warn'`)은 그 줄을 그대로 내보내고, 프로세스마다 한 번 `unverified` 를 알린다. 재사용 프로세스의 이전 턴 init 은 이번 턴의 것으로 치지 않는다.
- **보장 검사 방식(`builtinToolsCheck`).** 기본 `'warn'` 은 위와 같다. 턴 문맥 토큰(셸로 읽힘)을 쓰는 중계라면 `'strict'` 를 권한다. 셸을 막는 보안 겹이기 때문이다. `'strict'` 는 fail-closed 다. 다음 두 경우 그 턴의 출력을 내지 않고 프로세스를 내린 뒤 `error(reason:'config', resumable:false, detail:{builtinTools:'none', check:'strict', why})` 로 닫는다. `why` 는 `'no-tools-field'`(init 에 tools 칸이 없다)와 `'output-before-init'`(init 보다 먼저 출력이 왔다)이다. strict 는 init 을 턴마다 받는 것을 전제한다(실측: init 은 턴마다 온다).
- **권한 칸.** `'none'` 이면 `permissions.allowedTools`·`disallowedTools` 에 내장 도구 이름이 있어도 의미가 없다. 막지는 않고 그대로 CLI 에 넘긴다. `'none'` 이면 내장 도구 이름 규칙은 필요 없다.
- **이미지 file 전달과는 함께 쓸 수 없다.** `'none'` 과 `input.imageDelivery` 의 file 전달(`{kind:'file'}`)을 같이 주면 엔진 생성 때 설정 오류다. file 전달은 모델이 Read 로 이미지를 읽어야 하고 `'none'` 은 Read 를 끄기 때문이다. `allowedTools` 에 내장 도구 이름이 있는 것은 막지 않는다.
- **extraArgs 와의 관계.** `'none'`·`'verified'` 와 `extraArgs` 의 `--tools` 를 함께 주면 설정 오류다. Claude 엔진 생성 때 던지고, relay 에서는 고를 때 Claude 를 건너뛴다. `extraArgs: ['--tools', '']` 단독은 1.x 소비자를 위해 그대로 넘기고, started 뒤 프로세스마다 한 번 `core.config{warning:'prefer-field', fields:['claude.extraArgs --tools'], use:'claude.builtinTools'}` 를 낸다.
- **드러냄.** `started.permissions.backend.builtinTools` 가 `'default' | 'none' | 'verified'`, `builtinToolsCheck` 가 `'warn' | 'strict'` 다. Codex 는 이 칸을 지원하지 않는다([대응표](../../docs/BACKENDS.md#내장-도구-끄기)).
- **무시.** `builtinTools` 가 `'default'` 인데 `builtinToolsCheck` 를 주면 쓰지 않고 `core.config{warning:'ignored', fields:['claude.builtinToolsCheck']}` 로 알린다.

### 구독 사용률

`usage.subscription[]`(`window:'5h'|'7d'`, `usedRatio`, `resetsAt?`)은 CLI 의 비공개 사용률 이벤트에서 읽는다. 그래서 `subscription-usage` capability 는 그 프로세스에서 창 값을 하나 이상 읽은 뒤에만 켜지고 `ext{core.capabilities}` 로 알린다. 새로 뜬 프로세스는 다시 꺼진 상태에서 시작한다.

### 추론

추론 출력을 본 뒤 `thinking` capability 를 켜고, 조각은 `thinking-delta`, 완성본은 `ext{core.thinking}` 으로 낸다.

### 참고 프로필 `claudeProfiles`

값일 뿐 core 의 일부가 아니다. 펼쳐 쓰고 필요한 칸을 덮는다.

| 프로필 | 값 | 쓰임 |
|---|---|---|
| `conversation` | `permissions:{mode:'dontAsk', approval:'none'}`, `queue:{coalesce:true}` | 승인 창 없이 ask 로 되묻는 대화형 |
| `command` | `claude:{settingSources:['user','project'], strictMcp:false}`, `subagents:'inline'`, `permissions:{}` | 사용자 설정·플러그인을 쓰는 실행형. 사용자 계정의 원격 커넥터까지 붙는다. `approval` 을 비워 두므로 채우지 않으면 설정 단계에서 거부된다 |
| `batch` | `ask.enabled:false`, `queue:{coalesce:false, maxDepth:1}`, `approval:'none'`, `turnDefaults.requireToolCall:true` | 사용자 입력이 없는 턴. 도구 없이 끝난 턴은 `done{stopReason:'no-tool-call', toolCalls:0}` |

```ts check
import type { EngineConfig } from '@agent-relay-engine/core';
import { claudeProfiles } from '@agent-relay-engine/claude';

export const config: EngineConfig = {
  ...claudeProfiles.command, cwd: '/srv/app', namespace: 'my-tool',
  permissions: { ...claudeProfiles.command.permissions, approval: { kind: 'mcpTool', name: 'mcp__tool__approve' } },
};
```

### 한계

- control interrupt·승인 요청·사용률 이벤트·init 칸은 CLI 의 공개 규약이 아니다. 해석기는 못 읽는 줄을 버리고 죽지 않으며, capability 는 실제로 본 뒤에만 켠다.
- 결과 직전 끼워 넣기 경합에서 inject 불가로 오판할 수 있다.
- 프로세스 그룹 종료는 POSIX 기준이다. Windows 는 확인하지 않았다.

## 공개 API

<!-- gen:api @agent-relay-engine/claude . -->
`@agent-relay-engine/claude` — 39개, 공개 API 스냅샷 1.8.5 기준.

| 종류 | 이름 |
|---|---|
| function | `buildClaudeArgs` · `checkClaudeAuthStatus` · `checkExtraArgs` · `claudeCliSessionId` · `claudeToolKind` · `cleanupStaleMcpConfigFiles` · `describeApproval` · `launchesCoreTools` · `parseClaudeStreamLine` · `parseClaudeStreamLineAll` · `parseClaudeVersion` · `permissionPromptTool` · `removeLiveArgFiles` · `resolveClaudePermissions` · `resolveMcpServers` · `writeMcpConfigFile` |
| class | `ClaudeCliEngine` · `McpConfigWriteError` |
| const | `CLAUDE_CAPABILITIES` · `CLAUDE_LEGACY_FIELDS` · `CLAUDE_SESSION_NAMESPACE` · `CLAUDE_TOOL_KINDS` · `claudeBackend` · `claudeProfiles` · `CORE_FLAGS` · `createClaudeEngine` · `DEFAULT_CLAUDE_SUBAGENT_POLICY` · `isUuid` · `PROGRESS_EVERY_MS` |
| type | `AuthStatus` · `BuildArgsContext` · `ClaudeOptions` · `ClaudePermissionsBackend` · `ClaudeResolvedPermissions` · `ClaudeSessionOverrides` · `ClaudeStreamItem` · `CleanupStaleOptions` · `McpConfigFile` · `SubscriptionUsage` |
<!-- /gen -->

## 설정

이 패키지를 가져오면 선언 병합으로 `EngineConfig.claude?: ClaudeOptions` 가 생긴다. 다른 백엔드는 이 칸을 받기만 하고 `core.config{warning:'ignored'}` 로 알린다. 이 엔진도 다른 백엔드 칸(`codex.*` 등)을 받으면 started 뒤 프로세스마다 한 번 `core.config{warning:'ignored', fields}` 를 낸다.

| `claude.*` | 기본 | 뜻 |
|---|---|---|
| `settingSources` | `[]` | 쓸 사용자·프로젝트 설정(`'user'`·`'project'`·`'local'`, `--setting-sources`). 열면 `approval` 을 정해야 하고 `relaxed:true` |
| `strictMcp` | `true` | 준 MCP 서버만 붙인다(`--strict-mcp-config`). `false` 면 사용자·프로젝트 MCP 도 붙는다 |
| `coreToolsHost` | 없음 | 코어 도구(ask)를 합칠 툴 서버 이름. 주면 ask 서버를 따로 띄우지 않는다([ask README](../ask/README.md#2-툴-서버에-합치기--registercoretools)) |
| `useControlChannel` | `false` | control 채널(2단 중지·ask 끊기·inject 판별)을 쓸지. 끄면 `control-interrupt` capability 도 싣지 않는다 |
| `builtinTools` | `'default'` | `'none'` 이면 Claude 내장 도구를 모두 끈다(`--tools ''`, MCP 도구만 남는다). `'verified'` 면 승인 경로를 타는지 확인한 내장 도구만으로 띄운다(살아 있는 세션의 read-only 턴용). 둘 다 턴마다 보장 검사를 한다. 절 [내장 도구 끄기](#내장-도구-끄기) |
| `builtinToolsCheck` | `'warn'` | `'strict'` 면 보장 검사가 fail-closed 다(init 에 tools 칸이 없거나 init 보다 먼저 출력이 오면 그 턴을 `error(config)` 로 닫는다). `builtinTools` 가 `'none'`·`'verified'` 일 때만 뜻이 있다 |
| `mcpServersCheck` | `'warn'` | 넘긴 MCP 서버가 init 에 `connected` 로 있고 도구를 냈는지 턴마다 본다. `'warn'` 은 `core.config{warning:'mcp-not-connected'}` 로 알리고, `'strict'` 는 그 턴을 `error(config, resumable)` 로 닫고 프로세스를 내린다. 절 [MCP 연결 보장 검사](#mcp-연결-보장-검사) |
| `argFiles` | 엔진 소유, 0600·0700 | 엔진이 CLI 에 넘기는 인자 파일(MCP 설정, 시스템 프롬프트)과 그 폴더의 `{mode, uid, gid, dir}`. uid·gid 를 주면 CLI 사용자가 `dir`(없으면 `os.tmpdir()`)까지 지나갈 수 있어야 한다. 소유를 바꾸지 못하면 그 턴은 `error(config)`. 세션별로는 `resolveSession` 의 `claude.argFiles` 가 통째로 바꾼다(1.8.1). 절 [MCP 서버와 도구](#mcp-서버와-도구)의 '인자 파일의 소유·모드'·'세션별 인자 파일' |
| `extraArgs` | `[]` | 코어가 모르는 CLI 플래그를 인자 맨 끝에 그대로. 코어가 넣는 플래그(`CORE_FLAGS`)와 겹치면 설정 오류. `--tools` 는 `builtinTools` 로 쓴다(1.2.0 부터, 단독은 호환으로 넘어간다) |

- `started.permissions.backend` 는 `{settingSources, strictMcp, builtinTools, builtinToolsCheck, mcpServersCheck}`(`ClaudeResolvedPermissions`)다.
- 1.0 에 없는 칸(`permissions.settingSources`·`permissions.strictMcp`·최상위 `coreToolsHost`·`useControlChannel`·`extraArgs`·`deps.onControlRequest`)을 주면 엔진 생성과 relay 생성에서 `LegacyConfigError` 다(`CLAUDE_LEGACY_FIELDS`). 옮기는 법은 [마이그레이션 가이드](../../docs/MIGRATION.md).
- 공통 칸은 [core README](../core/README.md#설정), 칸별 백엔드 차이는 [대응표](../../docs/BACKENDS.md#설정-칸).

## 다른 문서

- [백엔드 대응표](../../docs/BACKENDS.md) · [testing README](../testing/README.md#가짜-claude-cli) — 가짜 CLI `fakeClaudeSpawn`

# @agent-relay-engine/core

백엔드와 무관한 공통 계약을 담는다: `Engine`·`EngineEvent`·`EngineConfig`, 프로세스 상한을 거는 풀, 세션마다 백엔드를 고르는 relay 엔진, 승인·질문·세션 기록을 나르는 사이드 채널, 프로젝트 정책 파일. core 는 어떤 백엔드도 알지 않는다. 엔진 구현은 [`@agent-relay-engine/claude`](../claude/README.md)·[`@agent-relay-engine/codex`](../codex/README.md) 가 이 계약대로 한다.

## 가장 짧은 예제

```ts check
import { createEnginePool, createEventTap, createSideChannel } from '@agent-relay-engine/core';
import { claudeProfiles, createClaudeEngine } from '@agent-relay-engine/claude';
import { withAskServer } from '@agent-relay-engine/ask';
import { FsSideStore } from '@agent-relay-engine/side-fs';

const sideRoot = '.agent-relay-engine/my-tool';
const side = createSideChannel(new FsSideStore(sideRoot), 'my-tool');
const config = withAskServer({ ...claudeProfiles.conversation, cwd: './work', namespace: 'my-tool' }, { sideRoot });
const tap = createEventTap();
const engine = createClaudeEngine(config, { side, onEvent: tap.push });
const pool = createEnginePool(engine, { maxProcesses: 3, tap });

for await (const ev of pool.engine.turn('3f1c0d4e-8a8f-4e4b-9a57-2b0f4f1d6c11', '안녕')) {
  if (ev.type === 'text') console.log(ev.text);
  if (ev.type === 'ask') console.log('질문:', ev.questions.map((q) => q.question));
}
```

풀을 쓰면 턴은 반드시 `pool.engine` 으로 돌린다. 원본 `engine.turn()` 은 풀 자리를 거치지 않아 `maxProcesses` 를 우회한다.

## 개념

### Engine — 세션 하나에 프로세스 하나

`Engine` 은 세션 id 하나에 CLI 프로세스 하나를 둔다. 세션 id 는 서비스가 정하고(UUID 권장), 처음 쓰는 id 면 새 대화를, 시작한 적 있는 id 면 이어 가기를 연다. 프로세스 상한·유휴 퇴출·대기는 `EnginePool` 이 맡는다.

| 멤버 | 뜻 |
|---|---|
| `turn(sessionId, input, opts?)` | 턴 하나의 `AsyncIterable<EngineEvent>`. 기록의 단일 출처 |
| `stop(sessionId, {force?})` | 2단 중지. `'control' \| 'signal' \| 'pending' \| 'none'` |
| `evict(sessionId)` | 프로세스만 내린다. 다음 턴은 같은 대화를 잇는다 |
| `forget(sessionId)` | 세션 하나를 엔진 메모리에서 잊는다(아래 [세션의 수명](#세션의-수명-evictforgetdispose)). 잊었으면 `true`, 모르는 세션이면 `false`. 진행 중이면 `ForgetError(busy)` |
| `restart?(sessionId, reason)` | 강제 재시작. 턴 중이면 `error{reason, resumable:true}` 로 끝낸다 |
| `status(sessionId)` | `SessionStatus{sessionId, started, process:'none'\|'idle'\|'busy'\|'stopping', queueDepth, lease?, usage?, awaitingPermissionSince?}` |
| `answerPermission(sessionId, requestId, decision)` | `permission` 이벤트에 답한다. `{behavior:'allow', updatedInput?}` 또는 `{behavior:'deny', message?}`. 기다리는 요청이 없으면 `false` |
| `rememberRule?(sessionId, {tool, prefix?, note?})` | "항상 허용" — 정책 파일 `remembered` 에 규칙을 더하고 다음 요청부터 재시작 없이 적용 |
| `acquire(sessionId, owner, ttlMs)` / `release(lease)` | 세션 소유권. 남의 lease 가 살아 있으면 `turn()` 은 `error(busy)` |
| `dispose()` | 모든 세션의 턴을 멈추고 프로세스를 내린 뒤, 보낸 세션 기록 쓰기가 저장소에 닿기를 기다린다(최대 5초 더, 아래 [사이드 채널](#사이드-채널--두-층)). 뒤의 `turn()` 은 거절 |

- **`TurnInput`**: 문자열, 또는 `{content, display?, answer?, clientMessageId?, author?}`. `content` 는 text·image·document block 배열이고 `display` 는 화면 기록용이다. `clientMessageId` 로 재전송을 거른다(`ext{core.duplicate}`). 경계: `core.input` 을 냈거나 백엔드에 입력을 보낸 뒤 끝난 턴(실패·중지·강제 닫기 포함)의 id 는 기억해 재전송을 거르고, 그 전에 끝난 턴의 id 만 잊어 다시 보내면 실행된다. 예외: ask 답 턴은 답을 기록한 뒤 입력을 보낸다 — 그 사이에 끝나면 id 는 잊히지만 같은 답의 재전송은 `error(ask-mismatch)` 다. 모델이 다시 묻게 한다.
- **`TurnOptions`**: `mode`(`turn`·`inject`·`reject`), `signal`(abort = stop), `limits`·`budget`(이 턴만 덮어쓰기), `lease{token}`, `gate(signal) => Promise<release>`(시작 전에 기다릴 것), `resume`(빈 content 를 허용하고 `resumePrompt` 를 보낸다, `display:[]`), `requireToolCall`(도구 호출 없이 끝나면 `done{stopReason:'no-tool-call'}`), `model`(이 턴에만 쓰는 모델, 아래 [모델 지정](#모델-지정)), `injectFallback`(`'turn'`·`'reject'`, `mode:'inject'` 를 끼워 넣지 못할 때의 처리. 주면 `QueuePolicy.injectFallback` 보다 먼저 본다. `'reject'` 면 도는 턴이 없을 때도 새 턴으로 열지 않고 `error{reason:'busy', detail:{injectFallback:'reject'}}` 로 거절한다- **`TurnOptions`**: `mode`(`turn`·`inject`·`reject`), `signal`(abort = stop), `limits`·`budget`(이 턴만 덮어쓰기), `lease{token}`, `gate(signal) => Promise<release>`(시작 전에 기다릴 것), `resume`(빈 content 를 허용하고 `resumePrompt` 를 보낸다, `display:[]`), `requireToolCall`(도구 호출 없이 끝나면 `done{stopReason:'no-tool-call'}`), `model`(이 턴에만 쓰는 모델, 아래 [모델 지정](#모델-지정)), `injectFallback`(`'turn'`·`'reject'`, `mode:'inject'` 를 끼워 넣지 못할 때의 처리. 주면 `QueuePolicy.injectFallback` 보다 먼저 본다. `'reject'` 면 도는 턴이 없을 때도 새 턴으로 열지 않고 `error{reason:'busy', detail:{injectFallback:'reject'}}` 로 거절한다), `toolScope`(이 턴에 쓸 수 있는 도구 범위, 아래 [턴 단위 도구 범위](#턴-단위-도구-범위-toolscope)).
- **`EngineDeps`**: `side`(필수), `spawn`(가짜 CLI 주입), `clock`, `onEvent`(풀 관측 탭), `onAnswer`(ask 답 기록, 기본 `recordAnswer`), `onPermissionRequest`(도구 승인 자동 응답, [도구 승인](#도구-승인)).

#### 세션의 수명 (`evict`·`forget`·`dispose`)

- `evict(sessionId)` 는 프로세스만 내린다. 세션 상태(큐·기억한 `clientMessageId`·lease·사용량·보낸 기록 쓰기 줄)는 `dispose()` 까지 엔진 메모리에 남는다 — 턴마다 새 세션 id 로 바꾸는 소비자는 옛 세션 상태가 턴 수만큼 쌓인다.
- `forget(sessionId)` 는 세션 하나를 엔진 메모리에서 지운다. 순서: 거절 검사 → 살아 있는 프로세스를 `evict` 와 같은 경로로 내림 → 보낸 기록 쓰기가 저장소에 닿기를 기다림(`dispose()` 와 같은 상한, 합쳐 최대 5초) → 메모리의 세션 상태(유휴 퇴출 타이머·턴 문맥 기록·MCP 문맥 토큰 포함)를 지움 → `true`. relay 는 라우팅 표의 고정도, 풀(`pool.engine`)은 그 세션의 풀 기록도 지운다.
- 5초 안에 닿지 않은 쓰기는 기다리지 않고 지운다. 같은 엔진에서 같은 id 로 새로 연 세션은 기록을 읽기 전에 그 쓰기를 기다린다(잊은 때부터 최대 5초 더) — 늦게 닿은 옛 쓰기가 새 기록을 덮지 않게. 그보다 오래 멈춘 저장소의 쓰기는 뒤늦게 닿아 새 기록을 덮을 수 있다. 같은 엔진의 분기(`fork`·`consult`)도 그 id 의 기록을 읽기 전에 기다린다. relay 는 잊은 백엔드 엔진들의 늦은 쓰기를 모아, 같은 id 의 다음 턴·분기가 백엔드를 고르거나 기록을 읽기 전에 기다린다 — 다른 백엔드로 열려도 덮이지 않게. 같은 저장소를 쓰는 다른 프로세스(다른 엔진 인스턴스)는 기다리지 않는다.
- 저장소 기록은 지우지 않는다. 같은 id 로 다음 `turn()` 이 오면 엔진을 새로 띄운 것처럼 저장소에서 기록을 읽어 잇는다(Claude 는 `--resume`). 메모리에만 두는 값(`fork` 의 `overrides`)은 새로 띄운 엔진처럼 사라진다.
- **`clientMessageId` 기억도 사라진다.** 잊은 세션에 같은 `clientMessageId` 로 다시 보내면 중복으로 거르지 않고 실행한다. 세션 id 를 회전하는 소비자는 잊은 뒤에는 입력마다 새 `clientMessageId` 를 쓴다(재전송 거르기는 잊기 전까지만 믿는다).
- **lease 가 살아 있으면 잊지 않는다.** 만료되지 않은 lease(`acquire`)가 있거나 `acquire` 가 저장소를 기다리는 중이면 `ForgetError(busy, cause:'lease')` 다 — 잊으면 이 엔진의 lease 검사가 사라져 토큰 없는 턴이 돈다. 먼저 `release(lease)` 한다. 잊는 중인 세션의 `acquire` 는 저장소에 가지 않고 `null`(잡지 못함)이다.
- 거절: 진행 중 턴(신호로 끊겨 닫히는 중인 턴 포함), 큐·gate 에서 기다리는 입력, 답을 기다리는 승인 요청, 진행 중 분기(원본·대상 모두, 분기 세션의 첫 턴이 원본 큐를 붙잡은 동안 포함), 살아 있는 lease, 이미 진행 중인 `forget`, 풀 자리를 잡았거나 기다리는 세션이면 아무것도 바꾸지 않고 `ForgetError{reason:'busy', resumable:true, detail:{cause}}` 를 던진다(`cause` 는 `'turn'`·`'queued'`·`'permission'`·`'fork'`·`'lease'`·`'forgetting'`). 빈 id 는 `ForgetError(input)`, `dispose()` 뒤에는 `ForgetError(disposed)` 다.
- 잊는 동안 그 세션에 온 `turn()` 은 `error{reason:'busy', resumable:true}` → `done`, `fork()`·`consult()` 는 `ForkError(busy)`(consult 는 error → done)다. relay 도 같다 — 잊는 동안 백엔드 엔진에 턴을 넘기지 않는다. `forget` 전에 받아 두고 아직 읽지 않은 `turn()` 스트림도 잊은 뒤 읽으면 같은 `busy` 로 닫힌다(새 프로세스를 띄우지 않는다) — 다시 `turn()` 을 부르면 새 세션으로 간다.
- 분기 세션의 첫 턴은 잊는 중인 원본의 큐를 붙잡지 않고 `error{reason:'busy', resumable:true}` 로 닫힌다. 원본 큐가 이미 붙잡힌 채 잊기가 끝나 가면(내리고 비우는 사이 붙잡힘) 지우지 않고 `ForgetError(busy, cause:'fork')` 를 던진다 — 이때 프로세스는 이미 내려갔고 세션은 잊기 전처럼 남는다(다음 턴이 다시 띄운다).
- 프로세스를 내리지 못하면(신호 실패 등) 세션을 남기고 `ForgetError{reason:'internal', resumable:true}` 를 던진다(원문은 `detail.cause`). 다시 부르면 다시 내리고, 그동안은 유휴 퇴출이 다시 내린다.
- relay 는 고정된 백엔드 엔진과 전환 전 옛 백엔드 엔진(그 세션을 아는 것) 모두에서 잊는다. 잊기 전에 모두를 바꾸지 않고 미리 검사해 하나라도 거절이면 아무것도 바꾸지 않는다. 미리 검사를 지난 뒤 프로세스 내리기가 실패하면 그 오류를 던지되, 이미 잊은 엔진은 되돌리지 않는다 — 고정된 엔진에서 잊었으면 고정도 지운다. 다시 부르면 남은 엔진에서 잊는다. 미리 검사는 백엔드 엔진의 `forgetBlocked(sessionId)`(backend-kit `BaseEngine` 이 가진다)로 한다 — `Engine` 을 직접 구현한 백엔드가 이것을 두지 않으면 relay 는 미리 검사 없이 그 엔진의 `forget` 거절을 그대로 던진다(먼저 잊은 엔진은 되돌리지 않는다). relay 의 `acquire` 도 잊는 동안 `null` 이고, `release` 는 그 세션을 아는 모든 백엔드 엔진에서 놓는다(한 엔진이 실패해도 나머지에서 놓은 뒤 첫 실패를 던진다).
- `dispose()` 는 모든 세션을 내리고 기록 쓰기를 비운 뒤 엔진을 닫는다. 그 뒤의 `turn()`·`forget()` 은 거절이다.

### EngineEvent — 턴 하나의 스트림

모든 이벤트에 `Envelope{turnId, sessionId, parent?, sourceId?, at}` 가 붙는다. 실행된 턴은 `started` 로 시작해 `done` 하나로 끝난다. 실행되지 않은 턴(busy·취소·입력 오류)은 `started` 없이 `error` → `done` 이다.

| type | 뜻 |
|---|---|
| `started` | 실행된 턴의 첫 이벤트. `backend`·`protocol`·`model`·`resumed`·`forked?`(분기 세션의 첫 턴에만 `true`, 아래 [세션 분기](#세션-분기와-물어보기-forkconsult))·`permissions`·`capabilities`·`mcpServers`·`tools?`(그 턴에 백엔드가 알린 도구 이름 원문 — Claude 는 init `tools`, Codex 는 싣지 않는다. 지연 로드 도구는 빠질 수 있다. 서버 쪽 판정·기록용이라 브라우저로 넘길 때는 뺀다, 1.8.8) |
| `accepted` | 입력이 백엔드에 들어갔다는 ack(`accepted-ack` 일 때). `mode` 가 실제 처리 방식 |
| `text-delta` / `text` | 조각 / 완성본. 둘 다 온다. 기록에는 `text` 만 남긴다 |
| `thinking-delta` | 추론 조각(`thinking` 일 때) |
| `tool-start` / `tool` | 도구 호출 시작 / 결과(`parsed`, `isError`). `name` 은 백엔드 어휘의 이름, `kind` 는 공통 분류(`shell·edit·read·search·web·mcp·agent·other`), `server` 는 `mcpServers` 의 키, `originalName?` 은 등록한 원래 이름 |
| `ask` | 질문 카드(`askId`, `questions` 1~4개, `confirm`, `requesters?`). 곧 `done(ask)`. 답은 다음 턴의 `TurnInput.answer = {askId, answers:[{labels, other?}]}` |
| `permission` | 도구 승인 요청(`requestId`, `toolName`, `toolUseId?`, `input`, `expiresAt?`, `displayName?`, `suggestions?`, `requesters?`). 답할 때까지 턴이 멈춘다 |

`permission`·`ask` 의 `requesters?: string[]` 는 그 턴의 요청자다(`TurnContext.requesters` 와 같은 값, [보낸 사람과 턴의 요청자](#보낸-사람과-턴의-요청자)). 누가 승인·답할 수 있는지 정하는 재료다. 승인이 서브에이전트 안에서 나와도 그 턴의 요청자다. 이벤트를 낸 시점의 값이라, 그 뒤 끼워 넣기로 들어온 사람은 다음 이벤트부터 실린다. 요청자가 없으면 칸이 없다. 정책은 엔진이 정하지 않는다(chat-server 의 `authorizeAction` 처럼 소비자가 판단한다).
| `progress` | 출력 없이 살아 있다는 신호 |
| `usage` | 토큰·비용·구독 사용률. `inputTokens` 는 캐시 읽기를 뺀 입력, 캐시 읽기는 `cacheReadTokens`. `costUsd` 는 그 턴의 비용이다 — 백엔드가 턴 값을 낸다(Claude 백엔드는 CLI 세션 누계의 차이로 구한다). `SessionStatus.usage` 는 턴 값의 합이다 |
| `queued` | 엔진 큐에 들어갔다(`position`) |
| `interrupted` | 중지됨(`via: control \| signal`) |
| `error` | `reason`(`ErrorReason`)·`resumable`·`detail?`. 사유별 resumable 기본은 `ErrorReason` 의 JSDoc. `disposed` 는 받아들이기 전 거절(이미 정리된 엔진에 연 턴)이면 `false`, 받아들인 뒤 거둔 입력(기록 읽기·gate·큐를 기다리다 `dispose()` 로 거둠, 세션 정리로 정리된 큐의 거절)이면 `true` 다 — 돌지 않은 입력이라 새 엔진·다시 연 세션에 그대로 보내도 된다 |
| `done` | 마지막 이벤트. `stopReason: end_turn \| ask \| interrupted \| error \| budget \| no-tool-call`, `toolCalls?` |
| `ext` | `ns` + `payload`. `core.*` 는 예약이다(`CORE_EXT`·`CoreExtPayloads`, 좁히기는 `isCoreExt(ev, CORE_EXT.restart)`) |

**`core.*` ext 가운데 턴의 상태를 알리는 것**

| ns | payload | 언제 |
|---|---|---|
| `core.empty_turn` | `{thinking: boolean}` | 정상으로 끝났는데(`done.stopReason` 이 `end_turn`·`no-tool-call`) 보이는 출력이 하나도 없던 턴. `done` 바로 앞에 온다 |
| `core.config` | `{warning, fields}`·`{warning:'resolve-failed', error, cause?}`(`error` 는 고정 문구, 훅의 원문은 `cause`)·`{warning:'prefer-field', fields, use}`·`{warning:'mcp-not-connected', servers:[{name, status}]}`·`{warning:'outer-session-stripped', vars}`·`{warning:'mcp-env-argv', server, keys, reason}` | 설정 경고. `ignored`·`unsupported`(쓰지 못한 칸), `unverified`(확인하지 못한 보장), `mcp-not-connected`(넘긴 MCP 서버가 붙지 않았다), `outer-session-stripped`(CLI 자식 env 에서 지운 바깥 세션 변수 이름, [자식 환경](#자식-환경)), `mcp-env-argv`(Codex: stdio 서버 env 키가 env 로 옮겨지지 않고 인자에 남았다, `reason:'conflict'|'reserved'|'invalid'`, 키 이름만), `unknown-tools`(Claude: `claude.builtinTools` `{allow}` 에 엔진이 모르는 이름, `{warning, fields, tools}`, 1.8.8) |

- **`core.empty_turn`.** 보이는 출력은 최상위의 `text`·`text-delta`(빈 문자열·공백만인 것은 뺀다), `tool-start`·`tool`, `permission`, `ask` 다. 서브에이전트 안의 출력은 세지 않는다. `thinking` 은 그 턴에 추론이 있었는지다. 중지·오류·시간 상한·예산·ask 로 닫은 턴에는 오지 않는다. 도구가 붙지 않아 모델이 생각만 하고 끝낸 턴을 "성공"으로 넘기지 않게 하려는 신호다 — 받으면 재시도하거나 사람에게 알린다.
- 그 밖의 `core.*` 이름과 payload 는 `CORE_EXT`·`CoreExtPayloads` 의 JSDoc 에 있다.

**`error` 의 `message` 와 `detail` (1.7.0)**

`message` 는 화면에 그대로 보여도 되는 글이다. 기록 저장소·채팅 서버가 그대로 남기고 내보낸다. 그래서 엔진 밖에서 온 글은 `message` 에 싣지 않고 `detail` 에 둔다.

- **`message` 에 싣는 것.** 엔진이 정한 고정 문구(`'시작 전 대기 실패'`, `'세션 설정 실패'`, `'백엔드를 고르지 못했다'`, `'세션을 다른 소유자가 잡고 있다'`, `'턴을 처리하다 예상하지 못한 오류가 났다'` 등)와 엔진이 만든 입력·설정 검사 문구다. 다만 소비자 훅이 돌려준 값(`resolveSession` 결과)이나 `fork` 의 `overrides` 를 검사한 글은 칸 이름 같은 소비자 값이 섞이므로 `message` 는 고정 문구(`'세션 설정 실패'`, `'fork 옵션 overrides 가 틀렸다'`)이고 검사 글은 `detail.cause` 다(1.8.1). 업스트림(CLI·모델 공급자)이 사용자에게 보여 주려고 만든 오류 글(Claude `cli-error` 의 결과 글, Codex 의 턴 실패 글)도 그대로 싣는다.
- **`detail` 로 가는 것.** 소비자 훅(`resolveSession`·`gate`·`onAnswer` 등)이나 하위 프로세스·RPC·파일 시스템이 던진 예외 글은 `detail.cause`, 세션을 잡은 소유자 이름은 `detail.owner`, CLI stderr 의 마지막 줄은 `detail.stderrLine`(끝부분 전체는 지금처럼 `detail.stderrTail`)이다. 기존 `detail` 칸은 그대로이고 이 칸들을 더했다.
- `detail` 은 서버 쪽 진단 몫이다. 화면에 내보내지 않는다(chat-server 는 `error` 항목·SSE 에 `detail` 을 싣지 않는다).

**소비자 규칙**

1. **모르는 것은 무시한다.** 모르는 `type`·`ext.ns` 가 와도 실패하지 않는다. `started.protocol.major` 가 다르면 그 턴을 쓰지 않는다.
2. **기록은 `turn()` 스트림에서만.** `pool.events()` 는 관측 전용이라 drop·중복이 있다. `RecordFn` 타입이 관측 이벤트를 컴파일 시점에 거부한다.
3. **`text` 만 저장한다.** `text-delta` 는 화면용이다.
4. **턴의 끝은 `done` 하나다.** `ext{core.duplicate}`·`ext{core.coalesced}` 는 단독으로 오고 `done` 이 없다.
5. **capability 로 UI 를 고른다.** `accepted-ack` 가 없으면 "보냄"까지만 표시하고, `inject` 가 없으면 끼워 넣기가 큐잉으로 떨어질 수 있다. `permission-edit-input` 이 없으면 바꾼 `updatedInput` 은 거절된다. `turn-tool-scope` 가 없으면 `TurnOptions.toolScope` 의 `'all'` 밖 값은 `error(config)` 다. `session-fork` 가 있으면 `fork`·`consult` 를 쓸 수 있다. 실측으로 바뀌면 `ext{core.capabilities}` 가 온다.
6. **sessionId 는 UUID 를 권장한다.** 아무 문자열이나 되고, 이벤트·기록에는 준 id 가 그대로 간다.

### EngineConfig — 공통 칸 + 백엔드 칸

공통 칸은 아래 [설정](#설정) 표다. 백엔드 칸(`claude.*`·`codex.*`)은 core 에 없다. core 는 빈 확장 지점 `BackendOptionsMap` 만 두고, 백엔드 패키지를 가져오면 선언 병합으로 그 칸이 `EngineConfig` 에 생긴다. 지운 설정 칸을 주면 엔진 생성에서 `LegacyConfigError`(새 위치 안내)다.

### 풀 — 프로세스 상한

`createEnginePool(engine, {maxProcesses, evictIdleMs?, tap?, metrics?, clock?, onQueued?})`.

| 멤버 | 뜻 |
|---|---|
| `engine` | 원본과 같은 `Engine`. `turn()` 이 풀 자리를 `gate` 로 걸어 풀 대기 중에도 `engine.stop()` 이 취소한다(`'pending'`). 나머지 메서드는 원본에 위임 |
| `turn(sessionId, input, opts?)` | `pool.engine.turn` 의 별칭 |
| `lease(sessionId, {wait?, signal?})` | 자리 하나. 꽉 차면 유휴 세션을 퇴출하고, 모두 바쁘면 대기(`wait`) 또는 `PoolBusyError` |
| `events({bufferSize?})` | 관측 전용 스트림(`observed: true`). 느린 구독자는 drop, 저장 금지 |
| `snapshot()` | `{sessions, processes, dropped}` |
| `evictIdle(olderThanMs?)` / `close()` | 유휴 정리 / 타이머 정리 |

- 엔진 큐(턴 중 들어온 입력)는 스트림의 `queued` 로, 풀 대기(자리 없음)는 `started` 앞이라 `onQueued({sessionId, position})` 로만 알린다.
- 사람의 승인을 기다리는 세션이 자리를 영원히 잡지 않게, `evictIdleMs` 를 준 풀은 `awaitingPermissionSince` 가 그보다 오래된 세션을 바쁜 중이라도 내린다(그 요청은 `reason:'evicted'` 로 취소).

### relay 엔진

`createRelayEngine(config, {...deps, backends})` 는 백엔드 설명자 목록을 받아 세션마다 쓸 수 있는 백엔드를 고른다. `RelayEngineConfig = EngineConfig & {prefer?, fallback?, detectCacheMs?}`.

- **고르기.** 세션의 첫 턴에 `resolveSession` 이 돌려준 `backend` → `prefer` → `backends` 순서대로 점검(캐시)해 쓸 수 있는 첫 백엔드를 고른다. 결과는 `SessionRecord.ext.relay = {backend, chosenAt}` 에 고정해 엔진을 다시 띄워도 같은 백엔드로 잇는다.
- **알림.** 고른 턴의 `started` 바로 뒤에 `ext{core.backend, {chosen, skipped:[{backend, reason, detail?}]}}` 를 낸다. 하나도 없으면 `started` 없이 `error{reason:'backend-unavailable', resumable:true, detail:{skipped}}` 다.
- **설정 검사.** 고를 때 그 세션의 `resolveSession` 결과를 합친 설정으로 설명자의 `validateConfig` 를 부르고, 던지면 `skipped{reason:'config'}` 로 건너뛴다. 각 백엔드 엔진에는 공통 칸과 자기 칸만 넘긴다(`stripConfig`).
- **대화 도중 전환(기본 꺼짐).** `fallback.onUsageLimit` 은 `error(usage-limit)`, `fallback.onUnavailable` 은 `error(auth)` 또는 `started` 없는 `error(exit·config)` 로 끝난 턴 뒤 그 백엔드를 다시 점검해 쓸 수 없을 때 켜진다. 실패한 턴은 그대로 끝나고, **다음 턴**이 다음 순서 백엔드의 새 대화로 열린다(이전 대화는 잃는다). 그 턴에 `ext{core.backend, {…, switched:{from, reason}, historyLost:true}}` 가 온다. 떠난 백엔드로는 되돌아가지 않는다(`skipped{reason:'session-used'}`).
- **라우팅.** `turn`·`stop`·`evict`·`restart`·`status`·`answerPermission`·`rememberRule`·`acquire`·`release` 는 세션의 백엔드 엔진으로 간다. `status()` 에 `backend` 칸이 붙는다. 풀(`createEnginePool(relay, …)`)의 상한은 백엔드를 합친 프로세스 수다.
- **relay 이전 기록.** `ext.relay` 가 없는 기록은 `ext.<이름>` 칸이 있는 백엔드, 없으면 `claimsLegacyRecord` 가 맡는 백엔드로 본다. 기록을 만든 백엔드를 `backends` 에서 빼면 판정할 수 없으니 그 백엔드도 넣거나 새 세션 id 를 쓴다.

**점검 `detectBackends(backends, opts?)`.** 세션을 띄우지 않고 모델 턴·구독 사용량을 쓰지 않는다. 병렬로 돌고 백엔드마다 `timeoutMs`(기본 10초)를 지킨다. 결과는 설명자 + (cwd, 그 백엔드 칸, `permissions.auth`, `inheritOuterSession`, `timeoutMs`)별로 `cacheMs`(기본 60초) 캐시하고(일시 실패 `timeout`·`command-failed` 는 5초) `{fresh:true}` 면 다시 본다. `BackendStatus{backend, available, reason?, detail?, version?, protocol?, auth?, usage?, checkedAt}` 이고 `reason` 은 `not-installed`·`not-logged-in`·`not-subscription`·`unsupported-version`·`command-failed`·`timeout` 이다. 백엔드별 점검 방법은 [백엔드 대응표](../../docs/BACKENDS.md#점검).

### 사이드 채널 — 두 층

아래층 `SideStore` 는 `get/put/consume/delete/watch` 다섯 개의 범용 저장소이고 `consume` 은 원자적이다(두 번째 호출은 null). 위층 `SideChannel` 은 용도별 API(`approvals`·`secrets`·`sessions`·`artifacts`)로 키 규약을 정한다. 모든 키는 `namespace` 아래에 놓여 같은 저장소를 쓰는 툴 둘이 충돌하지 않는다. 엔진과 ask 서버는 같은 저장소를 봐야 한다.

- 구현: `MemorySideStore`(core, 한 프로세스), `FsSideStore`([side-fs](../side-fs/README.md), 여러 프로세스).
- `createSideChannel(store, namespace)`. 비밀은 인자·환경 변수 대신 `side.secrets.issue(name, value, ttlMs)` 로 넘기고 소비 쪽이 `redeem` 한다.
- 다른 저장소 구현은 testing 의 `sideStoreContractSuite`·`sideChannelContractSuite` 를 통과해야 한다.
- `sessions.patch` 는 최상위 칸을 덮되 `ext` 는 **키 단위로 합친다**. 백엔드 칸(`ext.claude`·`ext.codex`)·relay(`ext.relay`)·분기(`ext.fork`)가 한 기록을 나눠 쓰므로, `SideChannel` 을 직접 만들면 이 규칙을 지켜야 한다 — 아니면 분기 범위가 다른 칸의 patch 에 지워진다.
- **같은 세션의 기록 쓰기는 부른 순서대로 저장소에 보낸다.** 엔진이 턴 중에 남기는 세션 기록(턴 수·사용량·백엔드의 resume 근거)은 앞 `sessions.patch` 가 끝난 뒤 다음을 보낸다. 쓰기 하나는 앞 쓰기를 보낸 뒤 5초까지만 기다리고 다음을 보낸다. 그 경우 멈췄던 쓰기가 뒤늦게 닿아 뒤 쓰기를 덮을 수 있다. 저장소가 그 5초보다 오래 멈추는 환경이면 늦게 받은 patch 가 앞 patch 를 덮지 않게(예: `lastUsedAt` 이 저장된 값보다 작으면 버리기) 직접 만든 `SideChannel` 에서 막는다. 같은 ms 에 쓴 두 기록은 `lastUsedAt` 이 같아 이 비교로 순서를 가리지 못한다.
- **기록 실패·지연과 턴.** 기록 실패는 턴을 실패로 만들지 않는다. 턴 수·사용량 기록과 백엔드의 resume 근거(claude 의 시작·되돌림·분기 id·닫힌 분기 표지, codex 의 스레드 기록)는 줄에 넣고 완료를 기다리지 않아, 저장소가 멈춰도 턴은 진행한다. 저장소에 남은 뒤에 돌아가야 하는 쓰기(claude·codex 의 `fork()` 등)는 그 쓰기를 기다리므로 저장소가 멈추면 함께 멈춘다.
- **정리한 세션의 기록은 되살아나지 않는다.** `consult` 의 분기 세션·실패한 분기처럼 엔진이 정리하며 기록을 지우는 세션은, 지우기 전에 그 세션의 쓰기를 멈추고 이미 보낸 쓰기를 5초까지 기다린 뒤 `sessions.delete` 를 부른다. 그 뒤의 쓰기는 보내지 않는다. 5초보다 오래 멈춘 쓰기는 지운 뒤에 닿을 수 있다.
- **`dispose()` 는 보낸 기록 쓰기를 비운 뒤 끝난다.** 세션마다 턴을 멈추고 프로세스를 내린 뒤(그 정리가 남긴 마지막 사용량·누계 기록까지) 보낸 쓰기가 저장소에 닿기를 기다린다. 세션들을 함께 기다리므로 더 걸리는 시간은 세션 수와 상관없이 최대 5초다. 그보다 오래 멈춘 쓰기는 기다리지 않고 끝난다 — 그 쓰기는 호스트 프로세스가 살아 있으면 뒤늦게 닿고, 바로 끝나면 잃는다. 그래서 `SIGTERM` 을 받아 `await engine.dispose()` 뒤 끝나는 호스트는 마지막 턴의 기록(턴 수·사용량·Claude 의 `ext.claude.cliCostUsd`)을 잃지 않고, 다시 띄운 엔진의 첫 턴이 낡은 기록을 읽지 않는다. `evict()`·유휴 정리는 프로세스만 내리고 세션(과 그 쓰기 줄)은 엔진에 남으므로 기록을 잃지 않는다 — 다음 턴이 그 쓰기를 기다린 뒤 기록을 읽고, `dispose()` 가 비운다. `forget()` 은 같은 상한으로 그 세션의 쓰기를 비운 뒤 세션을 지운다([세션의 수명](#세션의-수명-evictforgetdispose)).
- **`dispose()` 뒤에 나가는 기록.** 정리 상한을 넘겨 강제로 닫힌 턴이나 늦게 닫힌 프로세스가 `dispose()` 뒤에 남기는 기록은 비우기에 들지 않는다 — 호스트가 바로 끝나면 잃는다. 이 늦은 기록과 5초 상한을 넘겨 줄에 남은 쓰기는 같은 저장소로 다시 띄운 엔진의 기록을 덮을 수 있다. 같은 호스트에서 엔진을 다시 띄우면 옛 엔진의 `dispose()` 를 기다린 뒤 띄운다 — 그래도 저장소가 5초 넘게 멈췄거나 강제로 닫힌 턴이 있으면 덮일 수 있는 창이 남는다. 한 세션의 정리가 던지면 `dispose()` 는 다른 세션을 끝까지 정리·비운 뒤 세션 순서로 첫 오류를 던진다(나머지 오류는 버린다).
- 기록을 읽지 못하면(저장소 장애) 엔진은 그 세션을 새 세션으로 보지 않는다. 그 턴은 `error{reason:'internal', resumable:true}` 이고 다시 보내면 다시 읽는다. `fork` 는 `ForkError(internal)` 다.

### ask 와 승인 바인딩

ask 도구(`mcp__core__ask`, [ask](../ask/README.md))가 질문을 사이드 채널에 기록하면 엔진은 그 결과를 보는 즉시 `ask` → `done(ask)` 로 턴을 닫는다. 답은 다음 턴의 `TurnInput.answer` 로 보낸다. 엔진은 답이 마지막 질문의 것인지 확인하고(아니면 `error(ask-mismatch)`), `confirm:true` 질문에서 `kind:'approve'` 선택지 하나만 골랐을 때만 승인을 기록한다. 승인은 askId + 도구명 + 인자 해시에 묶이고, 툴 서버는 `requireApproval` 로 한 번만 소비한다. 일반 메시지가 오면 지난 승인은 무효가 된다.

```ts check
import { requireApproval, type CoreToolContext } from '@agent-relay-engine/core';

export async function deploy(ctx: CoreToolContext, args: { target: string; confirm?: string }) {
  const ok = await requireApproval(ctx, { tool: 'mcp__tool__deploy', args, confirm: args.confirm });
  if (!ok.ok) return { isError: true, content: [{ type: 'text' as const, text: ok.message }] };
  return { content: [{ type: 'text' as const, text: `${args.target} 배포 시작` }] };
}
```

직접 만든 이벤트·기록은 `askQuestions(ev)`, 답은 `answerList(answer)` 로 읽는다.

### 도구 승인

승인이 필요한 도구를 어떻게 묻는지는 `permissions.approval` 이 정한다.

| approval | 동작 |
|---|---|
| `'none'`(기본) | 사람에게 묻지 않고 거부한다. 막힌 호출은 `ext{core.permission_denied, {items:[{toolName, toolUseId, toolInput}]}}` 로 온다 |
| `{kind:'control'}` | 턴 스트림에 `permission` 이벤트를 내고, 소비자가 `answerPermission` 으로 답한다. `permissions.mode` 가 `'dontAsk'`(기본)면 어느 백엔드도 묻지 않고 거부해 `permission` 이 오지 않는다(Codex 는 `plan` 도 그렇다). Claude 는 `core.config{warning:'approval-mode'}` 를 내고, Codex 는 경고가 없다. Claude 에서 묻는 것을 확인한 모드는 `'default'` 다(다른 모드는 확인하지 않았다) |
| `{kind:'mcpTool', name}` | 소비자 승인 MCP 도구에 묻는다. Claude 백엔드 전용 |

**Claude 에서 control 은 `permissions.mode` 를 `'default'` 로 함께 줘야 한다**(묻는 것을 확인한 모드다. `auto`·`acceptEdits` 는 CLI 가 스스로 허용한 호출만 `permission` 없이 오고, 나머지 모드는 확인하지 않았다). Claude 의 기본 `mode:'dontAsk'` 에서는 CLI 가 승인을 묻지 않고 바로 거부하므로(`core.permission_denied`) `permission` 이벤트가 전혀 오지 않는다. mcpTool 은 확인하지 않았다(같은 CLI 판정으로 본다). 엔진은 모드를 몰래 바꾸지 않고, Claude 에서 이 조합이면 프로세스마다 한 번 `ext{core.config, {warning:'approval-mode', approval, mode}}` 로 알린다(세션 덮어쓰기·정책 파일 병합으로 정해진 값도 같다).

```ts check
import type { Engine } from '@agent-relay-engine/core';

export async function runWithApproval(engine: Engine, sessionId: string, ask: (tool: string, input: unknown) => Promise<boolean>) {
  for await (const ev of engine.turn(sessionId, '배포해 줘')) {
    if (ev.type !== 'permission') continue;
    const ok = await ask(ev.toolName, ev.input);
    await engine.answerPermission(sessionId, ev.requestId, ok ? { behavior: 'allow' } : { behavior: 'deny', message: '사용자가 거절했다' });
  }
}
```

- **처리 순서.** 훅 `deps.onPermissionRequest(req:{toolName, input, toolUseId?, displayName?}, ctx:{sessionId, requestId?})` → 정책 파일의 기억한 규칙 → 사전 승인 → `permission` 이벤트(사람). 훅이 결정을 돌려주면 그대로 답하고, `undefined` 면 다음 단계다. 훅이 던지면 거절한다. 이때 CLI·app-server 에는 고정 문구만 가고(도구 결과로 모델·기록에 남으므로), 훅의 원문은 `ext{core.control, {warning:'hook-error', subtype, requestId, cause}}` 와 metric `control.hook_error` 로만 알린다(1.7.0). `ctx.requestId` 는 그 호출이 판정하는 요청의 id 로, 같은 요청의 `permission` 이벤트·`core.permission_decided` 의 `requestId` 와 같다(1.8.10). Claude·Codex 는 항상 준다. 훅의 판정 기록과 결정 알림을 이 값으로 잇는다. 주지 않는 엔진(옛 엔진·직접 만든 엔진)도 있어 선택 칸이다.
- **두 시한.** 훅은 `limits.controlRequestMs`(기본 30초) 안에 답해야 한다. 사람은 `limits.permissionAnswerMs` 를 따르고 **기본은 무제한**이다. 주면 `permission.expiresAt` 이 붙고 넘기면 모델에게 "같은 도구를 바로 다시 시도하지 말라"는 거절을 보낸다. 시간 초과면 `ext{core.control, {warning:'request-timeout'}}` 다.
- **답 없이 끝난 요청**은 `ext{core.permission_cancelled, {requestId, toolName, reason}}` 로 온다. `reason` 은 `timeout`·`turn-ended`·`stopped`·`disposed`·`evicted` 다. 소비자는 이 requestId 로 카드를 닫는다.
- **사전 승인.** `answerPermission` 이 `false` 인(요청이 이미 사라진) 허용 답은 `recordPreapproval(side, {sessionId, toolName, input})` 로 남길 수 있다. 같은 도구·같은 인자의 다음 요청을 카드 없이 허용하고 `ext{core.permission_preapproved}` 를 낸다. 일회성이고 `PREAPPROVAL_TTL_MS`(1시간) 뒤 만료다.
- 답을 기다리는 동안 무응답 상한(`idleMs`)은 세지 않는다. `totalMs` 는 센다.
- **결정 알림.** 엔진이 승인 요청에 답을 백엔드로 보낼 때마다 `ext{core.permission_decided, {requestId, toolName, behavior, at, via, toolUseId?}}` 를 한 번 낸다. `behavior` 는 실제로 보낸 답(`'allow'`·`'deny'`), `at` 은 확정한 시각(epoch ms)이다. `toolUseId` 는 같은 요청의 `permission` 이벤트·훅 요청의 `toolUseId` 와 같은 값이고, 백엔드가 문자열로 주지 않았으면 칸이 없다(1.8.10). 훅·규칙·사전 승인·시간 초과·정책 거절 등 어느 경로든 같다. 감사 기록을 잇는 주 열쇠는 `requestId`(훅의 `ctx.requestId`)다. `toolUseId` 는 보조 열쇠다 — 백엔드가 준 값이라 빈 문자열일 수 있고, Codex MCP 승인은 요청에 그 칸이 없어 같은 서버(안내 문구에 도구 이름이 있으면 같은 도구)의 살아 있는 호출에서 추정한 값이다(하나로 정해지지 않으면 없다). 도구 입력·훅 원문은 싣지 않는다. 감사 기록용이다.
- **진 결정(`overridden`, 1.8.11).** 엔진이 받은 답과 실제로 보낸 답이 다르면 결정 알림에 `overridden: {behavior, via}` 가 붙는다 — 받았지만 진 결정이다. 예: 사람이 허용했는데(`answerPermission` 이 `true`) 그 사이 프로세스가 실패로 내려가는 중이거나 끼워 넣기로 도구 범위가 좁아져 엔진이 거절했다면 `{behavior:'deny', via:'policy', overridden:{behavior:'allow', via:'human'}}`. 훅·기억한 규칙·사전 승인의 허용이 진 경우도 같다(`via` 가 그 주체). Codex 가 바뀐 `updatedInput` 을 거절할 때도 같다. 받은 답과 보낸 답이 같으면 칸이 없다. 엔진은 허용을 거절로 바꾸기만 하고 거절을 허용으로 바꾸지 않는다.

  | `via` | 정한 것 |
  |---|---|
  | `human` | 소비자의 `answerPermission` |
  | `hook` | `onPermissionRequest` 훅의 답. 훅이 던져서 거절한 것도 여기다 |
  | `rule` | 설정 규칙: 기억한 규칙, Codex 의 `acceptEdits`·`allowedTools`·`disallowedTools` 대조 |
  | `preapproved` | 사전 승인(`recordPreapproval`) |
  | `policy` | 엔진 정책: `toolScope` 자동 거절, 도구 상한(budget) 중 거절, 승인 창 없음(Codex `approval` 이 control 이 아님). 정한 주체의 답을 엔진이 바꿔 보냈을 때(기다리는 사이 범위가 좁아짐, Codex 가 받지 못하는 `updatedInput`)도 `policy` 이고 `behavior` 는 `'deny'` 다 |
  | `timeout` | 훅(`controlRequestMs`)이나 사람(`permissionAnswerMs`)이 상한 안에 답하지 않았다 |

  `core.permission_cancelled` 와의 관계: `cancelled` 는 카드를 닫는 신호다. 사람 상한 초과는 `decided{via:'timeout'}` 와 `cancelled{reason:'timeout'}` 이 함께 온다. 턴 끝·중지·퇴출·dispose 로 거둔 요청은 `cancelled` 만 온다(결정이 아니다). 백엔드가 묻지 않고 스스로 허용한 도구(Claude 의 Read·`allowedTools`·`mode` 로 허용한 호출 등)는 승인 요청이 없으므로 이 이벤트도 없다. 닫힌 턴(소비자 스트림이 끝난 뒤)에 정해진 결정은 받을 스트림이 없어 내지 않는다. Claude 는 답을 CLI 에 쓴 뒤에 내고 쓰지 못하면(프로세스가 죽음) 내지 않는다. Codex 는 답을 app-server 로 돌려주기 직전에 낸다.

### 프로젝트 정책 파일

엔진은 `<cwd>/.agent-relay-engine/policy.json`(`policy.path` 로 바꾸고 `policy.enabled:false` 로 끈다)을 읽어 `permissions` 와 합친다. 사람이 편집하고 커밋하는 파일이다.

`started.permissions.policy` 는 이 턴에 적용된 정책 파일 상태다: `{enabled: boolean, path?: string}`. `path` 는 세션 cwd 기준으로 푼 절대 경로이고, `enabled:false` 면 `path` 가 없다. 파일이 없어도 `enabled:true` 다(켜져 있고 읽을 파일이 없을 뿐). Claude·Codex 가 같은 값을 싣는다. `path` 는 서버의 절대 경로이므로 클라이언트(브라우저 등)로 그대로 넘기지 않는다. `policy.enabled:false` 가 실제로 적용됐는지 확인하는 칸이다.

```json
{
  "mode": "acceptEdits",
  "allowedTools": ["Read", "Bash(git status *)"],
  "disallowedTools": ["Bash(rm *)", "WebFetch"],
  "remembered": [
    { "tool": "Bash", "prefix": "npm", "addedAt": 1793000000000, "note": "카드에서 항상 허용" }
  ]
}
```

- **우선순위.** 파일이 설정보다 높다. `mode` 는 파일 값이 덮고, 목록은 설정 뒤에 파일 쪽을 합집합으로 붙인다(`mergePolicy`). 모르는 칸은 읽고 쓸 때 보존한다.
- **검증.** `mode:'bypassPermissions'` 는 거부한다. 엔진을 만들 때 파일이 틀리면 `PolicyError` 로 던진다. 실행 중 고친 파일이 틀리면 앞의 값을 그대로 쓰고 `ext{core.policy, {warning:'invalid', error}}` 를 한 번 낸다. 이때 `remembered` 는 비운다.
- **변경 감지.** `mode`·목록이 바뀌면 다음 턴 전에 다시 띄우고 `ext{core.restart, {reason:'policy-changed'}}`. `remembered` 만 바뀌면 다시 띄우지 않는다.
- **기억한 규칙.** `{tool, prefix?}` 에 맞는 요청은 카드 없이 허용하고 `ext{core.permission_rule, {requestId, toolName, toolUseId?, rule, via?}}` 를 낸다. Bash 규칙은 명령을 `&&`·`||`·`;`·`|`·`&` 로 나눈 실행 단위마다 접두로 공백 경계까지 맞아야 한다. 명령 치환·리디렉션·괄호·중괄호·여러 줄은 맞추지 않고 사람에게 묻는다.
- **안전 규칙.** allow 만 기억한다. prefix 없는 Bash 규칙, `*`·래퍼(`bash`·`sh`·`env`·`sudo`·`xargs`·`eval` 등)·환경 변수 대입으로 시작하는 규칙은 거부한다.
- **도우미.** `suggestRulePrefix(command)`, `ruleLabel(rule)`(`Bash(npm *)` 표기), `matchRule`, `opensAllBash`, `unwrapShell`(셸 래퍼 벗기기).

### 세션별 설정 (`resolveSession`)

엔진 하나·풀 하나로 범위마다 다른 MCP 서버·도구·프롬프트를 쓴다. 훅은 spawn 과 매 턴 시작 전에 `{sessionId, record?, turnId?, signal?}` 로 불린다.

```ts check
import { createSideChannel, MemorySideStore } from '@agent-relay-engine/core';
import { createClaudeEngine } from '@agent-relay-engine/claude';

const PROMPTS: Record<string, string> = { writer: '글을 다듬는다', reviewer: '글을 검토한다' };
const engine = createClaudeEngine({
  cwd: '/srv/app', namespace: 'app',
  mcpServers: { app: { command: 'node', args: ['bin.js'] } },
  resolveSession: ({ record }) => {
    const scope = String(record?.ext?.scope ?? 'writer');
    return { systemPrompt: PROMPTS[scope], mcpArgs: ['--scope', scope], budget: { perSession: { turns: 100 } } };
  },
}, { side: createSideChannel(new MemorySideStore(), 'app') });
```

- **덮을 수 있는 칸**: `mcpServers`·`systemPrompt`(문자열)·`permissions`(`allowedTools`·`disallowedTools`·`mode`)·`cwd`·`mcpArgs`(문자열 배열)·`budget`(`perTurn`·`perSession`)·`model`(세션 기본 모델, 아래 [모델 지정](#모델-지정))·`mcpContext`(턴 문맥의 세션 기본값, 아래 [MCP 서버에서 턴 문맥 읽기](#mcp-서버에서-턴-문맥-읽기)). relay 는 `backend` 도 읽는다. 백엔드 패키지가 `BackendSessionOverridesMap` 으로 연 백엔드 이름 칸(예: Claude 의 `claude.argFiles`, 1.8.1)은 그 백엔드 엔진만 받는다 — relay 는 각 백엔드 엔진에 자기 이름 칸만 넘긴다. 그 밖의 칸은 `error(config)`.
- **합치기**: `mcpServers` 는 맵 통째로, `mcpArgs` 는 엔진 `mcpArgs(ctx)` 출력 대신, `permissions` 는 세 칸 각각, `budget` 은 키별로 바꾼다. `coreToolsSpec` 은 세션 서버에도 합쳐진다.
- **변경 감지**: 기동 지문(cwd·서버·권한 세 칸·mcpArgs)이 띄운 프로세스와 다르면 턴 사이에 다시 띄우고 `ext{core.restart, {reason:'config-changed'}}`.
- **실패**: 훅이 던지거나 검증에 걸리거나 `RESOLVE_SESSION_TIMEOUT_MS`(10초) 안에 답하지 않으면 그 턴은 `started` 없이 `error{reason:'config', resumable:true}` 다. `message` 는 늘 `'세션 설정 실패'` 이고 훅의 글·검사 글은 `detail.cause` 다(1.8.1 — 검사 글에 칸 이름 같은 소비자 값이 섞인다).
- **비동기**: 훅은 `Promise` 를 돌려도 된다. 저장소에서 프롬프트 재료를 턴마다 읽으려면 `resolveSession: async (ctx) => ({ systemPrompt: await loadPrompt(ctx) })` 처럼 쓴다. `EngineConfig.systemPrompt` 의 함수 형태는 동기만 받는다.
- **턴 id 와 중지 신호**(1.8.6): `ctx.turnId` 는 이 설정을 쓰는 턴의 id 로 그 턴 이벤트(`started` 등)의 `turnId` 와 같다. `ctx.signal` 은 그 턴이 `stop()`·강제 닫기·정리로 끝나거나 10초 상한(`RESOLVE_SESSION_TIMEOUT_MS`)을 넘겨 이 설정을 더는 쓰지 않게 되면 abort 한다. `signal.reason` 은 문자열 `'stopped'`(중지·강제 닫기·정리) 또는 `'timeout'`(상한 초과)이다. DB·외부 호출에 `fetch(url, { signal: ctx.signal })` 처럼 넘기면 턴이 끊긴 뒤에도 조회가 도는 것을 막는다. 훅이 값을 돌려준 뒤에는 abort 하지 않는다. 턴 안에서는 위 어느 길로 턴이 끊겨도(시작 전 대기 중이어도) 바로 abort 한다. 훅을 기다리던 턴은 설정 오류(`error{config}`)가 아니라 끊긴 대로(`interrupted{signal}`, 강제 재시작이면 그 오류) 닫힌다. 턴 밖에서 부르는 경로는 `turnId` 가 없다: Codex 의 분기 세션 열기는 `consult` 에 준 `signal` 이 abort 되거나 상한을 넘기면, `remember` 의 규칙 저장은 상한을 넘길 때만 abort 한다. relay 의 백엔드 고르기에서 부르는 훅은 `turnId`·`signal` 이 없고 10초 상한도 없다(고르기는 세션마다 한 번 돌아 여러 턴이 함께 기다리므로 한 턴의 신호로 끊지 않는다).
- **결정적이어야 한다**: 같은 세션에는 같은 값을 돌려준다. 매번 다른 값이면 턴마다 다시 띄운다. 이미 시작한 세션의 `cwd` 는 바꾸지 않는다.

### 모델 지정

모델은 세 단계로 정하고 앞의 것이 이긴다. 셋 다 없으면 백엔드 기본 모델이다. 엔진 하나로 세션·턴마다 다른 모델을 쓸 수 있다.

1. `TurnOptions.model` — 이 턴에만 쓴다. 다음 턴에 주지 않으면 아래 단계로 돌아간다.
2. `SessionOverrides.model` — `resolveSession` 이 준 세션 기본값.
3. `EngineConfig.model`

```ts check
import type { Engine } from '@agent-relay-engine/core';

declare const engine: Engine;
// 이 턴만 큰 모델로. 다음 턴은 세션·엔진 기본으로 돌아간다
for await (const ev of engine.turn('s1', '설계를 검토해 줘', { model: 'opus' })) {
  if (ev.type === 'started') console.log(ev.model);
}
```

- **대화는 이어진다.** 모델을 바꿔도 같은 세션의 기록과 문맥을 유지한다.
- **실제로 쓴 모델**은 `started.model` 이다. 살아 있는 프로세스의 모델을 바꿨으면 그 턴 `started` 뒤에 `ext{core.model, {model?, via}}` 가 온다. `via` 는 `'control'`(프로세스를 둔 채 바꿨다)·`'restart'`(같은 대화로 다시 띄웠다)·`'turn'`(턴 요청에 실었다)이다. `model` 은 백엔드가 알려 준 이름이고, 백엔드 기본으로 돌아가 이름을 모르면 없다. 세션이 시작 전이거나 프로세스가 내려가 있었으면 그 모델로 띄우기만 하고 알리지 않는다.
- **이미 그 모델이면 아무것도 하지 않는다.** 신호도 없다.
- **턴 사이에만 바꾼다.** 끼워 넣기(`mode:'inject'`)로 들어간 입력에 다른 `model` 을 주면 바꾸지 않고 `ext{core.model, {warning:'ignored-inject', model}}` 을 낸다.
- **세션 모델이 바뀌어도** `core.restart{config-changed}` 가 아니라 위 규칙으로 바꾼다.
- **틀린 이름**은 새 오류 사유가 아니다. 백엔드가 거절하면 그 백엔드의 기존 분류(Claude `cli-error`, Codex 요청 거절 등)를 따른다. `TurnOptions.model` 이 빈 문자열이면 `error(input)`, `resolveSession` 의 model 이 문자열이 아니면 `error(config)` 다.
- 백엔드마다 바꾸는 방법은 [대응표](../../docs/BACKENDS.md#모델-바꾸기)에 있다.

### MCP 서버에서 턴 문맥 읽기

stdio MCP 서버는 CLI 프로세스와 함께 살아 여러 턴을 넘긴다. 그래서 env 의 `AGENT_RELAY_ENGINE_TURN_ID` 는 서버를 띄운 첫 턴 값이고, 두 번째 턴부터는 틀린다. 도구 호출마다 그 호출의 턴 문맥은 `readTurnContext()` 로 읽는다.

```ts check
import { readTurnContext } from '@agent-relay-engine/core';

// tools/call 처리 안에서. _meta 는 요청의 params._meta 그대로 넘긴다
export async function onToolCall(request: { params: { name: string; _meta?: Record<string, unknown> } }) {
  const ctx = await readTurnContext(request.params._meta);
  if (!ctx) return { content: [{ type: 'text' as const, text: '엔진 밖에서 띄운 서버다' }] };
  const user = ctx.context?.user; // 소비자가 TurnOptions.mcpContext 로 준 값
  return { content: [{ type: 'text' as const, text: `${ctx.sessionId}/${ctx.turnId} ${String(user)}` }] };
}
```

- **값.** `TurnContext = {sessionId, turnId, invoker, scope, context?, requesters?}` 다(`requesters` 는 [보낸 사람과 턴의 요청자](#보낸-사람과-턴의-요청자)). `context` 는 `SessionOverrides.mcpContext`(세션 기본) 위에 `TurnOptions.mcpContext`(이 턴) 를 키별로 덮은 값이다. 둘 다 없으면 칸이 없다. 엔진은 값을 해석하지 않는다.
- **남기지 않는다.** 엔진은 `mcpContext` 를 디스크·로그(원시 로그 포함)·이벤트·기동 인자에 남기지 않는다. 메모리에만 두고 창구로만 준다. 원격 도구 자격 같은 비밀을 턴마다 넘겨도 된다.
- **창구.** 엔진 인스턴스마다 로컬 소켓 하나를 연다. POSIX 는 `0700` 임시 폴더 안의 Unix 도메인 소켓, Windows 는 named pipe 다. stdio 서버를 띄울 때 처음 열고 `dispose()` 에서 닫으며 폴더를 지운다(dispose 없이 프로세스가 끝나도 지우려 한다). 서버 없이 엔진만 쓰면 열지 않는다. 임시 폴더를 만들 수 없으면 알리지 않고 그대로 띄운다 — 서버는 `null` 을 받는다.
- **알리는 법.** `mcpContext` 가 `'env'`(기본)·`'both'` 면 CLI 프로세스 env 에 `AGENT_RELAY_ENGINE_CONTEXT`(소켓 경로)와 `AGENT_RELAY_ENGINE_CONTEXT_TOKEN`(세션 프로세스마다 32바이트 난수)을 싣는다(`MCP_TURN_CONTEXT_ENV`). stdio 서버가 이 env 를 물려받는다. 토큰은 기동 인자에 싣지 않는다. `'args'` 모드에는 싣지 않는다 — 그때 `readTurnContext()` 는 `null` 이다.
- **토큰.** 토큰이 세션을 정한다. 다른 세션의 문맥은 읽을 수 없다. 프로세스가 내려가면 그 토큰은 버려진다. **셸 도구도 읽을 수 있다.** 토큰은 CLI 프로세스 env 에 있어 CLI 가 띄우는 모든 자식이 물려받는다. 모델이 셸 도구(Bash 등)를 쓸 수 있는 세션이면 모델도 그 세션의 `context` 를 읽을 수 있다. 다른 세션의 값은 열리지 않는다. 비밀을 넣을 때는 셸 도구 허용과 함께 따진다.
- **조회 순서.** ① `_meta` 의 백엔드 키(대응표의 [턴 문맥 키](../../docs/BACKENDS.md#턴-문맥-키))로 그 호출의 턴을 찾는다. 엔진이 키를 아직 모르면 최대 2초 기다린다. ② 그래도 모르거나 `_meta` 가 없으면 그 세션의 지금 열린 턴이다. ③ 열린 턴도 없으면 `null` 이다. 끼워 넣기(`mode:'inject'`)는 열린 턴의 값을 쓴다.
- **실패.** env 가 없으면 `null` 이다. 창구가 거절하거나(모르는 토큰 등) `timeoutMs`(기본 3초) 안에 답이 없으면 던진다.
- **같은 프로세스의 http 서버.** 원격 http 서버는 소켓에 닿지 않는다. 엔진과 같은 프로세스에서 서버를 돌리면 `engine.turnContext(sessionId, meta?)` 로 같은 값을 얻는다(조회 순서도 같다). 원격으로 넘기는 일은 소비자 몫이다. `turnContext` 는 선택 메서드다 — 내장 엔진(claude·codex·relay·풀·메모리 엔진)은 모두 구현한다.
- **ask 서버.** `@agent-relay-engine/ask` 서버는 호출마다 창구에서 턴 id 를 읽어 질문 기록에 남긴다. 툴 서버에 ask 를 합칠 때는 `registerCoreTools(server, ctx, { turnContext: readTurnContext })` 를 준다.

### 보낸 사람과 턴의 요청자

여러 사람이 한 세션에 글을 넣는 서비스를 위한 기본 요소다. 엔진은 사람 식별자를 해석하지 않는다 — `id` 는 불투명한 문자열이고, 인증과 권한 판단은 소비자가 한다. 칸을 주지 않으면 동작·출력·CLI 로 가는 글이 지금과 글자까지 같다.

- **`TurnInput.author?: Author`**. `Author = {id: string, name?: string}`. 정규화 입력(`NormalizedInput.author`)과 기록 이벤트 `ext{core.input}` 의 payload(`author?`)에 그대로 실린다. 답 턴이면 payload 의 `answer?: {askId, author?}` 가 실제로 쓰인 답(합쳐진 턴이면 마지막 입력의 답)과 그 입력의 보낸 사람이다 — 결정 기록의 근거로 쓴다. `id` 가 비었거나 `name` 이 문자열이 아니면 `error(input)` 이다.
- **합치기.** `queue.coalesce` 로 여러 입력이 한 턴이 되면 `author` 는 머리 입력의 것이고, 합쳐진 모든 입력의 보낸 사람은 `authors: Author[]`(입력 순서, `id` 중복 없이 먼저 온 것만) 로 payload 에 실린다. `clientMessageId`·`clientMessageIds` 와 같은 방식이다. 합쳐지지 않은 턴은 `authors` 칸이 없다.
- **여러 사람의 입력을 한 턴으로: 입력 묶음.** `engine.turn(sessionId, [입력, 입력, …], opts)` 처럼 배열(`TurnInputBundle`)을 주면, 원소마다 단일 입력과 같은 정규화(author 검증·`inputAuthorFormat` 접두어·블록 정책)를 거친 뒤 큐 coalesce 와 같은 모양으로 합쳐 큐에 한 단위로 들어간다. 쉬는 세션이면 `queued` 없이 그 자리에서 한 턴, 스트림 하나다. 기록(`core.input`)의 `author`(첫 원소)·`authors`·`clientMessageIds` 와 `requesters`(턴 문맥·`permission`·`ask` 이벤트)는 큐로 합쳐진 턴과 같다. 소비자가 글을 이어 붙여 한 `TurnInput` 으로 보내면 보낸 사람이 하나만 남지만, 묶음은 모두 남는다. 도는 턴 뒤에 쌓인 묶음은 한 대기 단위이고, `queue.coalesce` 가 켜져 있으면 앞뒤 대기 입력과 순서대로 합쳐진다.
  - 비었거나 원소가 `MAX_TURN_INPUTS`(16)를 넘으면 `error(input)`. 원소 하나면 단일 입력과 같다(합친 칸이 없다). 문자열 원소도 받는다. 원소의 입력 오류는 `detail.index` 로 몇 번째인지 알린다.
  - 원소가 둘 이상이면 `answer` 를 실은 원소, 같은 `clientMessageId` 두 번, 일부 원소에만 있는 `clientMessageId` 는 `error(input)` 이다 — ask 답 권한이 다른 사람 글과 섞이지 않게, 이미 본 cmid 와 섞인 새 글이 duplicate 로 조용히 버려지지 않게 한다. 답은 따로 보낸다. `clientMessageId` 는 UTF-16 길이 200(`MAX_CLIENT_MESSAGE_ID`) 이하 문자열이어야 한다(단일 입력도).
  - 중복 판단은 묶음의 모든 `clientMessageId` 를 본다. 모두 이미 본 것이면 지금처럼 `ext{core.duplicate}`(턴을 열지 않는다), **일부만** 겹치면 `error(input)` 이다(부분 재전송은 모호해 겹치지 않은 것만 조용히 돌리지 않는다).
  - 턴 옵션(`model`·`toolScope`·`mcpContext`·`mode` 등)은 묶음 전체에 하나다. 원소별 옵션은 없다. `mode:'inject'` 묶음은 도는 턴에 한 발화로 끼워 넣는다. `resume` 이면 원소마다 이어서 하기와 같은 길(빈 원소에 이어서 하기 문구, 접두어 없음, 사람 글로 기록하지 않음)을 탄다.
  - **묶음의 `requesters` 에는 모든 원소의 `author` 가 들어간다 — 승인 정책은 가장 좁은 권한으로 판단한다.**
  - `consult`·분기(`fork`)는 묶음을 받지 않는다(타입에서 막힌다). 풀(`pool.turn`·`pool.engine`)·relay 엔진은 그대로 넘긴다. 메모리·스크립트·스텁 엔진(`@agent-relay-engine/testing`)은 원소 둘 이상의 묶음을 `error(input, '입력 묶음을 지원하지 않는다')` 로 닫는다(원소 하나는 단일 입력으로 받는다).
  - **`Engine` 을 직접 구현하면 런타임에 배열을 검사한다.** TS 메서드 매개변수는 이변(bivariant)이라 `turn(sessionId, input: TurnInput | string, …)` 처럼 좁은 시그니처도 `Engine` 으로 컴파일된다. 그대로 두면 배열을 받아 `{...input}` 처럼 다루다 `author` 없는 턴(`requesters` 칸 없음 — 소비자 정책이 "제한 없음"으로 읽을 수 있다)이 된다. 지원하지 않으면 `Array.isArray` 로 보고 `error(input)` 로 닫는다:

    ```ts
    async *turn(sessionId: string, input: TurnInput | string | TurnInputBundle, opts: TurnOptions = {}): AsyncGenerator<EngineEvent> {
      if (Array.isArray(input) && input.length !== 1) {
        yield { type: 'error', reason: 'input', message: '입력 묶음을 지원하지 않는다', resumable: false, turnId, sessionId, at: Date.now() };
        return yield { type: 'done', stopReason: 'error', turnId, sessionId, at: Date.now() };
      }
      const one = Array.isArray(input) ? input[0]! : input;
      // … 단일 입력으로 처리
    }
    ```
  - **`inputAuthorFormat` 이 `'none'`(기본)이면 모델은 이어 붙은 글의 화자를 구분하지 못한다** — 묶음을 쓰면 `'bracket'` 이나 함수 형식을 함께 켠다.
- **CLI 로 가는 글: `inputAuthorFormat`.** 기본 `'none'` 은 아무것도 붙이지 않는다. `'bracket'` 은 입력마다 첫 텍스트 블록 앞에 `[이름] `(이름이 없으면 id)을 붙이고, 함수 `(author) => string` 이면 돌려준 문자열을 접두어로 쓴다. 이미지·문서 블록에는 붙지 않는다. 합쳐진 입력은 조각마다 해당 보낸 사람의 접두어가 붙고, 끼워 넣기(`mode:'inject'`)도 같다. Claude·Codex 가 같은 규칙이다. 기록용 `display` 는 바뀌지 않는다. `'bracket'` 은 이름의 제어문자·줄바꿈을 공백으로, `[`·`]` 를 없애고 64자로 자른 값을 쓴다(화면·기록의 `author.name` 은 그대로). 빈 `name` 은 없는 것으로 보고 id 를 쓴다. 텍스트 블록이 없는(이미지만 있는) 입력은 접두어만 담은 텍스트 블록을 맨 앞에 둔다 — 합친 턴에서 앞사람 글로 읽히지 않게 한다. `TurnOptions.resume` 의 이어서 하기 문구에는 접두어를 붙이지 않는다(엔진이 만든 글이다). 함수가 던지거나 문자열이 아닌 값을 돌려주면 그 입력은 `'none'` 처럼 보내고 설정마다 한 번만 `process.emitWarning`(`AgentRelayEngineWarning`)을 낸다.
- **신뢰 경계가 아니다.** `inputAuthorFormat` 은 모델에게 주는 화자 힌트일 뿐이다. 본문 글에 `[Alice] …` 를 써 넣으면 가짜 조각 경계를 만들 수 있고, 엔진은 본문을 바꾸지 않는다. 권한 판단은 서버가 정한 턴 문맥 `requesters` 로 한다. 위조하기 어려운 구분자가 필요하면 함수 형식으로 직접 만든다.
- **`TurnContext.requesters?: string[]`.** 이 턴에 입력을 넣은 `author.id` 들이다. 입력 순서대로, 중복 없이. 합쳐진 턴은 합쳐진 입력 전부이고, 끼워 넣기로 들어온 입력은 들어온 시점부터 더한다. `author` 를 준 입력이 하나도 없으면 칸이 없다. 이어서 하기(`resume`) 턴은 입력에 `author` 를 주면 기록(`core.input`)과 requesters 에 남는다(접두어만 붙지 않는다). Claude 에서 끼워 넣기는 CLI 에 쓰기가 성공한 시점에 진행 중인 턴의 requesters 에 더해지고, 그 입력이 다음 턴으로 밀리면(큐잉) 이전 턴에도 남는다. 밀린 입력이 이어 시작한 새 턴에는 그 입력(머리)의 보낸 사람이 들어가고, 뒤에 더 밀린 끼워 넣기는 그 입력이 턴에 확정될 때 더해진다. 밀려서 이어 시작한 턴 안에서 뒤 입력이 늦은 replay(result 시점에야 확정)로 들어가면 그 보낸 사람은 result 시점에 그 턴의 requesters 에 들어간다 — 그 사이 도구 호출은 그 사람 없이 본다(누락 쪽). Codex 는 steer 가 받아들여진 시점에 더한다. `readTurnContext()`·`engine.turnContext()` 의 응답에만 실리고 env·args 표준 문맥은 바뀌지 않는다(그건 프로세스 단위라 턴마다 바뀌는 값을 담을 수 없다). 기존 `invoker`(엔진을 부른 쪽)의 뜻은 그대로다. MCP 서버가 이 값으로 권한을 판단할 때 요청자가 여럿인 턴은 가장 좁은 권한으로 판단하기를 권한다 — 정책은 서비스가 정한다.

```ts
// 설정에 inputAuthorFormat 를 주고, 입력에 author 를 준다
const config = { ...claudeProfiles.conversation, cwd: './work', namespace: 'my-tool', inputAuthorFormat: 'bracket' as const };
const engine = createClaudeEngine(config, { side });
// CLI 에는 "[Alice] 배포 상태 알려줘" 로 간다. 기록(core.input)에는 author 가 실린다
engine.turn('s1', { content: [{ type: 'text', text: '배포 상태 알려줘' }], author: { id: 'u1', name: 'Alice' } });
```

### 턴 단위 도구 범위 (`toolScope`)

한 턴에서 모델이 쓸 수 있는 도구를 좁힌다. 남의 세션에 묻는 턴이나 관련도만 보는 턴처럼, 그 턴만 쓰기를 막고 싶을 때 쓴다. 주지 않으면(기본 `'all'`) 동작과 출력이 지금과 같다.

```ts
type ToolScope = 'all' | 'read-only' | 'none' | { allow: string[]; readOnly?: true };
engine.turn(sessionId, '이 설계에서 빠진 것을 봐 줘', { toolScope: 'read-only' });
```

- **넓은 순서.** `'all'` > `{allow}` > `'read-only'` > `'none'` 이다. `'read-only'` 는 쓰기·삭제·외부 요청을 막고, 승인 없이 실행되는 읽기 도구는 그대로 둔다. `{allow, readOnly:true}` 는 `{allow}` 와 `'read-only'` 를 합친 결과(읽기 전용이면서 목록의 도구만)다.
- **capability `'turn-tool-scope'`.** 이것이 있는 엔진만 `'all'` 밖의 값을 받는다. 없는 엔진(메모리·스텁 엔진 등)은 조용히 무시하지 않고 `error(config)` 로 닫는다.
- **오류.** 형식이 틀리면 `error(input)` 이다. 이 세션에서 지킬 수 없는 범위면 턴을 시작하지 않고(`started` 없이) `error{reason:'config', resumable:false, message:'이 세션에서는 이 도구 범위를 지킬 수 없다', detail:{toolScope, cause}}` 다. `cause` 는 `'live-process'`(살아 있는 프로세스가 지킬 수 없는 범위)·`'unsupported'`(capability 없음)·`'allowed-tools'`·`'mode'`·`'approval'`·`'setting-sources'`·`'extra-args'`·`'unverified-tools'`·`'codex-config'`·`'features'`·`'codex-home'`(아래 표의 우회 설정)다.
- **자동 거부.** 범위 밖의 승인 요청은 사람에게 묻지 않고 엔진이 거절한다. `onPermissionRequest` 훅·정책 파일의 기억한 규칙·사전 승인보다 앞선다. 거절한 호출은 `ext{core.permission_denied, {items, reason:'tool-scope'}}` 로 남는다. 범위가 좁아지기 전에 와서 답을 기다리던 요청도 답을 쓰기 직전에 다시 보고 거절한다. 승인 창이 없는 세션(`approval:'none'`)은 백엔드가 스스로 거절하므로 `reason` 없이 그 백엔드의 거절 알림으로 온다.
- **알림.** 범위가 `'all'` 이 아니면 `started` 뒤 한 번 `ext{core.tool_scope, {scope}}` 를 낸다. 합쳐진 턴이면 실제로 쓴 가장 좁은 범위다.
- **합치기와 끼워 넣기.** 범위가 다른 입력이 `queue.coalesce` 로 한 턴이 되거나, 진행 중 턴에 끼워 넣기로 들어오면 **가장 좁은 범위**를 따른다. 범위는 합치기 묶음을 나누지 않는다. 좁아진 시점부터 남은 호출에 적용하고, 넓히지는 않는다 — 다른 사람의 입력이 넓은 권한 턴에 섞여 실행되지 않게 하려는 것이다. 끼워 넣기로 좁아지면 원래 턴 스트림에 `ext{core.tool_scope, {scope, via:'inject'}}` 가 한 번 더 온다. 넓혀야 하면 새 턴으로 보낸다.

**백엔드가 지키는 범위**

| 범위 | Claude(살아 있는 프로세스) | Codex(살아 있는 스레드) |
|---|---|---|
| `'all'` | 지금과 같다 | 지금과 같다 |
| `'read-only'` | 승인 경로(can_use_tool)를 엔진이 모두 거절한다. 쓰기(Write·Edit)·삭제 같은 셸 명령·WebFetch·하위 에이전트 안의 쓰기가 막힌다. Read·읽기 전용 셸·하위 에이전트 띄우기·ToolSearch 는 승인 없이 실행된다(실측) | `turn/start` 에 `sandboxPolicy:{type:'readOnly', networkAccess:false}` 를 실어 OS 샌드박스로 쓰기를 막는다. 그 턴의 승인 요청(샌드박스 밖 명령·파일 변경·MCP 도구)은 모두 거절한다. 다음 턴에 스레드의 원래 정책(thread/start·resume 응답의 `sandbox`)을 명시해 되돌린다 |
| `'read-only'` 를 깨는 설정 | 미리 허용한 도구(`allowedTools`, 엔진 ask 도구와 Read·Glob·Grep·LS·NotebookRead·ToolSearch 는 예외), `mode` 가 `dontAsk`·`default`·`plan` 밖, `approval:{mcpTool}`, `claude.settingSources`·`claude.extraArgs` 가 비어 있지 않음, init `tools` 에 확인하지 않은 내장 도구 → 그 턴은 `error(config)`. read-only 턴에서 띄운 하위 에이전트의 승인 요청은 턴이 끝난 뒤에도 거절한다 | `mcp__core__ask` 밖의 MCP `allowedTools`(승인 요청 없이 샌드박스 밖 서버에서 돈다), 허용 목록 밖의 `codex.config` 키, 기본 기능을 다 끄지 않은 `codex.disableFeatures`, `mode` `dontAsk`(기본)·`plan`(승인 정책 never), 앞 턴이 쓸 수 있었던 엔진 홈의 `config.toml`·`rules`·`hooks.json`·`managed_config.toml`·`requirements.toml` → 그 턴은 `error(config)` |
| 진행 중 턴을 좁히는 끼워 넣기 | 끼운 줄을 CLI 에 쓴 시점부터 그 턴의 승인 요청을 거절한다 | `turn/steer` 로는 샌드박스를 바꿀 수 없어 끼워 넣지 않는다 — `QueuePolicy.injectFallback` 대로 새 턴(그 범위)으로 가거나 거절된다 |
| `'none'`·`{allow}` | 띄울 때 도구 목록으로만 지킬 수 있어 `error(config)`(`cause:'live-process'`) | 셸을 끌 수 없어 `error(config)`(`cause:'live-process'`) |

`'read-only'` 를 쓰려면 위 표의 우회 설정을 피한다. `'none'`·`{allow}` 와 더 단단한 차단은 세션을 분기할 때 띄울 때의 도구 목록으로 지킨다(아래 [세션 분기와 물어보기](#세션-분기와-물어보기-forkconsult)).

### 세션 분기와 물어보기 (`fork`·`consult`)

남의 AI 세션 맥락에 물어볼 때 쓴다. 원본 세션을 바꾸지 않고 대화를 이어받은 새 세션을 만든다(`fork`). 그 위에서 범위를 좁힌 한 턴을 돌리고 정리하는 편의 기능이 `consult` 다. capability `'session-fork'` 가 있는 엔진만 두 메서드가 있다.

```ts
const { sessionId } = await engine.fork!(source, { toolScope: 'read-only' });
for await (const ev of engine.consult!(source, '이 결정의 근거가 뭐였지?')) render(ev); // 기본 'read-only', 끝나면 정리
```

- **지원 여부.** capability `'session-fork'` 로 본다. 메서드가 있어도(backend-kit `BaseEngine` 은 늘 둔다) capability 가 없는 엔진은 `ForkError(config, cause:'unsupported')` 다. 풀·relay 도 안쪽 엔진·백엔드의 capability 로 판단한다.
- **`fork(source, opts?) => Promise<{ sessionId }>`.** `opts` 는 `sessionId`(기본 randomUUID, 이미 있는 세션이면 거절), `overrides`(새 세션에만 덮는 `CommonSessionOverrides` — 백엔드 이름 칸은 받지 않는다), `toolScope`(기본 `'all'`), `ifBusy`(`'wait'` 기본·`'reject'`)다.
  - **원본 불변.** 원본의 대화·진행 중 턴·승인 대기·큐는 건드리지 않는다. 원본이 아직 시작되지 않았으면(백엔드가 대화를 만든 적이 없으면) 거절한다.
  - **원본이 턴 중일 때.** CLI 는 진행 중인 턴까지 복사한다(실측). 그래서 `'wait'` 는 분기를 요청한 시점에 돌던 턴이 끝나기를 기다린다(그 뒤에 들어온 턴은 기다리지 않는다, 상한 `limits.totalMs`). `'reject'` 는 바로 거절한다. 원본 턴 안의 도구(MCP 서버 등)가 같은 원본을 분기하면 `'wait'` 는 자기 턴을 기다려 상한까지 멈춘다 — 그 경우는 `'reject'` 를 준다.
  - **복사 구간 붙잡기.** 백엔드가 원본 대화를 실제로 복사하는 동안(아래 표) 엔진은 원본의 **다음 턴 시작만** 잠깐 붙잡는다. 순서·내용은 그대로고 지연만 생긴다. 붙잡은 동안 원본에 온 입력은 평소 "턴 중" 규칙(대기열·`mode:'reject'`·inject 대체 정책)을 따른다. 복사가 실패하거나 상한을 넘어도 반드시 놓는다. 상한은 **분기 쪽**이 정한다 — 기다림은 엔진 `limits.totalMs`, Claude 복사 구간은 분기 첫 턴의 `limits`(그 턴의 무응답·전체 상한), Codex 는 RPC 상한(`limits.controlRequestMs`). 원본 소유자가 정하지 않으므로, 남이 분기할 수 있는 서비스는 분기 쪽 상한을 짧게 둔다.
  - **실패.** `ForkError{reason, message, resumable, detail?}` 를 던진다. `message` 는 고정 문구이고 바깥 글은 `detail.cause` 다. `reason` 은 `input`(옵션·세션 id 가 틀림, 원본이 시작되지 않음 `cause:'source-not-started'`)·`busy`(`'reject'`, 기다림 상한)·`config`(범위를 지킬 수 없음, 백엔드 정책 검사)·`disposed`·`stopped` 와 백엔드 기동 실패의 사유다.
- **분기 범위는 세션에 고정된다.** `toolScope` 는 새 세션의 모든 턴에 걸린다 — 턴마다 분기 범위와 `TurnOptions.toolScope` 중 좁은 쪽을 따르고, 턴에 `'all'` 을 줘도 넓어지지 않는다. 범위는 세션 기록(`ext.fork`)에 남아 퇴출·재시작·엔진 재기동 뒤에도 유지된다. `resolveSession`·`overrides` 로 넓힐 수 없고, 기록을 읽을 수 없으면 `'none'` 으로 본다. 분기 세션을 다시 분기하면 원본 분기의 범위보다 넓어지지 않는다.
- **`overrides` 는 메모리에만 둔다.** `resolveSession` 결과 위에 칸별로 덮는다. 비밀이 든 `mcpServers` 를 디스크에 남기지 않으려는 것이다. 엔진을 새로 만들면 사라지고 그때부터는 `resolveSession` 이 정한다(범위는 위처럼 기록에 남는다). 그래서 `overrides` 로 **좁힌** 설정(서버를 줄이거나 권한을 좁힘)은 재기동 뒤 넓어질 수 있다. 좁힘이 꼭 지켜져야 하면 `toolScope` 로 주거나, `resolveSession` 에서 `ctx.record?.ext?.fork?.from` 으로 분기 세션을 알아보고 같은 좁힌 설정을 돌려준다.
- **권한.** 분기 권한은 **원본 대화 읽기 + 새 세션 실행**이다. 엔진은 누가 분기할 수 있는지 판단하지 않는다 — 원본 소유자가 아닌 사람이 부를 수 있는 서비스는 `fork`·`consult` 를 부르기 전에 원본 읽기 권한과 새 세션을 돌릴 권한을 서비스가 검사한다.
- **수명.** 분기 세션은 일반 세션과 같다. 풀·유휴 퇴출·`stop`·`evict` 를 그대로 따르고, 정리 책임은 소비자에게 있다. 풀의 `fork` 는 분기하는 동안(백엔드가 프로세스를 띄울 수 있다), `consult` 는 분기부터 정리까지 그 세션의 풀 자리를 잡는다. `fork()` 가 끝나기 전에 같은 id 로 온 `turn` 은 `error(busy, '세션을 분기하는 중이다')` 다.
- **백엔드에 남는 사본.** `consult` 의 정리는 엔진의 세션(프로세스·메모리·기록)만 지운다. Codex 는 `keep` 이 아닌 `consult` 의 분기를 `thread/fork{ephemeral:true}` 로 열어 스레드 기록을 디스크에 남기지 않는다(그래서 그 분기는 프로세스가 내려가면 이어 갈 수 없다 — 한 턴뿐이라 괜찮다). Claude CLI 에는 그런 옵션이 없어 분기 transcript 가 CLI 저장소에 남는다. `fork` 와 `keep` 인 `consult` 는 두 백엔드 모두 남는다. 원본 대화의 사본이므로 민감하면 백엔드 저장소를 따로 정리한다.
- **`consult(source, input, opts?) => AsyncIterable<EngineEvent>`.** 분기(기본 `toolScope:'read-only'`) → 한 턴 → `keep` 이 아니면 정리한다. 정리는 성공·오류·중지·소비자가 iterator 를 중간에 버린 경우 모두 하고, 분기 세션의 프로세스·메모리·저장소 기록(`SideChannel.sessions.delete` 가 있으면)을 지운다. `opts` 는 `toolScope`·`model`·`limits`(그 턴에만)·`keep`·`sessionId`·`ifBusy`·`signal`·`gate` 다. 이벤트의 `sessionId` 는 분기 세션이다. 분기에 실패하면 그 id 로 `error → done` 이 온다. 풀(`pool.engine.consult`)은 분기 턴도 풀 자리를 거치고, relay 는 원본이 고정된 백엔드에 맡기고 남긴 세션도 같은 백엔드에 고정한다.
- **분기의 첫 턴 표시.** 분기 세션의 첫 턴 — 새 백엔드 세션이지만 원본 대화를 이어받아 시작한 턴 — 의 `started` 에 `forked:true` 가 온다. 그 밖의 턴에는 없다. `resumed` 는 백엔드마다 뜻 그대로다(Claude 분기의 첫 턴은 `false`, Codex 는 `true`) — 진짜 새 대화와 분기의 시작은 `forked` 로 가른다. 첫 턴이 백엔드에 닿기 전에 실패해 다음 턴이 다시 이어받으면 그 턴에 온다. 한 분기 세션에서 최대 한 번이며, 오지 않을 수도 있다(첫 턴이 `started` 없이 닫히는 경우 등).
- **비용.** 분기 세션의 첫 턴은 원본 대화를 다시 읽는다(Claude 는 대부분 캐시를 읽는다, 실측). 관련도 판정처럼 자주 부르면 `model`·`limits`·예산으로 줄인다. 언제 부를지는 서비스가 정한다.

**백엔드별 분기**

| | Claude | Codex |
|---|---|---|
| 방법 | 분기 세션의 첫 프로세스를 `--resume <원본 CLI 세션 id> --fork-session` 으로 띄운다. CLI 가 정한 새 id(첫 `init` 의 `session_id`)를 기록해 이후 `--resume` 에 쓴다 | `fork()` 안에서 분기 세션의 app-server 를 띄우고 `thread/fork` 로 새 스레드를 얻는다. 그 프로세스를 첫 턴이 쓴다 |
| 복사 시점 | **분기 세션의 첫 턴.** CLI 는 `init` 을 입력 뒤에 내므로 `fork()` 는 기록만 한다. 그래서 `fork()` 와 첫 턴 사이에 원본이 더 진행됐으면 그만큼 포함된다(`consult` 는 바로 이어 돌아 문제없다). 첫 턴은 원본의 도는 턴이 끝나기를 기다리고, 첫 `init` 까지 원본의 다음 턴을 붙잡는다 | `fork()` 안. 원본의 턴 끝(또는 바로)부터 `thread/fork` 응답까지 원본의 다음 턴을 붙잡는다 |
| `'read-only'` | 턴 승인 경로(위 표, 살아 있는 세션과 같다) | `thread/fork`·`resume` 의 `sandbox:'read-only'` + 턴마다 `sandboxPolicy` readOnly. read-only 턴과 같은 우회 설정 검사를 `fork()` 에서 먼저 하고, `codex.allowProjectConfig` 여도 프로젝트 `.codex/` 를 거절한다 |
| `'none'` | 띄울 때 `--tools ''`(보장 검사 strict), MCP 서버·엔진 ask 서버를 넘기지 않고 미리 허용을 비운다. init 에 도구가 하나라도 있으면 `error(config, outside-scope)` | 받지 않는다 — `ForkError(config, cause:'unsupported')`(셸을 끌 수 없다) |
| `{allow}` | 목록의 내장 도구만 `--tools a,b`, 목록에 도구가 있는 MCP 서버만 넘긴다. 남긴 서버의 다른 도구는 승인 경로에서 거절한다. 미리 허용(정책 파일 포함)은 목록 안의 것만 받는다 | 받지 않는다 — `ForkError(config, cause:'unsupported')` |
| 원본 대화가 없을 때 | `error(resume-missing, '분기할 원본 대화가 CLI 에 없다')`. 맥락 없는 새 대화로 바꾸지 않고 다음 턴이 다시 분기를 시도한다 | `thread/fork` 오류 그대로 `ForkError` |
| 정책 재검사 | 일반 세션과 같은 인자 파일·세션 설정 경로 | `thread/fork` 직전에 홈 정책 항목·프로젝트 `.codex/` 를 `thread/start`·`resume` 과 같이 다시 보고, 응답 `sandbox` 로 홈 쓰기 가능을 다시 본다 |

### 중지와 끼워 넣기

- `engine.stop(sessionId)` 은 시작된 턴(입력을 CLI 에 보낸 턴)이 있으면 그 턴만 멈추고 `'control'|'signal'` 을 돌려준다. 백엔드가 프로세스를 내리지 않고 멈출 수 있으면 `'control'`, 아니면 프로세스 그룹에 SIGTERM → SIGKILL 이다. 뒤에 쌓인 입력은 다음 턴이 된다.
- 백엔드가 control 중지로 턴을 닫는 중이면 `stop()`·`evict()`·`dispose()` 는 그 끝을 기다린다. 다만 `interruptGraceMs + termGraceMs × 3` 를 넘기면 신호로 끊고 `'signal'` 로 알린다(반환값·metric·`interrupted.via` 가 같다). 끊고 프로세스를 내린 뒤에도 백엔드가 `termGraceMs` 안에 턴을 닫지 못하면 엔진이 그 턴을 `interrupted{via:'signal'}` → `done(interrupted)` 로 강제로 닫는다. control 단계 없이 바로 신호로 끊는 경우(`evict()`·`dispose()`·소비자 이탈·`stop({force:true})`·강제 재시작)도 같다 — 신호로 끊는 턴 하나를 기다리는 시간은 최대 `termGraceMs × 3` 이다. 풀 자리·세션 큐가 반환되고, 그 뒤 늦게 오는 출력은 버린다. 그 프로세스는 다시 쓰지 않는다. 백엔드가 턴 끝을 이미 받아 닫는 중이면 `evict()`·`dispose()` 의 신호 끊기는 프로세스만 내리고 중지로 세지 않는다(metric 없음, 턴은 받은 끝대로 닫힌다). 다만 그 끝을 내지 못해(사용량 기록 저장이 멈춤 등) 강제로 닫히면 신호로 끊긴 것이다(`interrupted{via:'signal'}`, metric `signal`). `core.input` 을 내기 전이고 입력을 보내기 전에 강제로 닫힌 턴의 `clientMessageId` 는 기억하지 않는다 — 같은 id 로 다시 보내면 실행된다(ask 답 턴의 예외는 위 `TurnInput`). `evict()` 가 그 끝을 기다리는 사이 다음 턴이 시작되면 그 턴의 프로세스는 내리지 않는다. `dispose()` 가 그 끝을 기다리는 사이 다음 턴이 같은 프로세스를 이어받으면 그 턴도 멈춘 뒤(`interrupted{via:'signal'}`) 프로세스를 한 번 내린다.
- 강제 재시작(`restart(sessionId, reason)`)과 다른 사유의 다시 띄우기(프롬프트·설정·정책·모델 변경 등)는 내려간 프로세스 하나에 metric `process.restart` 를 한 번 남긴다. 태그 `reason` 은 그 프로세스를 내린 사유다. 세션 프로세스에 미뤄 둔 `restart()` 의 사유를 다른 사유가 덮으면(다른 `restart()` 가 그 사유를 바꾸거나 그 프로세스를 내림, Claude 의 모델 변경·Codex 의 read-only 턴 재기동 등 `discardProc` 에 사유를 주어 내리는 백엔드 경로) 덮인 처음 사유가 태그 `deferred` 로 남는다 — 이상 신호(`watchdog` 등)가 지표에서 사라지지 않게. 두 사유가 같으면 `deferred` 는 없다. 미뤄 둔 `restart()` 의 사유가 그 프로세스의 종료로 이미 세어진 뒤, 세션에 남은 그 프로세스를 두고 부른 `restart()` 는 내려간 프로세스가 없어 세지 않는다. 아직 아무 프로세스도 없을 때 도는 턴을 끊는 `restart()` 는 센다(도는 턴도 프로세스도 없으면 세지 않는다).
- 시작된 턴이 없으면 큐·풀·spawn 을 기다리는 턴을 전부 취소하고 `'pending'` 을 돌려준다. 취소된 턴은 `started` 없이 `error{reason:'stopped', resumable:true}` → `done(error)` 다.
- 같은 질문의 답은 한 번만 받는다. 이미 답을 기록한 `askId` 의 답은 `error(ask-mismatch)` 다(`recordAnswer`). 답 턴이 답을 기록한 뒤(입력을 보내기 전이라도) 실패하면 같은 답을 다시 보내지 말고 모델이 다시 묻게 한다 — 같은 답은 `error(ask-mismatch)` 다.
- 도는 턴에 끼워 넣는 입력(`mode:'inject'`)에 `answer` 가 있으면 `error(input)` 으로 거절한다. 끼워 넣기는 답 확인을 거치지 않아 아무 글이 답으로 들어갈 수 있다. 답은 새 턴으로 보낸다.
- `mode:'inject'` 스트림은 실제 끼워 넣기로 확인되면 `accepted{mode:'inject'}` → `done(end_turn)` 으로 원래 턴보다 먼저 끝난다. 응답 본문은 원래 턴 스트림으로 흐르니 그 `done` 을 "응답 끝"으로 읽지 않는다. 큐잉으로 떨어지면 그 스트림이 다음 턴을 `started` 부터 받는다(`QueuePolicy.injectFallback`).

### 예산

`budget.perTurn`·`perSession`·`remaining(sessionId)`. `perTurn.costUsd` 는 그 턴의 비용(`usage.costUsd`)을, `perSession.costUsd` 는 그 합을 본다. 토큰·비용은 턴 결과 뒤에만 판단하므로 턴 하나는 상한을 넘을 수 있다. `stop()` 으로 멈춘 턴(백엔드가 중지를 받아들여 닫은 턴)은 결과가 상한을 넘었어도 중지로 닫는다(`interrupted{via:'control'}`). 세션 상한(`perSession`)을 넘었으면 다음 턴을 시작 전에 거부한다.

- `perSession.turns` 는 CLI 에 보낸 턴 수(세션 기록 `turns`)로, 다 쓰면 다음 턴을 시작 전에 거부한다(`resumable:false`).
- `perTurn.toolCalls` 는 턴의 도구 호출 수(서브에이전트 안 포함)로, 넘는 호출을 보면 2단 중지 → `error(budget, resumable:false, detail:{key:'toolCalls', limit, used, toolId, name})` + `done(budget)`. **사후 중지다** — 자동 허용 도구는 이미 실행됐을 수 있다.
- 구독 사용률(`usage.subscription`)을 못 읽는 경로에서는 `usage` 이벤트의 토큰 합이나 `engine.status(sid).usage` 로 한도를 판단한다.

### 도구 이름과 `originalName`

MCP 도구 이름은 `mcp__<서버>__<도구>` 이고, 이름의 `[^A-Za-z0-9_-]` 는 `_` 로 정규화된다(`normalizeToolName`). `McpServerSpec.tools` 에 원래 이름을 적어 두면 `tool-start`/`tool` 에 `originalName` 을 단다. 두 원래 이름이 같은 이름으로 정규화되면 `originalName` 을 비우고 `ext{core.tool_name, {warning:'ambiguous', name, server, candidates}}` 를 낸다.

## 공개 API

<!-- gen:api @agent-relay-engine/core . -->
`@agent-relay-engine/core` — 257개, 공개 API 스냅샷 1.8.12 기준.

| 종류 | 이름 |
|---|---|
| function | `announcesTurnContext` · `answerList` · `answerToText` · `appendRule` · `askEvent` · `askQuestions` · `authorsOf` · `bashSegments` · `buildMcpConfig` · `buildUserLine` · `checkAuthor` · `coalesceInputs` · `consumePreapproval` · `createEnginePool` · `createEventTap` · `createMetrics` · `createRelayEngine` · `createSideChannel` · `decodeJson` · `detectBackend` · `detectBackends` · `encodeJson` · `engineEnv` · `engineEnvReport` · `handleAsk` · `hashArgs` · `injectMcpArgs` · `isApiBillingVar` · `isCoreExt` · `isOuterSessionVar` · `lastAskId` · `launchesCoreToolsServer` · `loadPolicy` · `matchRule` · `mergeCoreToolsServer` · `mergePolicy` · `newAskId` · `normalizeInput` · `opensAllBash` · `parseAskArgs` · `parseAskQuestions` · `pickVictim` · `policyArgsKey` · `policyPath` · `policySignature` · `policyStatus` · `poolEngine` · `readAsk` · `readMcpContextEnv` · `readTurnContext` · `recordAnswer` · `recordPreapproval` · `requireApproval` · `resolveInputPolicy` · `resolveLimits` · `resumeInput` · `ruleLabel` · `ruleMatches` · `sniffImageType` · `splitToolName` · `staleWaiters` · `standardMcpArgs` · `standardMcpEnv` · `suggestRulePrefix` · `terminate` · `unwrapShell` · `unwrapToolResult` · `validateLimits` · `validatePolicy` · `watchPolicy` · `withKeyLock` |
| class | `AnswerMismatchError` · `BudgetTracker` · `ForgetError` · `ForkError` · `InputError` · `LegacyConfigError` · `LimitsError` · `MemorySideStore` · `PolicyError` · `PolicyState` · `PoolBusyError` · `ProcessPool` · `RelayEngine` · `SideBusyError` |
| const | `answeredKey` · `API_BILLING_ENV_PREFIXES` · `approvalMessages` · `askKey` · `askToolSchema` · `CORE_ASK_TOOL` · `CORE_EXT` · `CORE_TOOLS_SERVER` · `coreExt` · `DEFAULT_ASK_POLICY` · `DEFAULT_ASK_TTL_MS` · `DEFAULT_DETECT_CACHE_MS` · `DEFAULT_DETECT_TIMEOUT_MS` · `DEFAULT_INPUT_POLICY` · `DEFAULT_INVOKER` · `DEFAULT_LIMITS` · `DEFAULT_MCP_CONTEXT_MODE` · `DEFAULT_OBSERVE_BUFFER` · `DEFAULT_PERMISSION_MODE` · `DEFAULT_QUEUE_POLICY` · `DEFAULT_RESUME_PROMPT` · `ERROR_REASONS` · `execRun` · `holdsSeat` · `isDeclaredErrorReason` · `isEmptyAnswer` · `KNOWN_API_KEY_ENV_VARS` · `lastAskKey` · `MAX_ASK_QUESTIONS` · `MAX_CLIENT_MESSAGE_ID` · `MAX_TURN_INPUTS` · `MCP_CONTEXT_ENV` · `MCP_TURN_CONTEXT_ENV` · `nodeSpawn` · `normalizeToolName` · `OUTER_SESSION_ENV_PREFIXES` · `OUTER_SESSION_ENV_VARS` · `POLICY_FILE` · `POLICY_POLL_MS` · `PREAPPROVAL_TTL_MS` · `PRESERVED_ENV_VARS` · `PROTOCOL_VERSION` · `READ_TURN_CONTEXT_TIMEOUT_MS` · `registerCoreTools` · `RELAY_EXT` · `REMAINING_TIMEOUT_MS` · `SLEEP_THRESHOLD_MS` |
| interface | `BackendDescriptor` · `BackendOptionsMap` · `BackendSessionOverridesMap` · `CoreToolContext` · `Engine` · `EnginePool` · `SideChannel` · `SideStore` |
| type | `Announce` · `ApiKeyProvider` · `ApprovalFailReason` · `ApprovalGuardResult` · `AskAnswer` · `AskArgs` · `AskOption` · `AskPolicy` · `AskQuestion` · `AskQuestionAnswer` · `AskQuestionsSource` · `AskRecord` · `AskResult` · `Author` · `BackendFeatures` · `BackendName` · `BackendOptionsFields` · `BackendSessionOverridesFields` · `BackendStatus` · `BackendUnavailableReason` · `Budget` · `BudgetAdmission` · `BudgetFailure` · `BudgetKey` · `BudgetVerdict` · `ChildHandle` · `CommonEngineConfig` · `CommonSessionOverrides` · `ConsultOptions` · `CoreExtNs` · `CoreExtPayloadOf` · `CoreExtPayloads` · `CoreToolRegistrar` · `DeclaredErrorReason` · `DetectBackendsOptions` · `DetectOptions` · `DisplayBlock` · `DocumentBlock` · `EngineCapability` · `EngineConfig` · `EngineContractSuite` · `EngineDeps` · `EngineEnvOptions` · `EngineEnvReport` · `EngineEvent` · `EngineFactory` · `Envelope` · `ErrorReason` · `EventTap` · `ForkOptions` · `ImageBlock` · `ImageRefBlock` · `InputAuthorFormat` · `InputBlock` · `InputPolicy` · `Lease` · `LegacyRecordContext` · `Limits` · `LockOptions` · `McpContext` · `McpContextMode` · `McpServerLike` · `McpServerSpec` · `McpServerState` · `McpToolCallExtra` · `Metric` · `Metrics` · `MetricsSink` · `ModelVia` · `NormalizedInput` · `ObservedEvent` · `PermissionCancelReason` · `PermissionConfig` · `PermissionDecidedVia` · `PermissionDecision` · `PermissionDenial` · `PermissionMode` · `PermissionRequest` · `PermissionRuleVia` · `PolicyConfig` · `PolicyRule` · `PolicyStatus` · `PoolOptions` · `PoolSlot` · `PreapprovalQuery` · `ProjectPolicy` · `ProtocolVersion` · `QueuePolicy` · `ReadTurnContextOptions` · `RecordFn` · `RelayEngineConfig` · `RelayEngineDeps` · `RelayRecordExt` · `ResolvedPermissions` · `RuleInput` · `RunCommand` · `Seat` · `SessionOverrides` · `SessionRecord` · `SessionResolveContext` · `SessionStatus` · `SideStoreContractSuite` · `Skipped` · `SkippedBackend` · `SkipReason` · `SpawnFn` · `StopResult` · `SubagentPolicy` · `TextBlock` · `ToolKind` · `ToolScope` · `TurnContext` · `TurnDefaults` · `TurnInput` · `TurnInputBundle` · `TurnOptions` · `Usage` |
<!-- /gen -->

### 백엔드 골격 (`backend-kit`)

`@agent-relay-engine/core/backend-kit` 은 **experimental** 이다(minor 에서 바뀔 수 있다). 새 백엔드를 구현할 때만 쓴다. 쓰는 법은 [구조 문서](../../docs/ARCHITECTURE.md#새-백엔드-붙이기).

<!-- gen:api @agent-relay-engine/core ./backend-kit -->
`@agent-relay-engine/core/backend-kit` — 143개, 공개 API 스냅샷 1.8.12 기준.

| 종류 | 이름 |
|---|---|
| function | `addPending` · `bounded` · `cancelledNotice` · `cancelPending` · `caughtFailure` · `checkForkOptions` · `checkKeys` · `checkMcpContext` · `checkModel` · `checkOverrides` · `checkToolScope` · `clearEvict` · `configFailure` · `consultStream` · `coreInputPayload` · `createBaseCore` · `createRun` · `decidedNotice` · `deniedByToolScope` · `describeExit` · `discardProc` · `evictProc` · `fingerprint` · `foreignConfigFields` · `forkRecordOf` · `humanTimeoutMessage` · `mergeBudget` · `narrowToolScope` · `noteDecided` · `policyFor` · `rejectLegacyConfig` · `resetApprovals` · `resolveAuth` · `resolveModel` · `resolvePrompt` · `resolveSessionWith` · `restartSession` · `runPermissionHook` · `sameToolScope` · `scheduleEvict` · `sourceWaitError` · `stable` · `stopRun` · `stripForeignConfig` · `sweepPolicies` · `turnSkeleton` · `twoStageStop` · `waitSource` · `within` · `withRequesters` |
| class | `BaseEngine` · `BaseSession` · `Channel` · `PermissionDesk` · `SessionConfigError` · `SleepDetector` · `StderrTail` · `ToolNameIndex` · `ToolScopeError` · `TurnContextHub` · `TurnEnd` · `TurnQueue` · `TurnTimer` |
| const | `behaviorOf` · `budgetFailure` · `causeOf` · `CORE_LEGACY_FIELDS` · `DEFAULT_ASK_POLICY` · `DEFAULT_DENY_MESSAGE` · `DEFAULT_QUEUE_POLICY` · `defined` · `ENDED_TURN_TTL_MS` · `ENGINE_CONFIG_KEYS` · `exitDetail` · `FORK_EXT` · `FORK_ID_TAKEN` · `FORK_UNSUPPORTED` · `forkScopeError` · `isAllScope` · `KEY_WAIT_MS` · `MAX_ENDED_TURNS` · `MAX_KEYS` · `narrowestToolScope` · `narrowsToolScope` · `OVERRIDE_KEYS` · `PERMISSION_KEYS` · `RESOLVE_SESSION_TIMEOUT_MS` · `STDERR_GRACE_MS` · `STDERR_LINE_CHARS` · `STDERR_TAIL_CHARS` · `STOPPED_BEFORE_START` · `TOOL_SCOPE_DENIED` · `TOOL_SCOPE_DENY_MESSAGE` · `TOOL_SCOPE_UNSUPPORTED` · `toolScopeFailure` · `toolScopeNotice` · `UNEXPECTED_MESSAGE` · `withStderrLine` |
| type | `Admission` · `AuthKind` · `BaseCore` · `BaseCoreParts` · `BaseProc` · `BaseRun` · `CancelledPermission` · `ClosingRun` · `ConsultDeps` · `DecidedRun` · `DeskAnswer` · `DeskOptions` · `DeskRun` · `DeskVia` · `DriveStart` · `EventBody` · `ForkPlan` · `ForkRecordExt` · `Grant` · `HumanAnswer` · `InjectStart` · `LegacyField` · `LifecycleCore` · `LifecycleSession` · `MetaKeyReader` · `OriginalName` · `PendingTurn` · `PermissionDecided` · `PermissionHookResult` · `PermissionInbound` · `PolicyCore` · `ResolveOptions` · `ResolvingSession` · `RuleConfig` · `RunFailure` · `RunNotice` · `SessionContextView` · `SessionCore` · `StopReason` · `StopVia` · `TimedRun` · `TurnContextHubOptions` · `TurnEndDeps` · `TurnHooks` · `Wake` |
<!-- /gen -->

## 설정

공통 칸(`CommonEngineConfig`)이다. 백엔드 칸은 [claude](../claude/README.md#설정)·[codex](../codex/README.md#설정) README 에 있다.

| 칸 | 기본 | 뜻 |
|---|---|---|
| `cwd`, `namespace` | 필수 | CLI 작업 폴더, 사이드 채널 키 접두 |
| `systemPrompt` | 없음 | 문자열 또는 함수(매 턴 호출). 값이 바뀌면 다음 턴 전에 다시 띄우고 `ext{core.restart, {reason:'prompt-changed'}}`. 대화를 잇는지는 백엔드마다 다르다([대응표](../../docs/BACKENDS.md#프롬프트-변경)) |
| `resumePrompt` | `'이어서 계속해 줘'` | `TurnOptions.resume` 턴에 보낼 말 |
| `model` | CLI 기본 | 모델 이름(백엔드 어휘). 세션·턴 단계가 이긴다([모델 지정](#모델-지정)) |
| `mcpServers` | 없음 | 툴 MCP 서버(`McpServerSpec`: stdio `command/args/env` 또는 http `url/headers`, 선택 `tools`) |
| `coreToolsSpec` | 없음 | 코어 도구(ask) 서버. `mcpServers.core` 로 합쳐지고 `mcp__core__ask` 가 허용 목록에 들어간다. 보통 `withAskServer` 가 채운다 |
| `mcpContext` | `'env'` | 세션 문맥을 stdio MCP 서버에 넘기는 방식. `'env'`: `AGENT_RELAY_ENGINE_SESSION_ID`·`_TURN_ID`·`_INVOKER`·`_SCOPE`. `'args'`: `--session-id --turn-id --invoker --scope`. `'both'`. 서버는 `readMcpContextEnv(process.env)` 로 읽는다 |
| `scope`, `mcpArgs` | `[]`, 없음 | 세션 범위, 서버 args 뒤에 붙는 추가 인자 함수 |
| `resolveSession` | 없음 | 세션별 설정 훅([세션별 설정](#세션별-설정-resolvesession)) |
| `turnDefaults` | 없음 | `TurnOptions` 기본값(`requireToolCall`) |
| `inheritOuterSession` | `false` | `true` 면 바깥 Claude Code 세션 변수를 CLI 자식 env 에 그대로 넘긴다([자식 환경](#자식-환경)). 세션별로 덮지 않는다 |
| `permissions` | `mode:'dontAsk'`, `approval:'none'`, `auth.allow:['subscription']` | `mode` 는 `dontAsk`·`default`·`acceptEdits`·`plan`·`manual`·`auto`. 완화하면 `started.permissions.relaxed:true`. 정책 파일 상태는 `started.permissions.policy` 에 실린다(아래) |
| `policy` | `{enabled:true, path:'<cwd>/.agent-relay-engine/policy.json'}` | 프로젝트 정책 파일 |
| `limits` | idle 5분 · total 40분 · watchdog 12분 · interruptGrace 3초 · termGrace 3초 · evictIdle 15분 · controlRequest 30초 · permissionAnswer 없음 | `idleMs < watchdogMs` 등 불변식은 설정 로드 때 검증 |
| `queue` | `defaultMode:'turn'`, `coalesce:false`, `maxDepth:16`, `injectFallback:'turn'` | 턴 중 입력 처리 |
| `input` | `allowBlocks:['text','image']`, 이미지 inline, 5 MiB | 허용 block 과 이미지 전달 방식 |
| `inputAuthorFormat` | `'none'` | `TurnInput.author` 를 CLI 로 가는 글에 붙이는 방식. `'none'`·`'bracket'`·`(author) => string`. [보낸 사람과 턴의 요청자](#보낸-사람과-턴의-요청자) |
| `ask` | `endTurnOnAsk:true`, `defaultTtlMs` 1시간, `enabled:true` | ask 도구 정책 |
| `budget` | 없음 | [예산](#예산) |
| `subagents` | 백엔드 기본 | `drop`·`ext`·`inline` |
| `includePartial` | `false` | `text-delta`(와 백엔드에 따라 `thinking-delta`)를 낼지 |
| `rawLog`, `metrics` | 없음 | CLI 입출력 원문 로그(`{dir, maxBytes}`), 메트릭 싱크 |

### 자식 환경

엔진은 CLI 자식 env 를 `engineEnv(base, perms, providers, opts?)` 로 만든다(지운 이름이 필요하면 `engineEnvReport`).

- **과금 변수.** 그 CLI 가 과금에 쓰는 공급자의 변수(`KNOWN_API_KEY_ENV_VARS`·`API_BILLING_ENV_PREFIXES`)를 지운다. `permissions.auth.allow` 에 `'apiKey'` 가 있으면 남긴다.
- **엔진 문맥.** `AGENT_RELAY_ENGINE_*` 는 늘 지운다(이 엔진이 MCP 서버 안에서 돌 때 바깥 세션 문맥).
- **바깥 Claude Code 세션 변수.** 1.5.0 부터 기본으로 지운다. `OUTER_SESSION_ENV_VARS`(`CLAUDECODE`·`CLAUDE_CODE_SESSION_ID`·`CLAUDE_PID` 등)와 `OUTER_SESSION_ENV_PREFIXES`(`CLAUDE_CODE_MESSAGING_`)다. 엔진을 Claude Code 세션 안의 셸에서 띄우면 메시징 소켓·토큰이 자식으로 새고, CLI 가 바깥 세션 문맥을 자기 것으로 착각할 수 있어서다. `CLAUDE_CODE_` 접두 전체는 지우지 않는다(`CLAUDE_CODE_OAUTH_TOKEN`·`CLAUDE_CODE_MAX_OUTPUT_TOKENS` 같은 사용자 설정은 남는다). 지운 이름이 있으면 `started` 뒤 프로세스마다 한 번 `ext{core.config, {warning:'outer-session-stripped', vars}}` 를 낸다(값은 싣지 않는다). 바깥 세션 변수에 기대던 쪽은 `inheritOuterSession: true` 로 되돌린다.
- **남기는 것.** `PRESERVED_ENV_VARS`(`CLAUDE_CODE_ENTRYPOINT`·`CLAUDE_CONFIG_DIR`·`HOME`·`PATH`)는 어느 목록과 겹쳐도 남긴다.

## 다른 문서

- [백엔드 대응표](../../docs/BACKENDS.md) — 칸·이벤트·capabilities 의 백엔드별 해석
- [인터페이스 규칙](../../docs/INTERFACE-RULES.md) — 공개 API 를 더할 때의 규칙
- [testing README](../testing/README.md) — 계약 스위트·가짜 백엔드

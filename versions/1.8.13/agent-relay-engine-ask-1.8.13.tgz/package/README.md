# @agent-relay-engine/ask

코어 도구 `ask` 를 MCP 서버로 내놓는다. 모델이 `mcp__core__ask({questions:[{question, header?, options, multiSelect?}], confirm?})`(최대 4개, 선택지는 `{label, description?, kind?, payload?}`, 질문 하나면 `{question, options, multiSelect?, confirm?}` 도 된다)를 부르면 서버가 질문을 사이드 채널에 기록하고 `askId` 를 돌려준다. 엔진은 그 결과를 보는 즉시 `ask` 이벤트와 `done(ask)` 로 턴을 닫고, 사람의 답은 다음 턴의 `TurnInput.answer` 로 받는다. 승인이 필요한 툴 도구는 `requireApproval` 로 그 답을 한 번만 소비한다.

core 는 이 패키지에 기대지 않는다. 서버를 띄우는 설정은 소비자가 `coreToolsSpec` 칸에 넣는다.

## 가장 짧은 예제

```ts check
import { createSideChannel } from '@agent-relay-engine/core';
import { claudeProfiles, createClaudeEngine } from '@agent-relay-engine/claude';
import { withAskServer } from '@agent-relay-engine/ask';
import { FsSideStore } from '@agent-relay-engine/side-fs';

const sideRoot = '.agent-relay-engine/my-tool';
const config = withAskServer(
  { ...claudeProfiles.conversation, cwd: './work', namespace: 'my-tool' },
  { sideRoot, ttlMs: 30 * 60_000 },
);
const engine = createClaudeEngine(config, { side: createSideChannel(new FsSideStore(sideRoot), 'my-tool') });
```

`withAskServer` 는 `askServerSpec()` 으로 bin `agent-relay-engine-ask` 를 띄우는 `McpServerSpec` 을 만들어 `coreToolsSpec` 에 넣는다. 엔진이 이것을 `mcpServers.core` 로 합치고 `mcp__core__ask` 를 허용 목록에 더한다. Codex 엔진에서도 같다.

## 개념

### 1. 별도 프로세스 — `withAskServer`

- `sideRoot` 는 엔진의 `deps.side` 와 **같은 저장소**여야 한다. 다르면 엔진이 서버가 남긴 질문을 못 보고 모든 답이 `error(ask-mismatch)` 가 된다.
- `namespace` 를 생략하면 `config.namespace` 를 쓴다.
- `ttlMs` 는 질문 기록 ttl 과 `AskPolicy.defaultTtlMs`(승인 ttl)를 함께 맞춘다. 어긋나면 질문과 승인 중 한쪽이 먼저 사라진다.
- `runtime` 은 `'dist'`(기본, 빌드한 JS)와 `'source'`(이 저장소 안 개발용, tsx 로 src 를 돈다)다.
- `AskPolicy.enabled:false` 면 `coreToolsSpec` 이 있어도 서버를 띄우지 않는다.
- 세션 문맥은 엔진이 붙인다. 기본(`mcpContext:'env'`)은 서버 env 의 `AGENT_RELAY_ENGINE_SESSION_ID`·`_TURN_ID`·`_INVOKER`·`_SCOPE`(쉼표), `'args'` 면 `--session-id --turn-id --invoker --scope` 인자다.
- 서버는 살아 있는 동안 여러 턴을 넘긴다. 질문 기록의 turnId 는 호출마다 턴 문맥 창구(`readTurnContext`)에서 읽는다. 창구가 없거나(`'args'` 모드 등) 읽지 못하면 env·인자의 turnId(서버를 띄운 턴)를 쓴다.

bin 을 직접 띄울 때의 인자: `--side-root <dir> --namespace <ns> [--ask-ttl-ms <n>]` 에 문맥은 env 또는 인자로. 둘 다 있으면 칸마다 env 가 이긴다(`parseAskServerArgs(argv, env = process.env)`). stdout 은 MCP 전용이고 진단은 stderr 로만 낸다.

### 2. 툴 서버에 합치기 — `registerCoreTools`

툴이 이미 MCP 서버를 띄운다면 프로세스를 하나 더 두지 않고 그 서버에 `ask` 를 등록한다. `adaptMcpServer` 가 SDK `McpServer` 를 코어의 `McpServerLike` 로 맞춘다(JSON Schema → `z.fromJSONSchema`, 핸들러 예외 → `isError` 결과).

```ts check
import { createSideChannel } from '@agent-relay-engine/core';
import { adaptMcpServer, parseAskServerArgs, registerCoreTools } from '@agent-relay-engine/ask';
import { FsSideStore } from '@agent-relay-engine/side-fs';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';

const a = parseAskServerArgs(process.argv.slice(2));
const ctx = { sessionId: a.sessionId, turnId: a.turnId, invoker: a.invoker, scope: a.scope,
              side: createSideChannel(new FsSideStore(a.sideRoot), a.namespace) };
const server = new McpServer({ name: 'tool', version: '1.0.0' });
registerCoreTools(adaptMcpServer(server), ctx, { ttlMs: a.askTtlMs });
```

- `adaptMcpServer(server, opts?)` 는 `registerTool(name, config, cb)` 만 요구하는 구조적 타입(`ToolRegistrar`)을 받는다. 소비자가 자기 `node_modules` 의 SDK 로 만든 서버를 그대로 넘길 수 있다. 소비자 zod 를 쓰려면 `adaptMcpServer(server, { z })` 다.
- 엔진 쪽에서는 이 툴 서버를 `mcpServers.tool` 에 넣고 Claude 백엔드면 `claude.coreToolsHost: 'tool'` 로 지정한다. 엔진은 별도 ask 서버를 띄우지 않는다. 모델이 보는 이름은 `mcp__tool__ask` 이고, 허용 목록 자동 추가는 `coreToolsSpec` 경로에만 있으므로 `permissions.allowedTools` 에 `mcp__tool__ask` 를 직접 넣는다.

### 승인 흐름

```mermaid
sequenceDiagram
  participant M as 모델(CLI)
  participant A as ask 서버
  participant S as 사이드 채널
  participant E as 엔진
  participant H as 사람(UI)
  participant T as 툴 서버
  M->>A: ask({question, options:[{label:'진행', kind:'approve', payload:{tool, argsHash}}], confirm:true})
  A->>S: put asks/<sid>/<askId>, asks/<sid>/.last
  A-->>M: tool_result {askId}
  E-->>H: ask 이벤트 → done(ask)
  H->>E: turn({answer:{askId, answers:[{labels:['진행']}]}})
  E->>S: approvals.clear(sid) — 매 턴 앞, 지난 승인 무효화
  E->>S: lastAskId == askId? → approvals.record({approved, bind})
  E->>M: 답을 문장으로 바꿔 보낸다
  M->>T: deploy({..., confirm: askId})
  T->>S: requireApproval → approvals.consume(sid, askId, tool, hash(args − confirm))
  S-->>T: ok 또는 {missing|used|mismatch|expired|denied}
  T-->>M: 결과, 실패면 모델이 읽고 고칠 수 있는 안내문
```

- **승인으로 인정하는 답**: `confirm:true` 질문에서 `kind:'approve'` 선택지 **하나만** 골랐고 그 라벨이 질문 안에서 유일하며, 그 질문의 기타 입력이 비었을 때. `payload` 가 있으면 `{tool, argsHash}` 모양이어야 하고 그 도구·인자에만 묶인다. 애매하면 전부 거부다 — 거부는 다시 물으면 되지만 잘못된 승인은 되돌릴 수 없다.
- `requireApproval(ctx, {tool, args, confirm})` 은 최상위 `confirm` 을 뺀 인자를 `hashArgs`(키 정렬 JSON 의 sha256)로 대조한다. `confirm` 이 askId 모양(32자리 hex)이 아니면 저장소를 건드리지 않고 `missing` 이다. 실패 이유별 안내문은 `approvalMessages` 에 있다.
- **무효화**: 엔진은 매 턴 앞에서 지난 승인을 모두 무효로 만들고, 답이 아닌 일반 메시지면 마지막 질문 포인터도 지운다 — 옛 질문 카드에 늦게 답해 승인이 되살아나지 않게. `EngineDeps.onAnswer` 를 직접 넘기면 마지막 질문 대조를 잃으니 `recordAnswer` 를 감싸 쓴다.

### 가짜 CLI 에서

가짜 CLI 는 MCP 서버를 띄우지 않고 ask 결과만 재생한다. 서버가 남겼을 기록이 없으면 답 턴이 `ask-mismatch` 가 되므로, 가짜 모드에서는 `ask` 이벤트를 받은 자리에서 `recordFakeAsk(side, sessionId, ev)`([testing](../testing/README.md#recordfakeask))로 같은 기록을 남긴다.

### 실측으로 확인한 것

- `fromJSONSchema` 로 만든 스키마를 실제 Claude CLI 가 받는다. `started.mcpServers` 에 `{name:'core', status:'connected'}` 가 보인다.
- 질문 뒤 ask 끊기(interrupt)가 받아들여지고, 답 턴은 같은 프로세스에서 돈다.
- 확인하지 않은 것: `runtime:'source'` 로 띄운 서버를 실제 CLI 에 붙이는 경우.

## 공개 API

<!-- gen:api @agent-relay-engine/ask . -->
`@agent-relay-engine/ask` — 18개, 공개 API 스냅샷 1.8.13 기준.

| 종류 | 이름 |
|---|---|
| function | `adaptMcpServer` · `askServerSpec` · `createAskServer` · `parseAskServerArgs` · `withAskServer` |
| const | `ASK_BIN` · `ASK_SERVER_NAME` · `askBinPath` · `registerCoreTools` |
| interface | `ToolRegistrar` |
| type | `AdaptMcpServerOptions` · `AskServerArgs` · `AskServerContext` · `AskServerOptions` · `AskServerSpecOptions` · `JsonSchemaToZod` · `ToolTextResult` · `WithAskServerOptions` |
<!-- /gen -->

## 설정

`withAskServer(config, options)`·`askServerSpec(options)`

| 옵션 | 기본 | 뜻 |
|---|---|---|
| `sideRoot` | 필수 | `FsSideStore` 루트. 엔진 `deps.side` 와 같아야 한다 |
| `namespace` | `withAskServer` 는 `config.namespace`, `askServerSpec` 은 필수 | 사이드 채널 네임스페이스 |
| `ttlMs` | `withAskServer` 는 `config.ask.defaultTtlMs`, 없으면 서버 기본 | 질문 기록 ttl(`--ask-ttl-ms`). `withAskServer` 는 승인 ttl 도 같은 값으로 맞춘다 |
| `runtime` | `'dist'` | `'source'` 는 저장소 안 개발용 |

| 의존 | 범위 |
|---|---|
| `@modelcontextprotocol/sdk`(peer) | `^1.32.1` |
| `zod`(peer) | `^4.2.0`(`fromJSONSchema` 가 있는 버전). 범위 밖 버전을 소비자가 직접 의존하면 npm 이 `ERESOLVE` 로 설치를 거부한다 |

## 다른 문서

- [core README](../core/README.md#ask-와-승인-바인딩) — 답·승인 바인딩 계약
- [설치 가이드](../../docs/consumers/packaging.md) — peer 의존

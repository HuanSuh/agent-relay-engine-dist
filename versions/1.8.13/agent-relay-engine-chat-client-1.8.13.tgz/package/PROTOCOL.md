# 채팅 프로토콜 (HTTP + SSE)

`@agent-relay-engine/chat-client` 가 기본 transport(`createSseHttpTransport`)로 말하는 서버 계약. 타입은 [`src/protocol.ts`](src/protocol.ts) 가 정본이고, 이 문서는 그 설명이다.
참조 구현은 [`@agent-relay-engine/chat-server`](../chat-server/)(Node 에서는 이것을 그대로 쓴다)와 그것을 쓰는 [`examples/sse-server`](../../examples/sse-server/). 다른 서버(다른 언어 포함)도 아래를 지키면 `<agent-relay-engine-chat>` 을 그대로 붙일 수 있다.

경로는 모두 `endpoint`(기본 `/api`) 뒤에 붙는다. POST 본문은 `content-type: application/json` 이고, 실패 응답(4xx·5xx)은 `{ error: string }` 이다.

## 상태의 출처

- **기록**(`GET /sessions/:id/chat` 의 `items`)과 **이벤트 길**(SSE) 둘뿐이다. POST 응답은 접수 확인일 뿐이고 결과는 SSE 로 온다.
- 기록 항목은 세션마다 `seq` 가 1부터 늘어난다. 클라이언트는 기록을 읽는 동안 온 `chat` 을 모았다가 기록 뒤에 `seq` 로 걸러 붙인다(중복·순서 뒤바뀜 방지).
- 서버가 늦게 읽은 저장 기록과 그 사이 받은 턴을 합치면 앞서 보낸 `seq` 가 다른 항목을 가리킬 수 있다. 그때 서버는 `reload:true` 인 `session` 을 보낸다. 클라이언트는 그 세션을 열고 있으면 기록(`GET /sessions/:id/chat`)을 다시 읽고, 옛 `seq` 에 묶어 둔 상태는 버린다(1.8.3). 재연결 재생(`hello{replayed:true}` 뒤)으로 받은 `reload` 도 아직 처리하지 않은 신호이므로 똑같이 처리한다. 저장된 기록이 없어 `seq` 가 밀리지 않았으면 서버는 `reload` 를 보내지 않는다.
- `chat-delta` 는 화면용 조각이고 기록에는 같은 `turnId` 의 `text` 항목만 남는다. `text` 가 오면 조각 말풍선을 확정한다.

## HTTP

| 요청 | 응답 | 뜻 |
|---|---|---|
| `POST /chat` `{sessionId?, content?, mode?:'turn'\|'inject', answer?:{askId, answers?:[{labels[], other?}], labels?[], other?}, clientMessageId?}` | 202 `{sessionId, queued, duplicate?:'executed'}` | 턴 보내기. `content:''`(answer 없이) = [이어서 하기] resume 턴. `answer` 는 ask 질문의 답(아래 'ask 질문 묶음과 답')이고 `mode:'inject'`·`content` 와 함께 보내면 400 이다(1.8.0). `queued:true` 면 앞 턴이 돌고 있어 서버 큐에 들어갔다. 같은 `clientMessageId` 의 입력이 이미 실행된 적 있으면(재기동 뒤에도, 세션 기록을 보고) 엔진에 넘기지 않고 이 응답을 준다. 그때 `duplicate:'executed'` 를 싣는다. 같은 cmid 가 지금 돌거나 큐에 있으면 `duplicate` 칸은 없고 엔진의 `running`·`queued` 로 답한다(기존처럼 같은 cmid 의 서버 항목을 기다린다). 시작 전에 실패한 입력의 cmid 는 막지 않는다. `duplicate:'executed'` 를 받은 칸은 기다리지 않고 보낸 말풍선으로 확정하며, 같은 cmid 의 서버 항목이 오면 그 자리를 채운다 |
| `POST /permission` `{sessionId, requestId, behavior:'allow'\|'deny', message?, remember?:{tool, prefix?}}` | `{ok, preapproved?, rule?}` | 승인 답. `ok:false` = 엔진이 이미 거둔 요청(결말은 `permission-cancelled`). 그때의 늦은 허용은 `preapproved:true` 로 사전 승인됐을 수 있다. `remember`("항상 허용")는 allow 에만, 성공하면 `rule` 로 기억된 규칙을 돌려준다 |
| `POST /stop` `{sessionId}` | `{sessionId, via}` | `via`: `control`·`signal`·`pending`(시작 전 대기만 거둠)·`none`(중지할 턴 없음) |
| `POST /chat`·`/permission`·`/stop` 거부 | 4xx `{error}` | 서버의 결정 권한 훅이 거부했다(보통 403). 엔진에 가지 않았으므로 승인 카드·ask 는 열린 채 남는다 — 다른 사람이 답할 수 있다. 결정 권한을 쓰는 서버는 기록에 없는 질문의 답을 404, 이미 답한 질문의 답을 409 로 거부한다. 처리 중인 같은 질문의 답(409), 끼워 넣을 턴이 없어진 끼워 넣기(409 `끼워 넣을 턴이 없다 — send 로 보내라`, 보통 턴으로 다시 보낸다)도 있다(1.8.0) |
| `GET /sessions` | `{sessions: SessionSummary[]}` | `SessionSummary = {id, title, createdAt, updatedAt, busy, waiting}` |
| `GET /sessions/:id/chat` | `SessionSummary & {items: ChatItem[], capabilities, usage}` | 404 = 서버에도(`history` 저장소가 있으면 그 저장소에도) 없는 새 대화(빈 기록으로 본다). 저장소가 있으면 재기동 뒤에도 기록이 되살아나 200 이다 |
| `GET /sessions/:id/status` | `SessionSummary & {engine, capabilities, usage}` | 관측용(클라이언트 스토어는 쓰지 않는다). `engine` 은 `sessionId`·`started`·`process`·`queueDepth`·`lastActivityAt?`·`usage?`·`awaitingPermissionSince?`·`backend?`·`lease?` 만 있고, `lease` 는 `{sessionId, expiresAt}` 이다 — 엔진의 `owner` 는 내지 않는다(1.8.2) |
| `GET /metrics` | `{counters, pool}` | 관측용. `pool.sessions` 는 그 범위의 세션만, 칸은 `status` 의 `engine` 과 같다(1.8.2) |
| `GET /events?last=<id>` | SSE | 아래 |

### 기록 항목 `ChatItem`

공통 `{seq, turnId, at}` 에 `kind` 별 칸:

| kind | 칸 |
|---|---|
| `user` | `text, clientMessageId?, clientMessageIds?, author?, authors?, mode?:'inject'` — `clientMessageIds` 는 coalesce 로 한 턴에 합쳐진 입력들의 cmid(보낸 순서). 이 항목 하나가 그 대기 칸들을 모두 확정한다(1.2.1). `author: {id, name?}` 는 보낸 사람이다 — 서버의 신원 훅이 정한 값이고 `POST /chat` 본문의 author 는 받지 않는다. `authors` 는 합쳐진 입력들의 보낸 사람(입력 순서, id 중복 없음). 신원을 정하지 않는 서버는 두 칸이 없다(1.7.0). `answer?: {askId, decidedBy?}` 는 이 글이 ask 답일 때 그 askId 와 답한 사람이다(1.8.0) |
| `text` | `text` |
| `tool` | `toolId, name, server?, args, result, isError, approval?` — `approval.kind`: `asked`·`rule`(+label)·`preapproved`·`auto`·`unasked` |
| `ask` | `askId, question, options:[{label, description?, kind?, payload?}], multiSelect?, questions?, confirm?, requesters?, decidedBy?` — 아래 'ask 질문 묶음과 답'. `requesters: string[]` 는 질문을 낸 턴의 요청자 id, `decidedBy: {id, name?}` 는 답한 사람이다(엔진이 답을 받은 뒤 이 칸을 고친다, 1.8.0) |
| `permission` | `requestId, toolName, displayName?, input, outcome?, suggest?:{tool, prefix?}, requesters?` — `requesters: string[]` 는 승인을 낸 턴의 요청자 id 다(1.8.0) |
| `permission-denied` | `items:[{toolName, toolUseId?, toolInput?}]` |
| `permission-timeout` · `permission-preapproved{toolName}` · `permission-rule{toolName, rule, label}` | 카드 없이 지나간·거둔 승인의 알림 |
| `interrupted` | `via:'control'\|'signal'` |
| `error` | `message, reason, resumable, why?, clientMessageId?, clientMessageIds?` — `clientMessageId` 는 core.input 이 나오기 전에 끝난 턴(시작 전 실패)의 요청 cmid다. `clientMessageIds` 는 합쳐진 머리였을 때 머리와 꼬리 cmid 전부다. 목록의 보내기 칸을 모두 `failed` 로 바꾼다(1.2.1). `why` 는 엔진 error 의 `detail.why` 가 영문·숫자·`-`·`_` 64자 이하 문자열일 때만 싣는 선택 칸이다(그 밖의 detail 은 싣지 않는다, 1.8.9). 클라이언트도 같은 모양만 받는다. 미뤄 닫는 고아 칸 오류 항목에는 `why` 가 없다 |

### ask 질문 묶음과 답

- `questions: [{question, header?, options, multiSelect?}]`(1~4개)이 정본이다. `question`·`options`·`multiSelect` 는 첫 질문의 사본이라 옛 클라이언트도 첫 질문은 그린다. `questions` 가 없는 항목(옛 서버·기록)은 옛 칸을 질문 하나로 읽는다.
- `multiSelect` 가 없거나 false 면 그 질문은 선택지 하나만 고른다(라디오). true 면 여러 개를 함께 고른다. 선택지 `description` 은 설명 줄이다.
- 답(`POST /chat` 의 `answer`): 묶음이면 `{askId, answers:[{labels[], other?}]}`(질문 순서대로, 길이 = 질문 수). 질문 하나면 옛 모양 `{askId, labels[], other?}` 도 그대로 받는다(서버는 둘 다 받아야 하고, `answers` 가 있으면 그것만 쓴다). 클라이언트 스토어는 질문 하나면 옛 모양으로 보낸다. 답 수가 질문 수와 다르면(옛 클라이언트가 묶음의 첫 질문만 답한 경우) 엔진은 턴을 `error{reason:'ask-mismatch'}` 로 끝낸다. 승인 질문(`confirm`)에서 승인 선택지와 함께 기타를 적으면 거부로 기록된다.
- 엔진이 답을 다음 사용자 발화로 바꾼다: 질문 하나면 `선택: A, B` / `기타: …` 줄, 묶음이면 `1. 선택: A` · `2. 선택: x, y / 기타: …` 처럼 질문 번호마다 한 줄. 기록의 `user` 항목에 이 문장이 남는다.

`permission.outcome`(결말): `{behavior:'allow', rule?, decidedBy?}` · `{behavior:'deny', message?, decidedBy?, via?, overridden?}` · `{behavior:'timeout'}` · `{behavior:'preapproved', decidedBy?}` · `{behavior:'closed', reason?: 'turn-ended'|'stopped'|'disposed'|'evicted'}`.
기록은 덧붙이기만 하지만 승인 항목의 `outcome` 칸만은 결말이 나면 고친다 — 새로고침 뒤에도 카드가 닫혀 보이게. `decidedBy: {id, name?}` 는 답한 사람(서버의 신원 훅이 정한 값)이다. 감사용이고 신원을 정하지 않는 서버는 칸이 없다(1.8.0). ask 항목의 `decidedBy` 도 같은 뜻이다. ask 쪽은 새 SSE 이벤트가 없고, 답 글(`user`)의 `answer` 칸으로 알린다.
엔진이 받은 허용을 정책으로 거절해 보냈으면 서버가 그 카드의 결말을 `{behavior:'deny', via:'policy', overridden:{behavior:'allow', rule?, decidedBy?}}` 로 고치고 `permission-settled` 를 같은 `requestId` 로 다시 보낸다(1.8.11). 클라이언트는 받은 결말로 바꾼다 — 새 이벤트가 아니라 옛 클라이언트도 거절로 보인다. `overridden` 은 진 허용(그 사람·기억한 규칙 표기)이고 바깥 `decidedBy` 는 없다. 고친 결말을 받은 뒤 도착한 `POST /permission` 응답(`{ok:true}`)으로 결말을 허용으로 되돌리지 않는다. `overridden.rule` 이 있으면 진 허용이 "항상 허용" 규칙을 남겼다는 뜻이다(규칙은 저장돼 남는다). 한계: `overridden` 을 싣지 않는 옛 엔진에서 결정 알림이 서버의 허용 결말보다 먼저 오면 카드는 허용으로 남는다.

## SSE

- 이벤트 id 는 `<기동·길 표시>-<번호>`(클라이언트는 불투명하게 다루고 `?last=` 로 돌려주기만 한다). 서버는 최근 이벤트를 링에 두고 `?last=`(또는 `Last-Event-ID`) 뒤의 것만 다시 보낸다.
- 빈틈 없이 채울 수 없으면(다른 기동, 링 밖) `hello{replayed:false}` 만 보낸다 → 클라이언트는 세션 목록과 기록을 다시 읽는다.
- `hello.bootId` 가 처음 본 값과 다르면 **서버가 다시 떴다**. 브라우저 UI 는 페이지를 새로 받는다(옛 코드가 새 이벤트를 못 그리지 않게). 그때 마지막 승인 카드가 답을 기다리던 중이었으면 새 페이지가 resume 턴을 보내 모델이 같은 요청을 다시 내게 한다.
- `: ping` 주석 줄(기본 15초)은 이벤트가 아니다. 모든 세션의 이벤트가 한 길로 흐르고 클라이언트가 `sessionId` 로 거른다.

### 재연결 (1.7.0)

- **끊김.** 네트워크가 끊기거나 서버가 스트림을 끝내면(네이티브 `EventSource` 의 `readyState` 가 CONNECTING) 클라이언트는 `reconnectMs`(기본 1초) 뒤 `?last=` 로 다시 붙는다. `hello` 없이 끊김이 이어지면 간격을 두 배씩 늘린다(상한 `maxReconnectMs`).
- **거절.** 서버가 `GET /events` 를 4xx·잘못된 응답으로 받지 않으면(`readyState` 가 CLOSED) 바로 다시 붙지 않는다. 같은 길로 `GET /sessions` 를 보내 상태를 본다.
  - 401·403 이면 다시 붙지 않고 연결 상태를 `denied` 로 둔다. 사람이 다시 시도해야 한다(`store.reconnect()`). 판정은 오류의 `status` 숫자로 한다.
  - 그 밖(성공, 404, 5xx, 네트워크 오류, 10초 안에 답 없음)이면 `reconnectMs` 에서 두 배씩 늘려(상한 `maxReconnectMs`, 기본 30초) 다시 붙는다. `hello` 를 받으면 간격은 처음으로 돌아간다.
- 서버가 권한을 거두며 연결을 끊으면(`handler.disconnect`) 클라이언트는 다시 붙다가 `authorize` 거부를 받고 이 규칙으로 멈춘다.

| event | data | 클라이언트 처리 |
|---|---|---|
| `hello` | `{bootId, replayed, pingMs}` | 연결됨. 위 규칙 |
| `session` | `SessionSummary & {reload?: true}` | 목록에 넣는다. `reload:true` 면 그 세션의 기록이 합쳐져 `seq` 가 바뀌었다 — 열린 세션이면 기록을 다시 읽는다(1.8.3). 모르는 칸이라 무시하는 클라이언트는 다음 다시 읽기 때까지 옛 기록을 보인다 |
| `chat` | `{sessionId, item: ChatItem}` | 기록 항목 추가(`seq` 중복 제거) |
| `chat-delta` | `{sessionId, turnId, text}` | 조각 말풍선에 이어 쓴다 |
| `tool-start` | `{sessionId, turnId, toolId, name, server?}` | 실행 중 도구 카드(같은 `toolId` 의 `tool` 항목이 오면 바꾼다) |
| `chat-idle` | `{sessionId, turnId?, stopReason, busy, waiting}` | 턴의 done. `stopReason:'ask'` 면 답 기다림. 끼워 넣기의 done 이면 `busy:true` |
| `state` | `{sessionId, busy, waiting}` | 바쁨·대기 수 |
| `queued` | `{sessionId, turnId?, reason:'engine'\|'pool', position, busy, waiting}` | 큐 순번 또는 프로세스 자리 기다림 |
| `ask` | `{sessionId, turnId, askId}` | 질문 기록이 남은 뒤 |
| `permission` | `{sessionId, turnId, requestId}` | 승인 기록이 남은 뒤 |
| `permission-settled` | `{sessionId, requestId, outcome}` | 사람이 답한 결말. 정책이 덮은 허용이면 같은 `requestId` 로 고친 결말이 다시 온다(1.8.11) — 받은 값으로 바꾼다 |
| `permission-cancelled` | `{sessionId, requestId, reason, outcome}` | 엔진이 답 없이 거둔 요청(`reason`: `timeout`·`turn-ended`·`stopped`·`disposed`·`evicted`) |
| `accepted` | `{sessionId, turnId, mode, clientMessageId?}` | 엔진의 접수 확인(inject 가 실제 inject 였는지 `mode` 로) |
| `interrupted` | `{sessionId, turnId, via}` | 중지 확인 |
| `usage` | `{sessionId, turnId, usage}` | 토큰·비용·구독 사용률(`subscription` 이 없는 턴은 마지막 값을 유지) |
| `capabilities` | `{sessionId, turnId, capabilities[]}` | `text-delta`·`accepted-ack`·`inject`·`control-interrupt`·`control-approval`·`subscription-usage` |

모르는 이벤트 이름·항목 `kind` 는 무시한다(서버가 먼저 늘릴 수 있게).

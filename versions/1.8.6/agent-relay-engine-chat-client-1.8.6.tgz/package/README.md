# @agent-relay-engine/chat-client

채팅 화면의 **헤드리스** 층. 서버 이벤트·기록 → 화면 모델(`ChatState`) 리듀서, 요청 액션, 재연결·재시작 처리를 담는다. 런타임 의존성이 없고 브라우저·Node 모두에서 돈다.
화면은 [`@agent-relay-engine/chat-ui`](../chat-ui/README.md)(웹 컴포넌트)를 쓰거나, 이 패키지만 가져다 자기 프레임워크로 그린다.

서버 계약(HTTP `/api/*` + SSE)은 [PROTOCOL.md](PROTOCOL.md), 타입은 `src/protocol.ts`.

레지스트리에 발행하지 않는다. 설치는 [설치 가이드](../../docs/consumers/packaging.md)의 tarball 로 하고, 워크스페이스에서는 `"@agent-relay-engine/chat-client": "*"` 다.

## 가장 짧은 예제

```ts check
import { createChatStore, createSseHttpTransport, sessionList, statusTone } from '@agent-relay-engine/chat-client';

const store = createChatStore(createSseHttpTransport({ endpoint: '/api' }), { sessionId: 'abc' });
store.subscribe((s) => console.log(s.items.length, s.status, statusTone(s.status), sessionList(s).length));
store.start();               // 이벤트 길을 연다 — hello 가 오면 세션 목록·기록을 읽는다
await store.send('안녕');
```

## 개념

### 상태 `ChatState`

| 칸 | 뜻 |
|---|---|
| `sessionId`, `sessions` | 지금 세션, id → 요약. 화면 목록은 `sessionList(state)`(최근 순, 아직 서버에 없는 지금 세션 포함) |
| `items: ViewItem[]` | 화면 칸. `type`: `user`(`delivery` — 보내기 중 `pending`·실패 `failed`, `error`·`clientMessageId`·`clientMessageIds`·`inject`·`mode`. 확정되면 `delivery` 가 없다. 아래 참고)·`assistant`(`streaming`)·`tool`(`pending`, `approval`)·`ask`(`questions`, `selected`, `phase` — `askReady(item)` 이면 보낼 수 있다)·`permission`(`phase`, `outcome`, `suggest`)·`denied`·`preapproved`·`rule`·`permission-timeout`·`interrupted`·`error`(`superseded` 는 뒤에 사람 글이 왔거나 다음 입력이 시작돼 접힌 오류). `key` 는 스트리밍→확정, 실행 중→결과에도 그대로다. 보내기 중 칸의 key 는 `local:<clientMessageId>` 이고 서버 항목이 오면 서버 key 로 바뀐다(같은 자리). 대기 칸은 늘 목록 맨 끝에 있다(보낸 순서). `at?`(1.1.0)은 기록 항목의 시각(`ChatItem.at`, epoch ms)이고, 스트리밍 말풍선·실행 중 도구 카드처럼 아직 항목이 없는 칸은 비어 있다가 확정되면 채워진다 |
| `status: Status` | 상태줄 코드(`idle`·`busy`·`waiting-answer`·`waiting-permission`·`queued{position}`·`pool-wait`·`turn-error{…}`·`send-failed{message}` …). 문구는 그리는 쪽이 고른다. `statusTone(status)` = `''`·`busy`·`error` |
| `busy`, `waiting` | 턴이 도는 중, 대기 중인 턴 수. `canStop(s)`, `canInject(s)` |
| `ack` | 엔진 확인 신호 `{kind:'accepted', mode}` · `{kind:'interrupted', via}` |
| `resumable` | 마지막 오류가 이어서 할 수 있는 것([이어서 하기]). `beginInput()` 이 지운다 |
| `capabilities`, `usage`, `subscription` | `subscription` 은 마지막으로 읽은 구독 사용률 — 세션을 바꿔도 유지 |
| `connection` | `connecting`·`open`·`closed`(끊겨 다시 붙는 중)·`denied`(서버가 연결을 거부했다 — 401·403, 1.7.0. 다시 붙지 않고 `reconnect()` 를 기다린다) |
| `restarted`, `restartResume` | 서버 재시작을 봤다 / 그때 승인을 기다리던 중이었다 |

### 보내기 칸의 확정 (1.2.0·1.2.1)

- 칸을 확정하는 것은 서버의 사람 항목뿐이다. 항목의 `clientMessageId`(머리)나 `clientMessageIds`(합쳐진 모든 입력)에 든 칸이 모두 확정된다(1.2.1). 턴이 끝났다거나 `accepted` 가 왔다는 것으로는 확정하지 않는다.
- 큐에 들어간 턴의 칸은 서버가 그 턴을 시작할 때 항목을 쓰므로, 시작 전까지 `delivery:'pending'` 으로 남는다.
- 시작 전에 끝난 턴의 `error` 항목이 `clientMessageId` 를 싣고 오면 그 칸은 `failed` 가 되고 오류 문구를 `error` 에 둔다(1.2.1).
- `duplicate`(같은 cmid 의 재전송)는 원래 입력이 기록에 있으면 그 칸을 바로 지운다.
- `duplicate:'executed'`(서버가 영속 기록으로 실행됐다고 알림, WU-18)를 받은 칸은 기다리지 않고 보낸 말풍선(`provisional`)으로 확정한다. 말풍선은 칸이 아니라 자기 자리에 고정된 user 항목(`provisional`)이라 뒤의 턴이 그 위에 쌓여도 제자리에 남는다. 같은 cmid 의 서버 항목이 오면 그 자리를 채운다. 같은 세션을 다시 읽을 때 기록에 그 서버 항목이 없으면 말풍선은 남고, 다른 세션으로 갔다 돌아와도 되찾는다(다른 세션에는 보이지 않는다).
- 기록을 다시 읽어도 같은 세션의 `pending`·`failed` 칸은 남는다. 기록에 같은 cmid 가 있으면 확정하거나 실패로 바꾼다(1.2.1). 서버가 다시 뜨면(bootId 변경) `pending` 칸은 `failed`(`서버가 다시 시작되었다`)가 된다.
- 실패한 칸은 자기를 실패로 만든 서버 `error` 의 순번(`consumedSeq`)을 기억한다. 재시도로 pending 이 되어도 그 기억은 남아, 기록을 다시 읽을 때 같은 순번 이하의 옛 오류는 칸을 다시 실패로 만들지 않는다(1.2.1). 같은 cmid 의 서버 사람 글은 언제나 칸을 확정한다.
- 서버가 기록을 합쳐 `seq` 가 바뀌었다고 알리면(`reload:true` 인 `session`, 1.8.3) 열린 세션의 기록을 다시 읽는다. 이때 그 세션의 말풍선은 다시 읽은 기록의 끝에 놓이고 접힌 오류는 잊는다 — 옛 `seq` 가 다른 항목을 가리키기 때문이다. 실패 뒤 재시도 중인 칸이 소비한 오류 순번은 다시 읽은 기록에서 그 `clientMessageId` 의 n 번째 오류 순번으로 다시 맞춘다(n 은 칸이 소비한 오류 수 `consumedErrors`) — 기록에 남은 옛 오류가 재시도 칸을 다시 실패로 만들지 않게. 그 뒤의 오류는 재시도 자신의 것이라 칸을 실패로 만든다. 재연결 재생으로 받은 `reload` 도 똑같이 처리한다.
- `discard` 한 글을 서버가 이미 받았다면 나중에 서버 항목으로 다시 나타난다. 서버가 실제로 실행했기 때문이며 맞는 동작이다.

### 액션

| 액션 | 뜻 |
|---|---|
| `start()` · `dispose()` | 이벤트 길 열기(끊기면 `reconnectMs` 뒤 마지막 id 로 다시 붙는다. 서버가 거절하면 [재연결 규칙](PROTOCOL.md#재연결-170)) · 정리 |
| `reconnect()` | 이벤트 길을 닫고 바로 다시 연다. 기다리던 재연결과 늘어난 간격을 버린다. `denied` 뒤 사람이 다시 시도할 때 부른다 (1.7.0) |
| `newSession()` · `select(id)` | 새 대화 / 세션 열기(기록을 다시 읽는다) |
| `send(text)` · `inject(text)` | 턴 보내기 / 진행 중인 턴에 끼워 넣기. 빈 글은 `false`. POST 를 기다리지 않고 사람 글 칸(`delivery:'pending'`)을 먼저 넣는다(1.2.0). 못 보내면 그 칸이 `delivery:'failed'`·`error` 로 남고 상태줄은 `send-failed` |
| `retry(clientMessageId)` | failed 칸을 같은 `clientMessageId` 로 다시 보낸다(서버는 그 키를 멱등 키로 다룬다). failed 가 아니면 `false` (1.2.0) |
| `discard(clientMessageId)` | failed 칸을 지운다. pending 칸은 지우지 않고 `false` 를 돌려준다 (1.2.0). 서버가 이미 받은 글이면 나중에 서버 항목으로 다시 나타난다(1.2.1) |
| `beginInput()` | 새 입력을 시작한다(1.2.0). 상태가 `turn-error`·`send-failed` 면 `idle`(바쁘면 바쁜 상태)로 돌리고, 열린 오류 칸에 `superseded:true` 를 단다. 승인·질문 대기 상태는 덮지 않는다. `resumable` 은 건드리지 않는다 — `send`·`inject` 가 보냈을 때 지운다(1.2.1). `send`·`inject`·`resume` 이 먼저 부른다. 화면은 입력칸의 첫 `input` 에서 부른다 |
| `stop()` | 중지. 중지할 턴이 없으면 `status:'nothing-to-stop'` |
| `resume()` | [이어서 하기] — 빈 content 로 resume 턴. 성공하면 POST 전에 열려 있던 오류 칸만 접는다(1.2.1). 보내는 동안 새로 온 오류는 열린 채 남는다 |
| `selectAskOption(askId, index, label)` · `setAskOther(askId, index, text)` | ask 카드의 질문별 선택 상태(`item.selected[index]`)를 바꾼다. 단일 선택 질문은 라디오처럼 그것만 켜지고 복수(`multiSelect`)는 켜고 끈다 |
| `answerAsk(askId, answers?)` | 질문에 답. 생략하면 카드의 `selected` 를 보낸다. 질문별 배열 `[{labels, other?}]` 이나, 질문 하나짜리면 짧은 모양 `{labels, other?}` 도 받는다. 답 없는 질문이 있으면 `ask-empty` |
| `answerPermission(requestId, {behavior:'allow'} \| {behavior:'deny', message?}, remember?)` | 승인 답. `remember:{tool, prefix?}` 는 "항상 허용"(allow 만, 빈 접두·`*` 는 `bad-prefix`) |
| `reloadAll()` | 세션 목록과 지금 세션 기록을 다시 읽는다 |
| `subscribe(fn)` · `getState()` | 상태 구독 |
| `onNotice(fn)` | 밖으로 알릴 일: `permission`·`ask`(새로 온 요청, 어느 세션이든) · `error`(상태가 오류로 바뀜) · `restart` · `session` |

리듀서만 쓰려면 `reduce(state, action)` + `initialState(sessionId)` — 서버 이벤트(`{type, data, id?}`)와 `local/*` 액션을 받는 순수 함수다.

### Transport 직접 구현

스토어는 `Transport` 만 본다. 다른 경로·인증 헤더·WebSocket 서버면 직접 짠다.

```ts
import { createChatStore, type Transport } from '@agent-relay-engine/chat-client';

const ws = new WebSocket('wss://example.test/chat');
const transport: Transport = {
  connect(onEvent, lastId, onClose) {
    ws.onmessage = (m) => onEvent(JSON.parse(m.data)); // {type, data, id?}
    // 서버가 연결을 거절했으면 { permanent: true } — 스토어가 상태 확인 뒤 멈추거나 간격을 늘린다
    ws.onclose = (e) => onClose?.({ permanent: e.code === 1008 });
    ws.onopen = () => ws.send(JSON.stringify({ last: lastId }));
    return { close: () => ws.close() };
  },
  post: (path, body) => fetch(`/api${path}`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: token }, body: JSON.stringify(body) }).then(ok),
  get: (path) => fetch(`/api${path}`, { headers: { authorization: token } }).then(ok),
};
const store = createChatStore(transport);
```

`post`/`get` 은 2xx 면 본문 JSON, 아니면 본문의 `error` 를 메시지로 던져야 한다. 상태 코드는 `new HttpError(status, message)` 로 던지거나 숫자 `status` 칸이 있는 오류로 던진다 — 스토어는 `instanceof` 가 아니라 `status` 숫자로 거부(401·403)를 가린다(1.7.0). `onClose` 에 `{permanent:true}` 를 주면 서버가 연결을 거절했다는 뜻이고, 인자 없이 부르면 끊김으로 본다. 끊김이 `hello` 없이 이어지면 스토어는 간격을 늘리므로 거절을 알리지 않는 transport 도 1초마다 두드리지 않는다. 테스트에는 `createMemoryTransport({ 'GET /sessions': {...}, 'GET /sessions/*/chat': (body, path) => ... })` — `emit(type, data, id?)` 로 이벤트를 흘리고 `drop()` 으로 끊는다.

## 공개 API

<!-- gen:api @agent-relay-engine/chat-client . -->
`@agent-relay-engine/chat-client` — 76개, 공개 API 스냅샷 1.8.6 기준.

| 종류 | 이름 |
|---|---|
| function | `askReady` · `buildAnswer` · `createChatStore` · `createMemoryTransport` · `createSseHttpTransport` · `initialState` · `itemQuestions` · `lastPermissionWaiting` · `lateAnswerable` · `pickOption` · `reduce` · `sessionList` · `statusTone` |
| class | `HttpError` |
| const | `answered` · `canInject` · `canStop` · `emptySelections` · `paths` · `permissionOpen` · `ruleLabel` · `SERVER_EVENTS` |
| interface | `Transport` |
| type | `Action` · `AskAnswer` · `AskAnswerMark` · `AskOption` · `AskQuestion` · `AskQuestionAnswer` · `AskSelection` · `AskView` · `Author` · `Buffered` · `Capability` · `ChatItem` · `ChatItemKind` · `ChatRequest` · `ChatResponse` · `ChatState` · `ChatStore` · `ChatStoreOptions` · `CloseInfo` · `Connection` · `ErrorResponse` · `KeyValueStorage` · `LocalAction` · `MemoryRoute` · `MemoryTransport` · `MetricsResponse` · `Notice` · `PermissionCancelReason` · `PermissionDenial` · `PermissionOutcome` · `PermissionRequest` · `PermissionResponse` · `PermissionView` · `PolicyRule` · `RuleInput` · `RuleSuggestion` · `ServerEvent` · `ServerEventName` · `ServerEvents` · `SessionChatResponse` · `SessionsResponse` · `SessionStatusResponse` · `SessionSummary` · `SseHttpOptions` · `Status` · `StatusCode` · `StopRequest` · `StopResponse` · `Tone` · `ToolApproval` · `Usage` · `ViewItem` · `ViewItemType` |
<!-- /gen -->

## 설정

`createChatStore(transport, options?)`

| 옵션 | 기본 | 뜻 |
|---|---|---|
| `sessionId` | 새 id | 열 세션 |
| `reconnectMs` | `1000` | 끊긴 이벤트 길을 다시 붙기까지. 서버가 거절했는데 거부가 아니면 여기서 두 배씩 늘린다 |
| `maxReconnectMs` | `30000` | 거절 뒤 늘리는 간격의 상한 (1.7.0) |
| `storage` | 없음 | 서버 재시작 뒤 resume 표식을 둘 곳(페이지를 다시 받으면 `sessionStorage`) |
| `onRestart` | 없음 | 서버 재시작을 보면 부른다. 주면 스토어는 멈추고 이것만 부른다. 없으면 새 기동 기준으로 기록을 다시 읽고 필요하면 resume 턴을 보낸다 |
| `newId`, `now` | 내장 | id 만들기·시각(테스트 주입용) |

`createSseHttpTransport({ endpoint })` 의 `endpoint` 기본은 `/api` 다.

## 다른 문서

- [PROTOCOL.md](PROTOCOL.md) — 서버 계약(HTTP + SSE)
- [chat-ui](../chat-ui/README.md) — 이 스토어를 그리는 웹 컴포넌트 · [chat-server](../chat-server/README.md) — Node 서버 구현

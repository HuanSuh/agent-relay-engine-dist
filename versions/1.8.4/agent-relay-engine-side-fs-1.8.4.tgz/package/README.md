# @agent-relay-engine/side-fs

파일시스템 기반 `SideStore` 구현(`FsSideStore`)이다. 키 하나 = 파일 하나이고, 원자성은 같은 디렉터리 안의 `rename`/`link` 에 기댄다. 엔진과 ask MCP 서버처럼 서로 다른 프로세스가 같은 루트를 보고 질문·승인·lease 를 주고받는 데 쓴다. `sideStoreContractSuite` 를 통과한다.

## 가장 짧은 예제

```ts check
import { createSideChannel } from '@agent-relay-engine/core';
import { FsSideStore } from '@agent-relay-engine/side-fs';

const store = new FsSideStore('.agent-relay-engine/my-tool', { pollMs: 1000, nativeWatch: true });
const side = createSideChannel(store, 'my-tool');   // 키는 모두 <root>/my-tool/… 아래
const { ref } = await side.secrets.issue('deploy', 'token-value', 60_000);
console.log(ref);
```

## 개념

### 저장 형식

- **경로**: `<root>/<ns>/<key>`. 키의 `/` 는 디렉터리가 된다. `''`·`.`·`..`·`\`·NUL·중간 파일 접미(`.tmp`·`.consuming`·`.expiring`·`.lock`)가 든 조각은 거부한다.
- **파일 내용**: 앞 8바이트가 만료 시각(epoch ms, big-endian uint64, 0 = 만료 없음), 그 뒤가 값이다. 헤더가 8바이트보다 짧은 파일은 쓰다 만 것으로 보고 없는 것으로 읽는다.
- **만료**: 읽을 때 판정한다. 만료된 키는 `get` 이 null 을 돌려주며 지운다. 별도 청소 프로세스는 없다.

`SideChannel` 이 이 위에 놓는 키(모두 `<ns>/` 아래, 값은 JSON):

| 키 | 쓰는 쪽 | 내용 |
|---|---|---|
| `asks/<sid>/<askId>`, `asks/<sid>/.last` | ask 서버(쓰기), 엔진(읽기) | 질문 기록(`AskRecord`), 마지막 질문 포인터 |
| `approvals/<sid>/<askId>`, `…/<askId>.used`, `…/.epoch` | 엔진(쓰기), 툴 서버(consume) | 승인 기록, 소비 마커, 무효화 epoch |
| `leases/<sid>` | 엔진 | `Lease{owner, expiresAt, token}` — `put ifAbsent` + ttl |
| `sessions/<sid>` | 엔진·툴 | `SessionRecord`(코어는 `started`·`lastUsedAt` 등, 나머지는 `ext`) |
| `secrets/<ref>` | 발급 쪽 / 소비 쪽 | 일회성 비밀. `redeem` 은 consume |
| `artifacts/<id>` | 툴 | 산출물 변경 알림(`touch` → `watch`) |

### 원자성

| 연산 | 방법 | 보장 |
|---|---|---|
| `put` | 같은 디렉터리에 임시 파일을 다 쓴 뒤 `rename` | 읽는 쪽은 옛 값 아니면 새 값만 본다 |
| `put {ifAbsent}` | 다 쓴 임시 파일을 `link()` — 대상이 있으면 `EEXIST` | "없을 때만"과 "완성본만"을 함께 얻는다 |
| 만료 키 넘겨받기 | 키별 `<key>.lock` 을 link 로 잡고 만료 확인 → 삭제 → link | 잠금이 바쁘면 진다. 5초 넘은 잠금은 버린다 |
| `consume` | `rename(key → key.<난수>.consuming)` 후 읽고 지운다 | 한 쪽만 성공한다 — 두 번째 호출은 null. 하위 키를 가진 디렉터리 키는 consume 하지 않는다 |
| `delete` | `unlink`, 없으면 조용히 통과 | — |

`sessions.patch`·`approvals.consume` 은 core 의 키 잠금(`withKeyLock`)으로 직렬화한다. 잠금 키 `locks/<key>` 를 `put {ifAbsent, ttlMs: 1500}` 로 잡고, 바쁘면 지수 backoff 로 최대 2초 다시 시도한 뒤 `SideBusyError` 를 던진다. 동시 consume 에서 진 쪽은 언제나 `used` 를 받는다.

**한계.** 잠금은 `patch`·`consume` 끼리만 줄을 세운다. 같은 키에 직접 `put` 하면 나중 것이 이긴다. 잠금 안의 일이 ttl(1.5초)보다 오래 걸리면 다른 쪽이 들어올 수 있다. 만료 키 경합은 "승자 최대 1"만 보장한다.

### watch

`watch(ns, prefix, cb)` 는 `fs.watch`(재귀)와 mtime 폴링을 함께 돌리고, 같은 스냅숏과 비교해 바뀐 것만 알린다.

- **유실 가능**: 폴링 주기 안의 put → delete 는 둘 다 안 보일 수 있고, 같은 키의 여러 put 은 마지막 하나만 알릴 수 있다. 정확한 값은 알림 뒤 `get` 으로 다시 읽는다.
- **지연**: `fs.watch` 가 이벤트를 흘리는 환경(네트워크 파일시스템, 일부 컨테이너)에서는 최대 `pollMs` 늦다.
- 중간 파일은 알리지 않는다. 구독 직후의 put 은 놓치지 않는다(대신 키가 많은 디렉터리는 구독 비용이 크다). 콜백이 던져도 감시는 멈추지 않는다.

## 공개 API

<!-- gen:api @agent-relay-engine/side-fs . -->
`@agent-relay-engine/side-fs` — 2개, 공개 API 스냅샷 1.8.4 기준.

| 종류 | 이름 |
|---|---|
| class | `FsSideStore` |
| type | `FsSideStoreOptions` |
<!-- /gen -->

## 설정

`new FsSideStore(root, options?)`

| 옵션 | 기본 | 뜻 |
|---|---|---|
| `pollMs` | `1000` | `watch` 의 mtime 폴링 주기 |
| `nativeWatch` | `true` | `false` 면 `fs.watch` 없이 폴링만 |

## 다른 문서

- [core README](../core/README.md#사이드-채널--두-층) — `SideStore`·`SideChannel` 계약
- 다른 저장소 구현(SQLite·Redis 등)은 [testing](../testing/README.md#sidestoresidechannel) 의 계약 스위트 두 개를 통과해야 한다

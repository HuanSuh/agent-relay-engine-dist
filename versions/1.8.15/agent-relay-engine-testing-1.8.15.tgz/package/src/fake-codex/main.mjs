#!/usr/bin/env node
// 시나리오 기반 가짜 `codex app-server`. 실행: node main.mjs app-server [-c key=value]… [--disable <feature>]…
// 시나리오는 env FAKE_CODEX_SCENARIO(경로 또는 JSON), 기록은 env FAKE_CODEX_LOG(JSONL)다.
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createInterface } from 'node:readline';
import { startMcpBridge } from '../fake-mcp/bridge.mjs';
import { toolArgsClient } from '../fake-mcp/tool-args.mjs';
import { mcpServersFromConfig, parseArgs, unknownConfigKeys } from './args.mjs';
import { createLog } from './log.mjs';
import { loadScenario } from './scenario.mjs';
import { createServer, createWire } from './server.mjs';
import { createStore } from './store.mjs';

const die = (msg) => {
  process.stderr.write(`fake-codex: ${msg}\n`);
  process.exit(2);
};

const argv = process.argv.slice(2);
let parsed;
let scenario;
try {
  parsed = parseArgs(argv);
  scenario = loadScenario(process.env.FAKE_CODEX_SCENARIO);
} catch (e) {
  die(e.message);
}
if (parsed.subcommand !== 'app-server') die(`app-server 만 흉내 낸다 (받은 것: ${parsed.subcommand ?? '없음'})`);

const log = createLog(process.env.FAKE_CODEX_LOG);
log.start(parsed, argv);

// D-067: --strict-config 면 모르는 칸에 initialize 전에 끝난다(문구는 실측 그대로)
if (parsed.rest.includes('--strict-config')) {
  const unknown = unknownConfigKeys(parsed.overrides);
  if (unknown.length > 0) {
    process.stderr.write(`Error: unknown configuration field \`${unknown[0]}\` in -c/--config override\n`, () => process.exit(1));
    await new Promise(() => {});
  }
}

const { behavior } = scenario;
if (behavior.stderrOnStart !== undefined) await new Promise((r) => process.stderr.write(`${behavior.stderrOnStart}\n`, r));
if (behavior.exitOnStart !== false) process.exit(behavior.exitOnStart === true ? 1 : behavior.exitOnStart);
if (behavior.ignoreSigterm) process.on('SIGTERM', () => process.stderr.write('fake-codex: SIGTERM 무시\n'));

// 읽는 쪽이 먼저 닫아도 스택 트레이스로 죽지 않게
process.stdout.on('error', () => process.exit(0));

const codexHome = process.env.CODEX_HOME || mkdtempSync(join(tmpdir(), 'fake-codex-home-'));
// enabled=false 인 서버는 띄우지 않는다(D-067 실측)
const allServers = mcpServersFromConfig(parsed.config);
const mcpServers = Object.fromEntries(Object.entries(allServers).filter(([, spec]) => spec.enabled));
const disabledServers = Object.keys(allServers).filter((n) => !allServers[n].enabled);
// 기동 알림은 http 서버(브리지 대상 아님)도 낸다
const announced = Object.entries(parsed.config?.mcp_servers ?? {}).filter(([, spec]) => spec?.enabled !== false).map(([name]) => name);

// stdio MCP 서버를 먼저 띄운다. 그동안 온 stdin 줄은 파이프에 남아 있다가 아래에서 읽힌다.
let mcp;
if (Object.keys(mcpServers).length > 0) {
  try {
    mcp = await startMcpBridge(mcpServers, {
      label: 'fake-codex',
      envPrefix: 'FAKE_CODEX_',
      connectTimeoutMs: Number(process.env.FAKE_CODEX_MCP_TIMEOUT_MS) || 15000,
      callTimeoutMs: Number(process.env.FAKE_CODEX_MCP_CALL_TIMEOUT_MS) || 30000,
      envVarsOnly: true,
      // 가짜 CLI 옵션(env, fakeCodexSpawn 의 mcpStrictTools) 또는 시나리오 칸. 둘 중 하나면 켠다(E-31, 목록 밖 호출은 실측대로 item 없이 건너뛴다)
      strictTools: process.env.FAKE_CODEX_MCP_STRICT_TOOLS === '1' || scenario.mcpStrictTools === true,
    });
  } catch (e) {
    die(`MCP 서버를 띄울 수 없다: ${e.message}`);
  }
}

// 버퍼에 남은 stdout 을 비운 뒤 끝낸다 — 마지막 알림을 잃지 않게
const exit = (code) => {
  mcp?.closeAll();
  process.stdout.write('', () => process.exit(code));
};

const wire = createWire();
const handle = createServer({ wire, scenario, parsed, store: createStore(codexHome), mcp, mcpServers, disabledServers, announced, codexHome, exit, toolArgs: toolArgsClient(process.env, 'FAKE_CODEX_') });

// 받은 순서대로 처리한다. 턴 진행은 처리기 밖에서 돌아 다음 메시지를 막지 않는다
let chain = Promise.resolve();
const rl = createInterface({ input: process.stdin, crlfDelay: Infinity });
rl.on('line', (line) => {
  let msg;
  try {
    msg = JSON.parse(line);
  } catch {
    process.stderr.write(`fake-codex: JSON 이 아닌 입력 무시: ${line.slice(0, 80)}\n`);
    return;
  }
  log.recv(msg);
  chain = chain.then(() => handle(msg));
});
rl.on('close', () => {
  // 실제 app-server 는 stdin EOF 에 끝난다. SIGTERM 무시 모드는 신호 fallback 검증용이라 스스로 끝나지 않는다(고아 방지 시한만 둔다).
  if (behavior.ignoreSigterm) setTimeout(() => exit(0), 60_000);
  else void chain.then(() => setImmediate(() => exit(0)));
});

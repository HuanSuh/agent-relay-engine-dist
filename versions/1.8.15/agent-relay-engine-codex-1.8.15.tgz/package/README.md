# @agent-relay-engine/codex

OpenAI Codex CLI 백엔드다. `codex app-server`(stdio JSON-RPC)를 세션마다 띄워 [core](../core/README.md) 의 `Engine` 계약대로 턴 단위 이벤트를 낸다. 설명자 이름은 `'codex'` 다. 기준 CLI 버전은 codex-cli 0.164.0 이고 안정 API 만 쓴다.

## 가장 짧은 예제

```ts check
import { createSideChannel, MemorySideStore } from '@agent-relay-engine/core';
import { createCodexEngine } from '@agent-relay-engine/codex';

const side = createSideChannel(new MemorySideStore(), 'my-tool');
const engine = createCodexEngine({ cwd: process.cwd(), namespace: 'my-tool', codex: { sandbox: 'workspace-write' } }, { side });

for await (const ev of engine.turn('s1', '안녕')) {
  if (ev.type === 'text') console.log(ev.text);
}
await engine.dispose();
```

`createCodexEngine(config, deps): Engine` 은 core `EngineFactory` 와 같은 모양이다. relay 에 넣으려면 `codexBackend` 를 `createRelayEngine` 의 `backends` 에 넘긴다.

## 설치와 로그인

1. Codex CLI 를 설치한다(기준 0.164.0). `codex --version` 으로 확인한다.
2. **`codex login` 으로 ChatGPT 계정(구독)에 로그인한다.** 엔진은 ChatGPT 로그인만 강제해 띄우고(`forced_login_method="chatgpt"`) 계정 종류가 `chatgpt` 가 아니면 `error(auth)` 다. API 키를 쓰려면 `permissions.auth.allow:['subscription','apiKey']` 를 명시한다.
3. 엔진은 사용자 `~/.codex` 를 직접 쓰지 않는다. 격리 홈에 로그인 파일만 링크한다(아래 [격리 홈](#격리-홈)).
4. 설치된 codex 가 기준 버전과 메서드가 다른지는 저장소에서 `npm run codex:protocol` 로 본다. 설치 상태에 따라 결과가 달라 `npm run check` 에는 넣지 않는다.

## 개념

### 기동과 턴

1. 격리 홈을 준비하고 `codex app-server --strict-config --disable … -c forced_login_method="chatgpt" -c mcp_servers.<이름>.… -c <codex.config>` 로 띄운다(세션당 프로세스 하나). 모르는 `-c` 칸이면 initialize 전에 끝나고 `error(config, resumable:false)` 다(stderr 의 거부 문구는 `detail.cause`).
2. `initialize` → `initialized` → `account/read`. 구독이 아니고 `apiKey` 를 허용하지 않았으면 `started` 없이 `error(auth, resumable:false)`.
3. 기록에 스레드 id(`SessionRecord.ext.codex.threadId`)가 있으면 `thread/resume`, 없으면 `thread/start`. 승인 정책·샌드박스는 아래 [권한 매핑](#권한-매핑)이고 resume 에도 다시 준다. 없는 스레드면 `error(resume-missing, resumable:false)` 이고 그 id 를 잊어 다음 턴은 새 대화다.
4. `started.mcpServers` 는 MCP 기동 상태 알림으로 채운다(`MCP_STARTUP_WAIT_MS` 안에 모인 것, 모르는 서버는 `'unknown'`).
5. `turn/start{clientUserMessageId}` → 알림을 이벤트로 옮김 → `turn/completed` 로 `done`.

- 알림은 이 세션의 스레드 id 와 이번 턴 id 로 거른다. 서브 스레드는 `subagents`(기본 `'drop'`)를 따른다.
- 자식 env 는 openai 몫의 과금 변수(`OPENAI_API_KEY`·`CODEX_API_KEY`·`OPENAI_BASE_URL`)만 지우고 `CODEX_HOME=<home>` 을 둔다. anthropic 키는 MCP 서버가 쓸 수 있게 남는다.
- 무응답 상한은 모델 출력·도구 알림만 갱신한다. sleep 항목·토큰 사용량·사용률 알림은 갱신하지 않는다 — 질문을 써 놓고 sleep 만 반복하는 턴은 `idle` 에 걸린다. 상한을 넘으면 interrupt 를 시도한 뒤 프로세스를 버리고 `error(idle|total, resumable:true)` 다.
- 중지: 시작된 턴은 `turn/interrupt` 뒤 `interruptGraceMs` 안에 `turn/completed` 가 오면 `'control'`(프로세스 유지), 아니면 그룹 SIGTERM → SIGKILL `'signal'`.
- 중지된 턴은 `text-delta` 만 있고 `text` 완성본이 없다. 부분 응답을 `text` 로 합치지 않는다.
- 기동 중(initialize~thread 준비) 연결이 닫히거나 턴 도중 app-server 가 끝나면 `error(exit)` 다. 설정 거부로 끝난 `error(config)` 도 detail 이 같다. detail 은 `{code, signal, stderrTail?, stderrLine?}` 이다. `stderrTail` 은 stderr 의 마지막 2,048자를 줄 경계로 자르고 앞뒤 공백을 지운 값이고, stderr 가 비었으면 칸이 없다. stderr 마지막 줄은 `stderrLine`(200자 상한)에만 있고 message 에는 싣지 않는다(1.7.0). 설정 거부의 stderr 문구는 `detail.cause` 다.

### 권한 매핑

`permissions`(+ 세션 덮어쓰기 + 정책 파일)을 승인 정책·샌드박스·MCP 설정으로 옮긴다. 모드별 표는 [대응표](../../docs/BACKENDS.md#권한-모드-매핑)에 있다. 결과는 `started.permissions` 에 싣는다.

- `approval:{kind:'control'}` 이 아니면 on-request 여도 사람에게 묻지 않는다. 엔진이 거절하고 `ext{core.permission_denied, {items, reason}}` 를 낸다. `approval:{kind:'mcpTool'}` 은 대응이 없어 엔진 생성 때 거절한다.
- **MCP 도구.** 금지가 허용보다 먼저다.

  | 규칙 | `-c mcp_servers.<서버>.…` |
  |---|---|
  | allowedTools `mcp__s__*`·`mcp__s`, 그리고 `core` 서버(ask) | `default_tools_approval_mode="approve"` |
  | allowedTools `mcp__s__t` | `tools.<원래 이름>.approval_mode="approve"` |
  | disallowedTools `mcp__s__t` | `disabled_tools=["<원래 이름>"]`(모델이 도구를 못 본다) |
  | disallowedTools `mcp__s__*`·`mcp__s` | `enabled=false`(서버를 띄우지 않는다) |

  설정 키에는 Codex 가 아는 원래 이름이 들어가야 한다. 규칙은 정규화 이름(`mcp__s__files_delete`)이라 `McpServerSpec.tools`(원래 이름 목록)로 원래 이름(`files.delete`)을 찾는다. 허용은 애매하면 열지 않고, 차단은 애매하면 더 막는다.

  | `tools` 목록 | 허용 | 차단 | 경고 |
  |---|---|---|---|
  | 없음 | 규칙 이름 그대로 | 규칙 이름 그대로 | 없음 |
  | 후보 하나 | 원래 이름 | 원래 이름 | 없음 |
  | 후보 둘 이상 | 설정 안 함(승인 시점 안전망) | 후보 전부 | `core.tool_name{warning:'ambiguous', name, server, candidates}` |
  | 후보 없음 | 설정 안 함 | 규칙 이름 그대로 | `core.tool_name{warning:'ambiguous', …, candidates:[]}` |

  **도구 이름에 `.` 등이 있으면 `tools` 를 적어야 차단·허용이 정확하다.** 서버 전체를 허용(`mcp__s`)하고 그 안의 도구 하나를 막으면, 서버 전체 승인 때문에 승인 요청이 오지 않아 그 도구는 막히지 않는다.
- **내장 도구 이름**(`Bash`·`Edit` 등). 허용 목록에 있으면 열 수 없어 `core.config{warning:'ignored', fields:['permissions.allowedTools']}` 로 알린다. 금지 목록에 있으면 지킬 수 없어 막는다(fail-closed) — 엔진 설정이면 엔진 생성 때 던지고, 정책 파일·`resolveSession` 이면 세션 설정을 해석한 뒤 그 턴이 `error{reason:'config', resumable:false}` 다. message 는 대안(`permissions.mode:'plan'` 읽기 전용, 또는 `approval:{kind:'control'}` + 사람 승인)을 담은 고정 문구다. 지킬 수 없는 항목 이름은 `detail.cause`(쉼표로 이은 글)에 싣는다. 생성 때 던지는 `UnenforceableToolsError` 는 `tools`·`cause` 에, `fork()` 의 `ForkError(config)` 는 `detail.cause` 에 싣는다. relay 의 `skipped{reason:'config'}.detail` 에는 고정 문구만 간다.
- 승인 요청으로 온 허용 도구는 엔진이 목록과 대조해 허용하고(`core.permission_rule{via:'allowedTools'}`), 금지 도구는 거절한다(안전망). MCP 승인 요청에는 도구 이름 칸이 없어 안내 문구에서 이름을 읽는다. 이름이 하나로 정해지지 않으면 자동 허용하지 않고 사람에게 묻는다.
- 정책 파일의 mode·목록이 바뀌면 다음 턴 전에 다시 띄우고 같은 스레드를 잇는다(`core.restart{reason:'policy-changed'}`).

### 승인 세 갈래

**core 서버.** 이름 `core` 는 엔진 ask 서버의 예약 이름이다. ask 서버를 띄우지 않는 설정이어도 `mcpServers`(엔진 설정·`resolveSession`)에 `core` 가 있으면 설정 오류다. core 서버는 서버 전체가 아니라 `tools.ask.approval_mode="approve"` 로 ask 도구만 묻지 않는다.

서버 요청 셋을 공통 승인 요청(`PermissionRequest{toolName, input, toolUseId?, displayName?}`)으로 바꿔 공통 순서(훅 → 기억한 규칙 → 사전 승인 → 사람)로 처리한다. 훅이 던지면 문구 없이 거절하고 `core.permission_denied{reason:'hook-error'}` 로 알린다. 훅의 원문은 `ext{core.control, {warning:'hook-error', cause}}`·metric `control.hook_error` 에만 있다(1.7.0).

| 서버 요청 | toolName | input | toolUseId | displayName |
|---|---|---|---|---|
| 명령 실행 승인 | `commandExecution` | `{command, cwd, reason}` | 항목 id | command |
| 파일 변경 승인 | `fileChange` | `{changes, reason}` | 항목 id | |
| MCP 도구 호출 승인(elicitation) | `mcp__<server>__<tool>`(정규화 이름) | 도구 인자 | 진행 중 MCP 항목 id(없으면 비움) | `<server>.<원래 도구 이름>` |

- 훅·기억한 규칙·사전 승인·`core.permission_*` ext 는 모두 위 toolName 으로 대조·보고한다.
- 답: allow 는 accept, deny 는 decline 이고 턴은 계속된다.
- `updatedInput` 이 원래 입력과 다르면 실행하지 않는다. 거절하고 `ext{codex.permission, {warning:'updated-input-unsupported'}}` 를 낸다. 결정 알림은 `{behavior:'deny', via:'policy', overridden:{behavior:'allow', via}}` 다 — `via` 는 허용한 주체(`'human'`·`'hook'`)다(1.8.11).
- 대기 중 `stop()` 은 `turn/interrupt` 로 끝낸다. 카드는 `core.permission_cancelled(stopped)` 로 닫히고 늦은 `answerPermission` 은 `false` 다.
- 그 밖의 서버 요청(다른 elicitation·권한 상승·질문 등)은 사람에게 묻지 않고 거절하며 `ext{codex.server_request, {method, handled:false}}` 를 낸다. 권한 상승 요청에는 아무것도 주지 않는다.

**"항상 허용"(`rememberRule`).** 명령 규칙은 `rememberRule({tool:'commandExecution'|'Bash', prefix})` 로 정책 파일에 `{tool:'Bash', prefix}` 로 저장된다 — 두 백엔드가 한 정책 파일을 쓰기 때문이다. 돌려받은 규칙을 카드와 이어 보일 때는 `rule.tool` 이 아니라 카드의 toolName 을 쓴다. 맞추는 명령은 로그인 셸 래퍼(`/bin/zsh -lc '<cmd>'`)를 벗긴 `<cmd>` 다(core `unwrapShell`). `fileChange` 는 이름 규칙, MCP 도구는 `mcp__s__t` 이름 규칙이다. Codex 에서 명령 승인은 대개 샌드박스 밖 실행이라 기억한 Bash 규칙은 **샌드박스 밖 실행까지** 연다.

### ask

- `core` 서버의 `ask` 도구 호출이 끝나면 core `askEvent` 로 `ask` 이벤트를 낸다. 서브 스레드 안의 ask 와 오류 결과는 내지 않는다.
- `endTurnOnAsk`(기본)면 스트림을 `done(ask)` 로 닫고 Codex 턴은 `turn/interrupt` 로 끊는다.
- ask 가 켜져 있으면 지시문 끝에 `ASK_INSTRUCTIONS`(질문은 `ask` 도구로 하고, 답을 기다리며 sleep 하지 말라)를 붙인다. 지시문도 프롬프트 지문에 들어가므로 ask 를 켜거나 끄면 새 대화가 된다.

### 턴 문맥 창구

- **MCP 비밀 값은 argv 에 싣지 않는다.** http `headers` 는 app-server env 의 엔진 이름(`ARE_MCP_H_<서버 해시>_<순번>`)에 넣고 `-c mcp_servers.<이름>.env_http_headers={헤더=이름}` 만 싣는다. stdio `env` 는 같은 키로 app-server env 에 넣고 `env_vars` 에 이름만 싣는다(엔진의 문맥 env 는 그대로 `-c …env`). 옮긴 이름은 `-c shell_environment_policy.exclude` 에 늘 넣는다(`ARE_MCP_H_*` 패턴 + 턴 문맥 토큰 `AGENT_RELAY_ENGINE_CONTEXT_TOKEN` + 옮긴 stdio 키, 소비자가 `codex.config` 로 준 같은 키의 목록과 합친다) — 소비자가 `inherit="all"` 로 열어도 셸 env 에 보이지 않는다. 부모 env 에 같은 이름이 있어도 소비자 값으로 덮어 옮기므로 셸이 부모 값을 잃을 수 있다. 예약 이름(`PATH`·`HOME`·`USER`·`LOGNAME`·`SHELL`·`TMPDIR`·`TERM`·`TZ`·`LANG`·`LC_*`·`CODEX_*`·`OPENAI_*`·`AGENT_RELAY_ENGINE_*`·`NODE_*`·`LD_*`·`DYLD_*`·`*_PROXY`·`SSL_*`·`RUST_*`·`__CF_*`·`GIT_*`·`BASH_ENV`·`ENV`·`ZDOTDIR`·`XDG_*`·과금·바깥 세션 변수)은 app-server 자체 env 를 바꿔 인증·과금 차단·프록시를 우회하지 않도록 옮기지 않고 인라인으로 두며 `ext{core.config,{warning:'mcp-env-argv', server, keys, reason:'reserved'}}` 로 알린다. 서로 다른 서버가 같은 키에 다른 값을 요구하면 `reason:'conflict'`, 변수 이름 모양이 아닌 키(`=` 등)는 `reason:'invalid'` 다. MCP 서버 이름은 `[A-Za-z0-9_-]+` 만 받는다(`-c` 가 따옴표 키를 받지 않는다) — 아니면 설정 오류다.
- core README 의 [MCP 서버에서 턴 문맥 읽기](../core/README.md#mcp-서버에서-턴-문맥-읽기)를 따른다. app-server 프로세스 env 에 `AGENT_RELAY_ENGINE_CONTEXT`·`_CONTEXT_TOKEN` 을 싣고, stdio 서버마다 `-c mcp_servers.<이름>.env_vars=["AGENT_RELAY_ENGINE_CONTEXT", "AGENT_RELAY_ENGINE_CONTEXT_TOKEN"]` 로 이름만 넘긴다. 토큰 값은 기동 인자에 없다.
- 서버가 받는 `_meta["x-codex-turn-metadata"].turn_id` 는 app-server 의 턴 id 다. 엔진은 `turn/start` 응답에서 이 id 를 엔진 턴에 잇는다. 서브 스레드의 호출은 그 스레드의 턴 id 를 싣는다. 엔진은 서브 스레드의 `turn/started` 를 볼 때 그 id 도 같은 엔진 턴에 잇는다.

### 끼워 넣기 (steer)

- `mode:'inject'` 이고 이 세션 턴이 진행 중이면 `turn/steer` 를 보낸다. 같은 턴에 그 입력이 오면 끼운 쪽 스트림은 `accepted{mode:'inject'}` → `done(end_turn)` 이고 본문은 원래 턴으로 흐른다.
- 턴이 막 끝났거나 id 가 맞지 않으면 `QueuePolicy.injectFallback` 대로 큐(`'turn'`)나 `error(busy)`(`'reject'`)로 간다.
- 진행 중 턴보다 좁은 `toolScope` 의 입력은 steer 하지 않고 같은 대체 정책으로 간다(아래 [턴 단위 도구 범위](#턴-단위-도구-범위)).

### 턴 단위 도구 범위

`TurnOptions.toolScope` 의 뜻과 공통 규칙은 [core README](../core/README.md#턴-단위-도구-범위-toolscope)에 있다. capability `turn-tool-scope` 가 늘 있다. 이 백엔드에서는 이렇게 지킨다.

- **`'read-only'`.** `turn/start` 에 `sandboxPolicy:{type:'readOnly', networkAccess:false}` 를 싣는다. OS 샌드박스가 쓰기를 막는다(실측 0.164.0: `operation not permitted`). 그 턴의 승인 요청 세 갈래(샌드박스 밖 명령·파일 변경·MCP 도구)는 사람에게 묻지 않고 훅·규칙·허용 목록보다 먼저 거절하며 `ext{core.permission_denied, {items, reason:'tool-scope'}}` 를 낸다.
- **다음 턴에 되돌린다.** 턴의 `sandboxPolicy` 는 다음 턴에도 남는다(실측). 그래서 범위를 준 턴 다음의 `'all'` 턴은 thread/start·thread/resume 응답의 `sandbox`(스레드의 원래 정책)를 `sandboxPolicy` 로 명시해 보낸다. 되돌린 뒤의 턴은 칸을 싣지 않는다. 원래 정책을 모르는 프로세스는 다시 띄워 thread/resume 의 `sandbox` 로 돌린다.
- **다시 띄울 때.** read-only 턴이 `codex.allowProjectConfig` 로 프로젝트 config 를 읽은 프로세스(기동 때와 thread 요청 직전 재검사에서 찾은 것 모두)나 원래 샌드박스를 모르는 프로세스를 내리고 다시 띄우면 같은 스레드를 resume 한다. `core.restart` 는 내지 않고 metric `process.restart` 의 `tags.reason` 에 `'tool-scope-project-config'`·`'tool-scope-sandbox'` 를 남긴다.
- **지킬 수 없는 설정(fail-closed).** 승인 요청 없이 샌드박스 밖에서 도는 도구가 생기는 설정이면 read-only 턴을 보내지 않고 `error(config)` 로 닫는다. `detail.cause` 는 다음과 같다.
  - `'allowed-tools'`: 엔진 ask 도구(`mcp__core__ask`) 밖의 MCP 도구를 `permissions.allowedTools` 로 미리 허용했다. 승인 요청 없이 실행되고, MCP 도구는 샌드박스 밖 서버 프로세스에서 돈다. `mcp__core__*`·`mcp__core` 도 예외가 아니다.
  - `'codex-config'`: `codex.config` 에 허용 목록 밖의 키가 있다. 허용 목록(`SCOPE_CONFIG_KEYS`)은 `model`·`model_reasoning_effort`·`model_reasoning_summary`·`model_verbosity`·`shell_environment_policy.inherit`·`shell_environment_policy.exclude` 뿐이다. 점 키와 중첩 표를 모두 편 경로가 문자 그대로 같아야 한다(공백·대소문자를 고치지 않는다). `codex.config` 는 엔진 설정 뒤에 `-c` 로 붙어 덮기 때문이고, 금지 목록은 표기 변형·profiles 경로로 샜다.
  - `'mode'`: 해석된 승인 정책(approvalPolicy)이 `never` 다. `permissions.mode` 가 `dontAsk`(기본)나 `plan` 이면 그렇다. 승인 요청이 오지 않아 엔진이 거절할 자리가 없다. read-only 를 쓰려면 `'default'` 등 묻는 모드를 준다.
  - `'codex-home'`: 앞 턴이 엔진 `CODEX_HOME`(`codex.home`, 기본은 작업 폴더 밖, [격리 홈](#격리-홈))에 쓸 수 있었는데 그 안에 정책 항목(`config.toml`·`rules`·`hooks.json`·`managed_config.toml`·`requirements.toml`·`.env`·`*.config.toml`(profile 파일), 이름 대소문자 무시) 중 하나가 있다. 쓸 수 있었다는 것은 홈이 쓰기 가능 경로(cwd, 스레드 샌드박스의 writableRoots, 제외하지 않은 `TMPDIR`·`/tmp`) 안이거나 스레드 샌드박스가 `dangerFullAccess`·`externalSandbox` 라는 뜻이다. 프로세스가 없으면 설정의 샌드박스 모드로 본다. 경로는 실제 경로(심볼릭 링크를 푼 값)로 비교한다. 엔진과 app-server 는 이 항목들을 만들지 않으므로 누군가 써 넣은 것으로 본다. `rules` 의 `prefix_rule` allow 는 read-only 턴에서도 샌드박스와 승인을 건너뛰고 명령을 실행한다(실측).
  - `'codex-project-config'`: 프로젝트의 `.codex/` 안에 항목이 하나라도 있다(rules/·config.toml·hooks.json 등, 빈 `.codex` 폴더는 괜찮다). 세션 cwd 의 실제 경로와 주어진 경로부터 위로 git 루트(`.git` 이 있는 폴더, 끊어진 링크 `.git` 은 표식이 아니다)까지 각 폴더를 본다. git 루트가 없으면 cwd 만 본다. git 루트 바깥(사용자 홈의 `~/.codex` 등)은 보지 않는다. 이름은 파일 시스템처럼 접어 비교한다(NFKC·유니코드 대소문자). 찾은 `.codex` 폴더는 `detail.paths` 에 싣는다. Codex 는 이 프로젝트 rules·config 도 읽는다(실측). rules 의 allow 는 턴 readOnly·승인을 건너뛰고, config 는 env·MCP 서버 등을 바꾼다. 그래서 read-only 를 지킬 수 없어 거절한다.
  - `'features'`: `codex.disableFeatures` 가 기본으로 끄는 기능(`apps`·`plugins`·`goals`·`hooks`·`multi_agent`)을 다 끄지 않는다.
- **남는 위험.** 작업 폴더의 `AGENTS.md` 와 skills 는 모델에게 주는 지시일 뿐 승인·샌드박스를 바꾸지 않는다. 그래서 read-only 판정에 넣지 않는다. 앞 턴이 이것들을 고쳐 다음 턴의 행동을 바꿀 수는 있다(지시 주입). read-only 턴의 쓰기는 여전히 샌드박스와 승인 거절이 막는다.
- **끼워 넣기.** `turn/steer` 에는 샌드박스 칸이 없어 진행 중 턴을 좁힐 수 없다. 그래서 진행 중 턴보다 좁은 범위의 inject 는 steer 하지 않고 `QueuePolicy.injectFallback` 대로 새 턴(그 범위)으로 가거나 거절된다. 같거나 넓은 범위의 inject 는 지금처럼 steer 하고, 진행 중 턴의 범위는 그대로다.
- **`'none'`·`{allow}`.** 살아 있는 스레드에서는 셸 자체를 끌 수 없어 `error(config)`(`cause:'live-process'`)다. 분기에서도 받지 않는다(아래).

### 세션 분기 (`fork`·`consult`)

뜻과 공통 규칙은 [core README](../core/README.md#세션-분기와-물어보기-forkconsult)에 있다. capability `session-fork` 가 늘 있다. manifest 에 `thread/fork`(0.164.0 v2 안정 스키마)를 더했다.

- **띄우는 법.** `fork()` 안에서 분기 세션의 app-server 를 띄우고 원본 스레드를 `thread/fork`(`threadId`, `ephemeral:false`, `excludeTurns:true`, 세션 설정의 `cwd`·`approvalPolicy`·`sandbox`·`model`·`developerInstructions`)한다. 새 스레드 id 를 기록하고, 그 프로세스를 첫 턴이 쓴다(첫 턴이 오지 않으면 유휴 정리가 내린다). 실측(0.164.0): 새 id 가 생기고, 맥락을 이어받고, 원본은 분기 쪽 대화를 모른다.
- **응답 검사.** 응답의 스레드 id 가 비었거나 원본과 같으면(분기를 따르지 않은 app-server) 기억하지 않고 `ForkError(internal, cause:'fork-not-honoured')` 다.
- **ephemeral.** `keep` 이 아닌 `consult` 는 `ephemeral:true` 로 분기해 스레드 기록을 디스크에 남기지 않는다(v2 스키마 `ThreadForkParams.ephemeral`). `fork`·`keep` 인 `consult` 는 남긴다(이어 가야 한다).
- **원본이 턴 중이면.** 그때의 `thread/fork` 동작은 실측하지 않았다. 그래서 턴 중에는 보내지 않는다 — `ifBusy` 로 기다린 뒤, 원본 턴 끝(또는 바로)부터 `thread/fork` 응답까지 원본의 다음 턴 시작을 붙잡는다.
- **홈·프로젝트 정책(WU-36 규칙).** `thread/fork` 직전에도 `thread/start`·`resume` 과 같이 엔진 홈의 정책 항목과 프로젝트 `.codex/` 를 다시 본다(같은 검사 함수). 응답의 실제 `sandbox` 로 홈 쓰기 가능(`codex-home-writable`)을 다시 본다. 걸리면 `ForkError(config, cause)` 이고 세션은 남지 않는다.
- **범위.** `'all'`·`'read-only'` 만 받는다. `'read-only'` 분기는 `thread/fork`·`resume` 의 `sandbox:'read-only'` 로 스레드를 열고 모든 턴에 `sandboxPolicy` readOnly 를 싣는다. read-only 턴과 같은 우회 검사(`allowed-tools`·`codex-config`·`features`·`mode`·`codex-home`)를 `fork()` 에서 먼저 하고, `codex.allowProjectConfig` 여도 프로젝트 `.codex/` 를 거절한다. 홈 쓰기 가능 판정은 분기 스레드의 읽기 전용 샌드박스가 아니라 엔진 설정의 샌드박스로 한다(원본 세션이 같은 홈을 쓴다). `'none'`·`{allow}` 는 셸·읽기를 끌 수 없어 `ForkError(config, cause:'unsupported')` — 조용히 넓히지 않는다.

### 모델 바꾸기

- 스레드(`thread/start`·`thread/resume`)는 세션 단계 모델(`SessionOverrides.model` → `EngineConfig.model`)로 연다.
- 이번 턴 모델이 스레드의 지금 모델과 다르면 `turn/start` 의 `model` 칸으로 보낸다. 이 턴 전에 살아 있던 프로세스였으면 `started` 뒤 `ext{core.model, {model, via:'turn'}}` 를 낸다. 설정·정책 변경으로 다시 띄우면서 세션 모델도 바뀌었으면 `via:'restart'` 다.
- app-server 는 턴의 모델 덮어쓰기를 스레드에 남긴다. 그래서 엔진이 지금 모델을 기억하고, `TurnOptions.model` 이 없는 다음 턴에는 세션·엔진 모델을 명시해 보낸다.
- 세션·엔진 모델이 둘 다 없으면 엔진이 턴 모델로 덮어쓴 적이 있을 때만 스레드의 기본 모델로 되돌린다. 기본 모델은 모델 없이 연 스레드의 `thread/start` 응답(없으면 덮어쓰기 직전 모델)이고, 덮어쓰기 여부와 함께 세션 기록 `ext.codex`(`defaultModel`·`overridden`)에 남는다. 모델을 정하지 않은 세션은 칸을 싣지 않아 CLI 기본 모델을 따른다.
- 세션 모델로 연 스레드에서 세션 모델을 지우면 되돌릴 이름을 모르므로 칸을 싣지 않는다.
- `turn/steer` 에는 모델 칸이 없다. 끼워 넣기에 다른 모델을 주면 `core.model{warning:'ignored-inject'}` 다.

### 격리 홈

기본 `~/.codex` 를 그대로 쓰면 사용자 플러그인 MCP 서버·알림·설정이 엔진 세션에 샌다. 그래서 엔진 전용 `CODEX_HOME`(`codex.home`)을 쓴다.

- spawn 전에 폴더를 만들고 `auth.json` 을 `authSource/auth.json` 을 가리키는 링크로 둔다.
- 링크가 일반 파일로 바뀌어 있으면 CLI 가 토큰 갱신 때 교체 쓰기한 것이다. 그 파일이 지금 쓰이는 로그인이라 건드리지 않고 `ext{codex.auth, {warning:'auth-file-diverged'}}` 를 낸다. 원본과 다시 맞추려면 그 파일을 지운다.
- 원본에 `auth.json` 이 없으면 spawn 하지 않고 `error(auth, resumable:false)` 다.
- 대화 기록이 이 폴더에 쌓인다. `codex.home` 을 바꾸면 이전 세션은 `resume-missing` 이 된다.
- **기본 위치는 모델이 쓸 수 없는 곳이다**(1.8.0). 홈의 `rules/*.rules` allow 규칙은 샌드박스와 승인을 모두 건너뛴다(실측). 그래서 홈이 작업 폴더 안에 있으면 보통 턴의 모델이 규칙을 심어 이후 모든 턴의 승인을 우회할 수 있다. 기본 홈은 사용자 데이터 폴더 아래 cwd 마다 따로 둔다(폴더 권한 0700). `<cwd 해시>` 는 cwd 실제 경로의 sha256 앞 16자다.
  - macOS: `~/Library/Application Support/agent-relay-engine/codex-home/<cwd 해시>`
  - Linux 등: `$XDG_DATA_HOME`(없으면 `~/.local/share`)`/agent-relay-engine/codex-home/<cwd 해시>`
  - Windows: `%LOCALAPPDATA%\agent-relay-engine\codex-home\<cwd 해시>`
- **옛 기본 홈에서 옮기기**: 새 기본 홈이 없고 옛 기본 홈 `<cwd>/.agent-relay-engine/codex-home` 의 `sessions/` 안에 실제 세션 파일이 있으면, 처음 띄울 때 한 번 새 홈으로 옮긴다. 그래서 resume 이 이어진다.
  - 옛 홈은 모델이 쓸 수 있던 곳이라 **허용 목록만 복사한다**: `sessions/`·`archived_sessions/`·`*.sqlite`(`-wal`·`-shm` 포함). 실제 폴더·파일일 때만, 링크를 따라가지 않고 복사한다(하드링크도 끊긴다). 복사 전후 옛 홈의 dev/ino 와 실제 경로가 `<실제 cwd>/.agent-relay-engine/codex-home` 인지 보고, 바뀌었으면 옮기지 않는다. 옮긴 트리 안의 심볼릭 링크는 지운다.
  - `auth.json`·정책 항목·심볼릭 링크·그 밖의 이름은 옮기지 않는다. 옛 홈은 원본 그대로 `<옛 홈>.migrated` 로 이름만 바꾼다. FIFO·소켓 등 파일·폴더가 아닌 항목도 복사하지 않는다.
  - sqlite 는 묶음(`X.sqlite`·`X.sqlite-wal`·`X.sqlite-shm`) 단위로 옮긴다. 하나라도 옮기지 못하면(실제 파일이 아니다·하드링크·특수 파일) 또는 본문(`X.sqlite`)이 없으면 묶음 전체를 건너뛴다. 짝 없는 WAL·SHM 이 새 홈에 남지 않는다.
  - 파일 시스템이 목록 항목의 종류를 알려 주지 않으면(DT_UNKNOWN) `lstat` 으로 본다.
  - 결과는 `started` 뒤 `ext{core.config, {warning:'codex-home-migrated', from, home, skipped, left, removedLinks, skippedHardLinks}}` 로 알린다. `skipped` 는 옮기지 않은 최상위 이름, `left` 는 옛 자리에 남은 것의 경로다. `removedLinks` 는 허용 목록의 최상위 항목(`sessions/`·`archived_sessions/`·sqlite 묶음)과 그 아래에서 옮기지 않은 링크·특수 파일 수, `skippedHardLinks` 는 같은 범위에서 옮기지 않은 하드링크 수다. 항목 하나는 한 번만 세고, 최상위 항목이면 `skipped` 에도 이름이 있다. 허용 목록 밖의 최상위 이름(`auth.json`·설정 등)은 `skipped` 에만 있다. `skipped` 의 이름은 모델이 쓸 수 있던 옛 홈에서 읽은 그대로다 — 믿지 말고, 화면·로그에 낼 때는 이스케이프한다.
  - 파일은 `O_RDONLY|O_NOFOLLOW|O_NONBLOCK` 로 열고 `fstat` 이 일반 파일일 때만 그 fd 에서 복사한다. 링크·FIFO·소켓·장치는 복사하지 않고 `removedLinks` 로, 하드링크(`nlink>1`)는 `skippedHardLinks` 로 센다. 폴더는 `O_DIRECTORY|O_NOFOLLOW` 로 열어 dev/ino 가 `lstat` 과 같은지 보고, 복사 뒤 모든 폴더의 dev/ino 를 다시 봐 다르면 실패한다(Windows 에는 `O_NOFOLLOW` 가 없어 이 보호가 약하다). 전체 2GiB·항목 20만 개(옛 홈 최상위 항목 포함)·5분을 넘으면 옮기기 실패다. 목록을 읽은 뒤 사라진 항목은 실패가 아니라 건너뛴다(세지 않는다). sqlite 묶음의 멤버가 사라졌으면 그 묶음 전체를 건너뛴다. 한 번의 블로킹 read(느린 네트워크 파일 시스템 등)는 시간 상한으로 끊지 못한다. 새 홈을 비우기 직전에 시간·새 홈이 아직 안 쓰였는지·잠금이 아직 내 것인지 다시 보고, 아니면 실패다.
  - 프로세스 사이에는 `<새 홈의 부모>/.migrate.lock`(내용 `<pid> <토큰> <만든 시각 ms>`)으로 한 번만 옮긴다. 그 pid 가 죽었거나 잠금이 10분보다 오래됐으면(pid 와 무관) 잠금을 버리고, 풀 때는 내 토큰일 때만 지운다. 살아 있는 잠금 때문에 건너뛰면 `{warning:'codex-home-migrate-skipped', from, home, cause:'locked'}` 를 내고 다음 기동에 다시 본다.
  - 옮기지 못하면 `{warning:'codex-home-migrate-failed', from, home, cause}` 를 내고 새 빈 홈으로 계속한다. 옛 홈은 그대로 두고, 이어 갈 스레드는 `resume-missing` 이 된다.
  - 새 홈이 없거나 로그인 링크만 있을 때 옮긴다. 그래서 앞 기동에서 옮기지 못했으면 다음 기동에 다시 해 본다. 같은 프로세스에서 동시에 연 세션은 한 번만 옮긴다.
  - 옛 홈이나 그 부모(`.agent-relay-engine`)가 심볼릭 링크면 옮기지 않는다(`codex-home-migrate-failed`). 옮긴 새 홈이 다시 작업 폴더를 가리키게 되기 때문이다.
  - `codex.home` 을 준 엔진은 옮기지 않는다.
- **띄울 때마다 홈을 검사한다**(app-server 를 띄우기 전, 점검 `detect` 포함).
  - 홈에 정책 항목(`config.toml`·`rules`·`hooks.json`·`managed_config.toml`·`requirements.toml`·`.env`·`*.config.toml`(profile 파일), 이름은 파일 시스템처럼 NFKC·유니코드 대소문자로 접어 비교하고 ASCII 가 아닌 이름은 정책 항목으로 본다) 중 하나라도 있으면 띄우지 않는다. 예외: `config.toml` 이 `[projects."<경로>"]`(리터럴 문자열 `[projects.'<경로>']` 도) 표의 `trust_level = "<문자열>"` 만 들었으면(주석·빈 줄 허용) 허용한다 — git 저장소 cwd 면 app-server 가 thread/start 때 이 trust 기록을 홈에 직접 쓴다(실측). `.env` 는 Codex 프로세스 env 를 바꾼다(실측: `PATH`·임의 변수, `TMPDIR` 로 workspace-write 쓰기 범위가 넓어진다). 홈 목록을 읽을 수 없어도 거절한다. 결과는 `error(config, resumable:false)` 이고 `detail.cause` 는 `'codex-home-policy'`, `detail.entries` 는 찾은 이름이다. trust 기록 밖의 이것들은 엔진과 app-server 가 만들지 않으므로(실측) 누군가 써 넣은 것이다. 지우고 다시 연다. Codex 설정은 `codex.config` 로 준다.
  - 홈 최상위에 알려진 Codex 산출물(`sessions`·`archived_sessions`·`*.sqlite*`·`log`·`logs`·`history.jsonl`·`auth.json`·`models_cache.json`·`version.json`·`installation_id`·`.sandbox_migration`·`shell_snapshots`·`skills`·`memories`·`plugins`·`cache`·`tmp`·`thread-writer-locks`·trust 기록 `config.toml`, 0.164.0 실측) 밖의 이름이 있으면 거절하지 않고 `ext{core.config, {warning:'codex-home-unknown-entries', entries}}` 를 낸다. 같은 목록은 한 번만 알린다.
  - 기본 홈(`codex.home` 을 주지 않은 경우)이 실제 폴더가 아니면(심볼릭 링크 등) 띄우지 않는다. 결과는 `error(config)` 이고 `detail.cause` 는 `'codex-home-link'` 다.
  - 프로젝트 `.codex/`(위 `'codex-project-config'` 와 같은 탐색, 안에 무엇이든 있으면)가 있으면 **기본으로 띄우지 않는다**. 결과는 `error(config, resumable:false)` 이고 `detail.cause` 는 `'codex-project-config'`, `detail.paths` 는 찾은 `.codex` 폴더다. 프로젝트 `config.toml` 은 홈에 trust 기록이 없어도, `-c projects."…".trust_level="untrusted"` 를 줘도 적용된다(실측).
    - Codex 샌드박스는 cwd 바로 아래 `.codex` 만 보호한다. 하위 폴더의 `.codex/` 는 workspace-write 턴의 모델이 만들 수 있다(실측). 그 폴더를 cwd 로 쓰는 다른 세션의 사슬에 들어가 승인·설정을 바꾼다.
    - 저장소에 일부러 둔 `.codex/` 를 써야 하면 `codex.allowProjectConfig: true` 를 준다. 그러면 막지 않고 `ext{core.config, {warning:'codex-project-config', paths}}` 를 프로세스마다 한 번 낸다. 위험: rules 의 allow 는 샌드박스·승인을 건너뛰고 config 는 env·MCP 서버를 바꾸며, 모델이 하위 폴더에 심은 것도 같이 통과한다. read-only 턴은 켜도 거절한다.
  - 홈이 쓰기 가능 경로 안이면 띄우지 않는다. 결과는 `error(config, resumable:false)` 이고 `detail.cause` 는 `'codex-home-writable'`, `detail.home` 은 그 홈이다. 기본 홈과 명시적 `codex.home` 모두 같고, 탈출구는 없다. 쓰기 가능 경로는 세션 cwd, `codex.config` 의 `sandbox_workspace_write.writable_roots`, 제외하지 않은 `TMPDIR`·`/tmp` 이다. 같은 프로세스의 새 `thread/start` 는 그 사이 홈에 생긴 rules 를 읽어 승인을 우회한다(실측). 그래서 경고가 아니라 거절이다. 경로는 실제 경로로 비교한다. 아직 없는 홈은 있는 상위 폴더까지 실제 경로로 푼다.
  - 쓰기 가능 경로가 홈 안에 있어도(`writable_roots` 에 `<홈>/rules` 등) 거절한다. cwd 가 사용자 데이터 폴더의 상위(예: cwd 가 `~`)면 기본 홈도 cwd 안이라 거절된다. 그때는 `codex.home` 을 cwd 밖에 준다.
  - **`danger-full-access` 는 홈을 보호하지 못한다.** 어디든 쓸 수 있어 이 거절은 적용하지 않는다(거절하면 이 모드를 쓸 수 없다). 정책 항목 검사는 그대로 한다.
  - 살아 있는 app-server 에 `thread/start`·`thread/resume` 을 보내기 직전에도 홈 정책 항목과 프로젝트 `.codex/`(켜지 않았을 때)를 다시 본다. 띄운 뒤 생겼으면 요청을 보내지 않고 `error(config, 'codex-home-policy' | 'codex-project-config')` 로 그 턴을 끝낸다.
  - `thread/start`·`thread/resume` 응답의 실제 `sandbox` 로 쓰기 가능 경로를 다시 본다. 엔진이 모르는 설정(profile 등)이 홈을 쓰기 가능으로 넓혔으면 그 세션은 `error(config, 'codex-home-writable')` 로 실패하고, 새 스레드는 기억하지 않는다.
  - `codex.config` 키는 영문·숫자·`_`·`-` 를 점으로 이은 모양만 받는다. Codex 는 `-c` 키 앞뒤 공백을 지우고 읽어(실측) 엔진 검사와 어긋날 수 있어서다. `project_root_markers` 는 엔진의 프로젝트 rules 사슬(`.git` 기준)과 어긋나 받지 않는다. 둘 다 엔진을 만들 때 던진다.
  - 검사와 기동 사이 짧은 틈(TOCTOU)은 남는다. 같은 홈·cwd 를 쓰는 다른 세션의 모델이 그 사이에 쓸 수 있다. 검사는 기동·thread 요청 직전마다 다시 해 틈을 줄인다.
  - 프로젝트의 `AGENTS.md` 는 모델 지시문일 뿐 샌드박스·승인을 바꾸지 않아 막지 않는다. 신뢰하지 않는 저장소라면 지시문 주입에 유의한다.
- 기능 플래그(`codex.disableFeatures`)까지 꺼야 계정에 묶인 앱 커넥터가 빠져 준 MCP 서버만 남는다.

### 백엔드 설명자 (`codexBackend`)

```ts check
import { detectBackends } from '@agent-relay-engine/core';
import { codexBackend } from '@agent-relay-engine/codex';

// codex.home 을 주지 않으면 엔진과 같은 기본 홈(작업 폴더 밖)을 쓴다
const [codex] = await detectBackends([codexBackend], { config: { cwd: process.cwd() } });
console.log(codex.available, codex.version, codex.protocol, codex.auth, codex.usage);
```

**점검(`detect`)은 세 단계이고 스레드·턴을 열지 않는다**(모델 턴·구독 사용량 없음).
1. `codex --version` 을 기준 `CODEX_PROTOCOL_VERSION` 과 대조한다. 같으면 `protocol:'ok'`, 다르면 `'untested'`(쓸 수는 있다). 실행 파일이 없으면 `not-installed`.
2. 엔진과 같은 격리 홈·기동 인자로 `codex app-server` 를 잠깐 띄운다(MCP 서버는 붙이지 않는다). 홈 열기(옛 홈 옮기기·정책 항목 검사)도 엔진과 같다. 로그인 파일이 없으면 띄우지 않고 `not-logged-in`, 홈에 정책 항목이 있으면 `command-failed` 다(`detail` 에 사유 `codex-home-policy` 와 문제 경로).
3. `initialize` → `account/read`(없으면 `not-logged-in`, 구독이 아니면 `not-subscription`) → `account/rateLimits/read`(구독 사용률 `usage`, 못 읽어도 쓸 수 있음) 뒤 내린다. 설정 거부는 `command-failed`, 시한 초과는 `timeout`.

`validateConfig` 는 이 설정으로 엔진을 만들 수 없으면(지킬 수 없는 내장 도구 금지 등) 던진다. relay 는 그 백엔드를 `skipped{reason:'config'}` 로 건너뛴다.

### JSON-RPC 클라이언트 (`/protocol`, experimental)

프로토콜 원본 타입·메서드 상수·JSON-RPC 클라이언트는 `@agent-relay-engine/codex/protocol` 에 있다. **experimental** 이라 minor 에서 바뀔 수 있다. 엔진을 쓰기만 하면 필요 없다.

```ts check
import { nodeSpawn } from '@agent-relay-engine/core';
import { createRpc, isNotification } from '@agent-relay-engine/codex/protocol';

const rpc = createRpc(nodeSpawn('codex', ['app-server'], { cwd: process.cwd(), env: { PATH: process.env.PATH ?? '', HOME: process.env.HOME ?? '' } }));   // core 의 ChildHandle
await rpc.request('initialize', { clientInfo: { name: 'x', title: null, version: '0' }, capabilities: { experimentalApi: false } });
rpc.notify('initialized');
rpc.onServerRequest(async () => ({ decision: 'decline' }));
rpc.onNotification((n) => { if (isNotification(n, 'turn/completed')) console.log(n.params.turn.status); });
```

- 줄 형식에 `jsonrpc` 칸이 없다. 보낼 때도 넣지 않는다.
- 비JSON 줄과 모르는 메시지는 버리고 rawLog 에만 남긴다.
- error 응답은 `RpcError{code, message, data}`, 시한 초과는 `RpcTimeoutError`, 자식 종료·`close()` 는 대기 요청을 `RpcClosedError` 로 끝낸다.
- 서버 요청 처리기가 없으면 `-32601` 로 답한다. 처리기가 던지면 `-32603` 이다.

## 공개 API

<!-- gen:api @agent-relay-engine/codex . -->
`@agent-relay-engine/codex` — 19개, 공개 API 스냅샷 1.8.15 기준.

| 종류 | 이름 |
|---|---|
| function | `parseCodexVersion` · `resolveCodexPermissions` |
| class | `CodexEngine` |
| const | `ASK_INSTRUCTIONS` · `CODEX_CAPABILITIES` · `codexBackend` · `createCodexEngine` · `DEFAULT_CODEX_COMMAND` · `DEFAULT_CODEX_SUBAGENT_POLICY` · `DEFAULT_DISABLED_FEATURES` · `DEFAULT_SANDBOX` · `MCP_STARTUP_WAIT_MS` · `STRICT_CONFIG_FLAG` |
| type | `CodexEngineConfig` · `CodexOptions` · `CodexPermissions` · `CodexPermissionsBackend` · `CodexRecordExt` · `CodexResolvedPermissions` |
<!-- /gen -->

<!-- gen:api @agent-relay-engine/codex ./protocol -->
`@agent-relay-engine/codex/protocol` — 101개, 공개 API 스냅샷 1.8.15 기준.

| 종류 | 이름 |
|---|---|
| function | `createRpc` · `fileRawLog` · `isItemType` · `isNotification` · `isServerRequest` |
| class | `RpcClosedError` · `RpcError` · `RpcTimeoutError` |
| const | `CLIENT_NOTIFICATION_METHODS` · `CLIENT_REQUEST_METHODS` · `CODEX_PROTOCOL_VERSION` · `SERVER_NOTIFICATION_METHODS` · `SERVER_REQUEST_METHODS` · `THREAD_ITEM_TYPES` |
| type | `Account` · `AgentMessageItem` · `AskForApproval` · `ClientNotificationMap` · `ClientNotificationMethod` · `ClientRequestMap` · `ClientRequestMethod` · `CodexErrorInfo` · `CollabAgentToolCallItem` · `CommandExecutionItem` · `CommandExecutionRequestApprovalParams` · `CommandExecutionRequestApprovalResponse` · `CommandExecutionStatus` · `DeltaNotification` · `DynamicToolCallParams` · `DynamicToolCallResponse` · `FileChangeItem` · `FileChangeRequestApprovalParams` · `FileChangeRequestApprovalResponse` · `FileUpdateChange` · `GetAccountParams` · `GetAccountRateLimitsResponse` · `GetAccountResponse` · `InitializeParams` · `InitializeResponse` · `ItemNotification` · `JsonValue` · `KnownThreadItem` · `ListMcpServerStatusParams` · `ListMcpServerStatusResponse` · `McpServerElicitationRequestParams` · `McpServerElicitationRequestResponse` · `McpServerStatus` · `McpToolCallItem` · `McpToolCallResult` · `McpToolCallStatus` · `OtherItem` · `PatchApplyStatus` · `PermissionsRequestApprovalParams` · `PermissionsRequestApprovalResponse` · `PlanType` · `RateLimitSnapshot` · `RateLimitWindow` · `ReasoningItem` · `RequestId` · `RequestOptions` · `ReviewDecision` · `Rpc` · `RpcDirection` · `RpcNotification` · `RpcOptions` · `RpcRawLog` · `RpcServerRequest` · `SandboxMode` · `SandboxPolicy` · `ServerNotificationMap` · `ServerNotificationMethod` · `ServerRequestHandler` · `ServerRequestMap` · `ServerRequestMethod` · `SleepItem` · `SubAgentActivityItem` · `Thread` · `ThreadForkParams` · `ThreadForkResponse` · `ThreadItem` · `ThreadResumeParams` · `ThreadResumeResponse` · `ThreadStartParams` · `ThreadStartResponse` · `ThreadTokenUsage` · `TokenUsageBreakdown` · `ToolRequestUserInputParams` · `ToolRequestUserInputQuestion` · `ToolRequestUserInputResponse` · `Turn` · `TurnError` · `TurnInterruptParams` · `TurnInterruptResponse` · `TurnStartParams` · `TurnStartResponse` · `TurnStatus` · `TurnSteerParams` · `TurnSteerResponse` · `UserInput` · `UserMessageItem` · `WebSearchItem` |
<!-- /gen -->

## 설정

이 패키지를 가져오면 선언 병합으로 `EngineConfig.codex?: CodexOptions` 가 생긴다. Claude 전용 칸 `claude.*` 는 받기만 하고 프로세스마다 한 번 `core.config{warning:'ignored', fields}` 로 알린다.

| `codex.*` | 기본 | 뜻 |
|---|---|---|
| `command` | `'codex'` | 실행 파일 |
| `home` | 사용자 데이터 폴더의 `agent-relay-engine/codex-home/<cwd 해시>`([격리 홈](#격리-홈)) | 엔진 전용 `CODEX_HOME`(격리 홈). resume 은 같은 폴더여야 한다. 쓰기 가능 경로 안이면 `error(config, 'codex-home-writable')` |
| `authSource` | env `CODEX_HOME` 또는 `~/.codex` | 로그인 파일(`auth.json`)이 있는 원래 홈 |
| `disableFeatures` | `DEFAULT_DISABLED_FEATURES`(`apps`·`plugins`·`goals`·`hooks`·`multi_agent`) | `--disable` 로 끄는 기능 |
| `config` | 없음 | 추가 `-c` 값. 키는 점 경로, 값은 TOML 로 직렬화한다. 엔진이 넣는 `-c` 뒤에 붙어 같은 키면 이긴다 |
| `sandbox` | `'workspace-write'` | 새 스레드의 샌드박스. `permissions.mode:'plan'` 이면 `read-only` |
| `allowProjectConfig` | `false` | 프로젝트 `.codex/`(rules·config 등)가 있어도 띄운다(경고만). 위험은 [격리 홈](#격리-홈) |

- `started.permissions.backend` 는 `{approvalPolicy, sandbox}`(`CodexResolvedPermissions`)다.
- capabilities 는 `accepted-ack`·`control-interrupt`·`subscription-usage`·`inject` 이고, `includePartial` 이면 `text-delta`·`thinking`, `approval:'control'` 이면 `control-approval` 을 더한다.
- 문서 입력·비용 예산·`permission-edit-input` 이 없다. 프롬프트가 바뀌면 새 대화다. 전체 차이는 [대응표](../../docs/BACKENDS.md).
- 공통 칸은 [core README](../core/README.md#설정).

## 다른 문서

- [백엔드 대응표](../../docs/BACKENDS.md) · [testing README](../testing/README.md#가짜-codex-app-server) — 가짜 app-server `fakeCodexSpawn`
- 예제: `npm run example:cli -- --backend codex --fake basic-text`(가짜), `npm run example:cli -- --backend codex`(실제 codex, 격리 홈은 엔진 기본). `--profile`·`--control` 은 Claude 전용이라 함께 주면 인자 오류다

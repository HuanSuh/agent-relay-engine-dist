// 실제 CLI 의 stream-json 줄 모양을 흉내 낸다. 칸 이름은 core 파서(stream/parse.ts)가 읽는 것과 맞춘다.
import { randomUUID } from 'node:crypto';

const MODEL = 'claude-fake-1';
/** 띄우지 않은 MCP 서버가 init.tools 에 싣는 대표 도구 이름(mcp__<서버>__fake_tool) */
const FAKE_TOOL = 'fake_tool';
const BUILTIN_TOOLS = ['Task', 'Bash', 'Read', 'Write', 'Edit', 'Glob', 'Grep'];
/** 2.1.312 의 init.capabilities 일부(실측). 엔진이 control 계열을 미리 알아보는지 검증하는 데 쓴다. */
const INIT_CAPABILITIES = ['interrupt_receipt_v1', 'interrupt_cancel_queued_v1', 'interrupt_send_now_v1', 'msg_lifecycle_v1'];

/** 시나리오에 등장하는 tool_use 이름을 모아 init.tools 에 넣는다 — 엔진이 도구 목록을 검사할 수 있게. */
function collectTools(scenario, extraBuiltins = []) {
  const names = new Set([...BUILTIN_TOOLS, ...extraBuiltins]);
  const walk = (steps) => {
    for (const s of steps) {
      if (s.emit?.type === 'tool_use' && typeof s.emit.name === 'string') names.add(s.emit.name);
      if (Array.isArray(s.then)) walk(s.then);
    }
  };
  for (const t of scenario.turns) walk(t.steps);
  return [...names];
}

function mcpServers(tools) {
  // server 이름에는 `__` 가 없다고 본다 (core splitToolName 과 같은 규칙)
  const servers = new Set(tools.map(serverOf).filter((name) => name !== undefined));
  return [...servers].map((name) => ({ name, status: 'connected' }));
}

/** 실제 서버 상태가 우선. 시나리오에만 등장하는 서버는 connected 로 덧붙인다. */
function mergeServers(actual, fromScenario) {
  const known = new Set(actual.map((s) => s.name));
  return [...actual, ...fromScenario.filter((s) => !known.has(s.name))];
}

/**
 * mcpStatus 한 벌을 기본 서버 목록에 입힌다. 'omit' 이면 칸을 싣지 않는다(mcp_servers 가 없는 옛 CLI 흉내).
 * 객체면 이름 → 상태다: 목록에 있는 이름은 상태를 바꾸고, 없는 이름은 뒤에 덧붙이고, 값이 null 인 이름은 목록에서 뺀다.
 * connected 가 아닌 서버의 도구는 init.tools 에서도 빠진다.
 */
function applyMcpStatus(servers, spec) {
  if (spec === 'omit') return undefined;
  const has = (name) => Object.hasOwn(spec, name);
  // 'no-tools' 는 실측 모양(tools/list 가 오류인 서버)이다: 목록에는 connected 로 싣고 init.tools 에서 그 서버 도구만 뺀다(hiddenTools)
  const shown = (status) => (status === NO_TOOLS ? 'connected' : status);
  const out = servers.filter((s) => !has(s.name) || spec[s.name] !== null).map((s) => (has(s.name) ? { ...s, status: shown(spec[s.name]) } : s));
  const known = new Set(servers.map((s) => s.name));
  for (const [name, status] of Object.entries(spec)) if (status !== null && !known.has(name)) out.push({ name, status: shown(status) });
  return out;
}

const NO_TOOLS = 'no-tools';
/** 실제 CLI 가 도구 이름에 쓰는 정규화(core normalizeToolName 과 같다) */
const normalize = (name) => name.replace(/[^A-Za-z0-9_-]/g, '_');
/** mcp__<서버>__<도구> 의 서버 조각. MCP 도구가 아니면 undefined */
function serverOf(tool) {
  const at = tool.startsWith('mcp__') ? tool.indexOf('__', 5) : -1;
  return at > 5 ? tool.slice(5, at) : undefined;
}

/** mcpStatus 한 벌에서 connected 가 아닌(빠진 것·'no-tools' 포함) 서버의 도구는 init.tools 에 싣지 않는다 */
function hiddenTools(tools, spec) {
  if (spec === undefined || spec === 'omit') return tools;
  const hidden = new Set(Object.entries(spec).filter(([, status]) => status !== 'connected').flatMap(([name]) => [name, normalize(name)]));
  return tools.filter((t) => !hidden.has(serverOf(t)));
}

/** mcpStatus 칸의 모양: 한 벌('omit' 또는 이름 → 상태 문자열·null) 또는 그 배열(입력 순번별). 맞지 않으면 이유 */
export function mcpStatusProblem(v) {
  const one = (x) => x === 'omit' || (typeof x === 'object' && x !== null && !Array.isArray(x) && Object.values(x).every((s) => s === null || typeof s === 'string'));
  if (Array.isArray(v) ? v.length > 0 && v.every(one) : one(v)) return undefined;
  return "'omit' 또는 {서버 이름: 상태 문자열|null}, 또는 그 배열(비어 있지 않은)이어야 한다";
}

/** MCP 결과처럼 객체는 JSON 문자열을 담은 text 블록으로 감싼다. */
function toContent(v) {
  if (typeof v === 'string' || Array.isArray(v)) return v;
  return [{ type: 'text', text: JSON.stringify(v ?? null) }];
}

export function textOf(userMsg) {
  const c = userMsg?.message?.content;
  if (typeof c === 'string') return c;
  if (!Array.isArray(c)) return '';
  return c.filter((b) => b?.type === 'text' && typeof b.text === 'string').map((b) => b.text).join('');
}

/**
 * builtin:'off' 는 --tools '' 를 반영한 것이다 — init.tools 에서 내장 이름을 빼고 MCP 이름만 싣는다. 배열이면(--tools a,b) 그 내장 이름만 남긴다.
 * extraBuiltins 는 기본 목록에 더하는 내장 이름이다(실제 CLI 기본 목록의 확인 밖 도구 흉내). builtin 이 배열이면 거기 있는 것만 남는다.
 * initTools:'omit' 이면 init 에 tools 칸을 아예 싣지 않는다(실측이 없는 CLI 모양 흉내).
 */
/**
 * initEachTurn 이면 실제 CLI 처럼 user 메시지마다 init 을 다시 싣는다(beginInput). dirtyTurn 번째 입력의 init 은
 * builtin:'off' 여도 내장 이름을 싣는다 — 재사용 프로세스의 턴마다 보장 검사를 흉내 낸다.
 *
 * mcpStatus 를 주면 init.mcp_servers 를 그 값으로 입힌다(applyMcpStatus). 배열이면 N번째 입력의 init 에 N번째 벌을 쓰고, 모자라면 마지막 벌을 쓴다.
 * 주지 않으면 기본 목록 그대로다. 기본 목록은 --mcp-config 로 넘긴 서버(configServers, 브리지가 없으면 connected)와 시나리오에만 나온 서버다.
 *
 * outputBeforeInit: true 면 입력마다, 숫자 N 이면 N번째 입력에만 init 이 나가기 전에 assistant 줄(pre-init)을 먼저 낸다.
 * init 앞 출력을 흉내 낸다. 턴마다 init 을 다시 싣는 모드(initEachTurn)에서 그 턴의 init 보다 앞에 온다.
 */
export function createEmitter({ sessionId, scenario, cwd = process.cwd(), mcp, model: startModel, builtin = 'on', extraBuiltins = [], initTools = 'emit', initEachTurn = true, dirtyTurn, outputBeforeInit = false, mcpStatus, configServers = [] }) {
  // 브리지가 있으면 실제 서버가 내놓은 도구와 연결 상태를 싣는다. 시나리오에만 있는 이름도 남겨 기존 검사가 깨지지 않게 한다.
  const listed = [...new Set([...collectTools(scenario, extraBuiltins), ...(mcp?.tools ?? [])])];
  // 띄우지 않은(mcp:'off') 서버도 실제 CLI 처럼 도구를 init.tools 에 싣는다. 시나리오에 그 서버 도구가 없으면 대표 도구 하나를 싣는다
  const named = new Set(listed.map(serverOf));
  const allTools = [...listed, ...(mcp ? [] : configServers).filter((name) => !named.has(name) && !named.has(normalize(name))).map((name) => `mcp__${normalize(name)}__${FAKE_TOOL}`)];
  const mcpOnly = allTools.filter((t) => t.startsWith('mcp__'));
  let inputNo = 0;
  // 입력 전에 나가는 init(inputNo 0)은 첫 벌을 쓴다
  const statusNow = () => (Array.isArray(mcpStatus) ? mcpStatus[Math.min(Math.max(inputNo, 1), mcpStatus.length) - 1] : mcpStatus);
  const kept = Array.isArray(builtin) ? allTools.filter((t) => t.startsWith('mcp__') || builtin.includes(t)) : builtin === 'off' ? mcpOnly : allTools;
  const toolsNow = () => hiddenTools(inputNo !== dirtyTurn ? kept : allTools, statusNow());
  // 실측 CLI 는 --mcp-config 로 넘긴 서버를 모두 싣는다. 띄우지 않는 모드(mcp:'off')에서는 넘긴 서버를 connected 로 싣고, 브리지가 있으면 실제 상태를 쓴다
  const servers = mergeServers(mcp ? mcp.servers : configServers.map((name) => ({ name, status: 'connected' })), mcpServers(listed));
  const serversNow = () => (mcpStatus === undefined ? servers : applyMcpStatus(servers, statusNow()));
  let initSent = false;
  let msgSeq = 0;
  // --model 로 받은 이름. set_model 로 바뀐다. 없으면 고정 이름(기존 시나리오 동작)
  let model = startModel ?? MODEL;

  const write = (obj) => {
    process.stdout.write(JSON.stringify(obj) + '\n');
    return obj;
  };
  const stamp = (obj) => ({ ...obj, session_id: obj.session_id ?? sessionId, uuid: obj.uuid ?? randomUUID() });
  const assistant = (block, parent) =>
    stamp({
      type: 'assistant',
      message: {
        id: `msg_fake_${++msgSeq}`,
        type: 'message',
        role: 'assistant',
        model,
        content: [block],
        stop_reason: null,
        usage: { input_tokens: 0, output_tokens: 0 },
      },
      parent_tool_use_id: parent ?? null,
    });

  function result(overrides, turn) {
    const durationMs = turn ? Date.now() - turn.startedAt : 0;
    return stamp({
      type: 'result',
      subtype: 'success',
      is_error: false,
      duration_ms: durationMs,
      duration_api_ms: durationMs,
      num_turns: 1,
      result: turn?.lastText ?? '',
      total_cost_usd: 0.0012,
      usage: { input_tokens: 12, output_tokens: 8, cache_read_input_tokens: 0, cache_creation_input_tokens: 0 },
      permission_denials: turn?.denials ?? [],
      // 실 CLI 는 이 턴이 처리한 사람 메시지와 뒤에 밀린 입력 수를 싣는다
      ...(scenario.behavior.resultUuids && turn && { user_message_uuids: turn.uuids, queued_turn_count: turn.queued() }),
      ...overrides,
    });
  }

  /** 시나리오의 짧은 표기를 실제 줄로 편다. 모르는 type 은 실제 CLI 원문으로 보고 그대로 둔다. */
  function expand(spec, turn) {
    const { type, parent, ...rest } = spec;
    switch (type) {
      case 'text':
        return assistant({ type: 'text', text: String(rest.text ?? '').replaceAll('{{input}}', turn?.inputText ?? '') }, parent);
      case 'thinking':
        return assistant({ type: 'thinking', thinking: String(rest.text ?? ''), signature: 'fake' }, parent);
      case 'tool_use':
        return assistant({ type: 'tool_use', id: rest.id, name: rest.name, input: rest.input ?? {} }, parent);
      case 'tool_result':
        return stamp({
          type: 'user',
          message: {
            role: 'user',
            content: [{ type: 'tool_result', tool_use_id: rest.tool_use_id, content: toContent(rest.content), is_error: rest.is_error === true }],
          },
          parent_tool_use_id: parent ?? null,
        });
      case 'delta':
        return stamp({
          type: 'stream_event',
          event: { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: String(rest.text ?? '') } },
          parent_tool_use_id: parent ?? null,
        });
      case 'rate_limit':
        return stamp({ type: 'rate_limit_event', rate_limit_info: rest.info });
      case 'result':
        return result(rest, turn);
      default:
        return stamp(spec);
    }
  }

  return {
    write,
    expand,
    result,
    /** user 메시지 한 개가 들어왔다. initEachTurn 이면 이 입력의 init 을 다시 싣는다(첫 입력은 시작 때 낸 init 을 그대로 쓴다). */
    beginInput(extra = {}) {
      inputNo += 1;
      if (initEachTurn && inputNo > 1) initSent = false;
      if (!initSent && (outputBeforeInit === true || outputBeforeInit === inputNo)) write(assistant({ type: 'text', text: 'pre-init' }));
      this.ensureInit(extra);
    },
    ensureInit(extra = {}) {
      if (initSent) return;
      initSent = true;
      write(
        stamp({
          type: 'system',
          subtype: 'init',
          cwd,
          session_id: sessionId,
          tools: initTools === 'omit' ? undefined : toolsNow(),
          mcp_servers: serversNow(),
          model,
          permissionMode: 'default',
          apiKeySource: scenario.behavior.apiKeySource,
          slash_commands: [],
          output_style: 'default',
          claude_code_version: '0.0.0-fake',
          ...(scenario.behavior.initCapabilities && { capabilities: INIT_CAPABILITIES }),
          ...extra,
        }),
      );
    },
    /** --replay-user-messages 처럼 받은 사람 메시지를 되돌려 준다. uuid 는 보낸 쪽 것을 유지(ack 매칭용) — replayWithoutUuid 면 uuid 칸 없이(옛 CLI), replayNewUuid 면 CLI 가 새로 붙인 것처럼 바꾼다. */
    replay(msg) {
      const b = scenario.behavior;
      const line = stamp({ type: 'user', message: msg.message, parent_tool_use_id: null, uuid: b.replayNewUuid ? randomUUID() : msg.uuid, isReplay: true });
      if (b.replayWithoutUuid) delete line.uuid;
      return line;
    },
    /** set_model(실측 2.1.322 코드): 칸이 없거나 'default' 면 기본 모델로 돌아간다. 해석한 이름을 돌려준다 */
    setModel(name) {
      model = name === undefined || name === 'default' ? MODEL : name;
      return model;
    },
    model: () => model,
    controlError(requestId, error, extra = {}) {
      return { type: 'control_response', response: { subtype: 'error', request_id: requestId, error, ...extra } };
    },
    controlResponse(requestId, response) {
      return { type: 'control_response', response: { subtype: 'success', request_id: requestId, response: response ?? {} } };
    },
    flush: () => new Promise((resolve) => process.stdout.write('', () => resolve())),
  };
}

#!/usr/bin/env node
// 시나리오 기반 가짜 claude CLI. 실제 CLI 와 같은 인자를 받아도 되도록 세션 id 외의 인자는 무시한다.
import { randomUUID } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createInterface } from 'node:readline';
import { applyProcessBehavior } from './behavior.mjs';
import { createControl } from './control.mjs';
import { createEmitter, mcpStatusProblem } from './emit.mjs';
import { toolArgsClient } from '../fake-mcp/tool-args.mjs';
import { parseMcpConfigArgs, startMcpBridge } from './mcp.mjs';
import { loadScenario } from './scenario.mjs';
import { createRunner } from './turn.mjs';

function argValue(args, name) {
  const i = args.indexOf(name);
  if (i >= 0 && i + 1 < args.length) return args[i + 1];
  const eq = args.find((a) => a.startsWith(`${name}=`));
  return eq?.slice(name.length + 1);
}

let scenario;
try {
  scenario = loadScenario(process.env.FAKE_CLAUDE_SCENARIO);
} catch (e) {
  process.stderr.write(`fake-claude: ${e.message}\n`);
  process.exit(2);
}

// 읽는 쪽이 먼저 닫아도 스택 트레이스로 죽지 않게
process.stdout.on('error', () => process.exit(0));

const args = process.argv.slice(2);
// --resume <원본> --fork-session(실측 2.1.325): 원본 맥락을 이어받은 새 세션 id 를 만든다. 원본 id 는 init 의 fake_fork_from 으로 알린다
const forkFrom = args.includes('--fork-session') ? argValue(args, '--resume') : undefined;
// behavior.ignoreForkSession: --fork-session 을 따르지 않고 원본 id 로 이어 쓰는 CLI 흉내
const sessionId = forkFrom !== undefined && !scenario.behavior.ignoreForkSession ? randomUUID() : (argValue(args, '--session-id') ?? argValue(args, '--resume') ?? randomUUID());
const { behavior } = scenario;

// 시스템 프롬프트: 실제 CLI 처럼 기동 때 한 번 읽는다(E-60, 실측 2.1.325 — 뒤에 파일을 지워도 지시가 남는다). 읽은 글은 init 의 fake_system_prompt 로 알린다
let systemPrompt = argValue(args, '--append-system-prompt');
const promptFile = argValue(args, '--append-system-prompt-file');
if (promptFile !== undefined) {
  try {
    systemPrompt = readFileSync(promptFile, 'utf8');
  } catch (e) {
    process.stderr.write(`fake-claude: --append-system-prompt-file 을 읽을 수 없다: ${e.message}\n`);
    process.exit(1);
  }
}

// 없는 대화의 --resume(실측 2.1.322): stderr 문구, result{error_during_execution, is_error, num_turns:0}, exit 1
const missingResult = () =>
  process.stdout.write(JSON.stringify({ type: 'result', subtype: 'error_during_execution', is_error: true, num_turns: 0, duration_ms: 0, session_id: sessionId, permission_denials: [] }) + '\n', () => process.exit(1));
// 기동 직후 init 없이 끝난다(시나리오 startupExit)
if (scenario.startupExit) {
  const { code, stderr } = scenario.startupExit;
  if (stderr === undefined) process.exit(code);
  process.stderr.write(`${stderr}\n`, () => process.exit(code));
  await new Promise(() => {});
}
const resumeMissing = argValue(args, '--resume') !== undefined ? behavior.resumeMissing : 'off';
if (resumeMissing === 'stderr') {
  process.stderr.write(`No conversation found with session ID: ${sessionId}\n`, () => missingResult());
  await new Promise(() => {});
}
if (resumeMissing === 'result-only') {
  createInterface({ input: process.stdin }).once('line', () => missingResult());
  await new Promise(() => {});
}

// mcp:'spawn' — 서버를 먼저 띄워 init.tools 에 실제 도구를 싣는다. 그동안 온 stdin 줄은 파이프에 남아 있다가 아래에서 읽힌다.
let mcp;
if (process.env.FAKE_CLAUDE_MCP === 'spawn') {
  try {
    // 켜는 길은 두 가지다: 가짜 CLI 옵션(env, fakeSpawn 의 mcpStrictTools) 또는 시나리오 칸 mcpStrictTools
    mcp = await startMcpBridge(parseMcpConfigArgs(args), process.env.FAKE_CLAUDE_MCP_STRICT_TOOLS === '1' || scenario.mcpStrictTools === true);
  } catch (e) {
    process.stderr.write(`fake-claude: --mcp-config 를 읽을 수 없다: ${e.message}\n`);
    process.exit(2);
  }
}
// mcp:'off' — 서버를 띄우지 않지만 넘긴 이름은 init.mcp_servers 에 싣는다(실측 CLI 와 같다). 읽지 못한 --mcp-config 는 없는 것으로 본다
let configServers = [];
if (!mcp) {
  try {
    configServers = Object.keys(parseMcpConfigArgs(args));
  } catch {
    configServers = [];
  }
}
// --tools '' 는 내장 도구를 모두 끈다(실측 2.1.322). 실제 CLI 와 같게 기본으로 반영한다. FAKE_CLAUDE_BUILTIN_TOOLS=ignore 일 때만 무시한다(E-48).
// --tools a,b 는 그 내장 도구만 남긴다(분기 범위 {allow}, E5·D-194). 실측 2.1.325: Agent 를 주면 init 에는 Task 로 보이고, 기본 목록에 없는 이름은 실패 없이 빠진다
const toolsArg = process.env.FAKE_CLAUDE_BUILTIN_TOOLS !== 'ignore' ? argValue(args, '--tools') : undefined;
const listedTools = (arg) => {
  const names = arg.split(',');
  return names.includes('Agent') ? [...names, 'Task'] : names;
};
const builtin = toolsArg === '' ? 'off' : toolsArg !== undefined && toolsArg !== 'default' ? listedTools(toolsArg) : 'on';
// 실제 CLI 기본 목록에 실리는 확인 밖 도구 흉내(CronCreate 등). --tools 로 띄우면 빠진다
const extraBuiltins = (process.env.FAKE_CLAUDE_EXTRA_BUILTINS ?? '').split(',').filter((n) => n !== '');
const dirtyTurn = Number(process.env.FAKE_CLAUDE_DIRTY_TURN) || undefined;
/** 'all' 이면 입력마다, 양의 정수면 그 번째 입력에만 init 앞 출력을 낸다. 그 밖은 끈다(false). */
function outputBeforeInitOf(v) {
  if (v === 'all') return true;
  const n = Number(v);
  return Number.isInteger(n) && n > 0 ? n : false;
}
// init 은 기본적으로 턴마다 온다(D-120). FAKE_CLAUDE_INIT_EACH_TURN=0 일 때만 기동 때 한 번만 낸다.
const initEachTurn = process.env.FAKE_CLAUDE_INIT_EACH_TURN !== '0';
// init 의 MCP 서버 상태: 시나리오 칸이 있으면 그것을, 없으면 가짜 CLI 옵션(env, fakeSpawn 의 mcpStatus)을 쓴다. 둘 다 없으면 기본 목록 그대로다.
let mcpStatus = scenario.mcpStatus;
if (mcpStatus === undefined && process.env.FAKE_CLAUDE_MCP_STATUS) {
  try {
    mcpStatus = JSON.parse(process.env.FAKE_CLAUDE_MCP_STATUS);
  } catch {
    // JSON 이 아닌 값은 아래 모양 검사에 걸리게 한다
    mcpStatus = null;
  }
  if (mcpStatusProblem(mcpStatus)) {
    process.stderr.write(`fake-claude: FAKE_CLAUDE_MCP_STATUS 는 ${mcpStatusProblem(mcpStatus)}\n`);
    process.exit(2);
  }
}
const out = createEmitter({ sessionId, scenario, mcp, model: argValue(args, '--model'), builtin, extraBuiltins, initTools: process.env.FAKE_CLAUDE_INIT_TOOLS === 'omit' ? 'omit' : 'emit', initEachTurn, dirtyTurn, outputBeforeInit: outputBeforeInitOf(process.env.FAKE_CLAUDE_OUTPUT_BEFORE_INIT), mcpStatus, configServers });

const childPid = applyProcessBehavior(behavior);
if (childPid !== undefined) {
  // 그룹 종료 검증 쪽이 자식 생존을 확인할 수 있게 pid 를 알린다 (파서는 ignore 로 넘긴다)
  out.write({ type: 'system', subtype: 'fake_child', pid: childPid, session_id: sessionId });
}
const initExtra = { ...(childPid !== undefined && { fake_child_pid: childPid }), ...(forkFrom !== undefined && { fake_fork_from: forkFrom }), ...(systemPrompt !== undefined && { fake_system_prompt: systemPrompt }) };
const runner = createRunner({ out: { ...out, ensureInit: () => out.ensureInit(initExtra), beginInput: () => out.beginInput(initExtra) }, scenario, mcp, sessionId, toolArgs: toolArgsClient(process.env, 'FAKE_CLAUDE_') });
const handleControl = createControl({ out, runner, behavior });

if (behavior.initTiming === 'before-first-input') out.ensureInit(initExtra);

const rl = createInterface({ input: process.stdin, crlfDelay: Infinity });
rl.on('line', (line) => {
  let msg;
  try {
    msg = JSON.parse(line);
  } catch {
    process.stderr.write(`fake-claude: JSON 이 아닌 입력 무시: ${line.slice(0, 80)}\n`);
    return;
  }
  if (msg?.type === 'control_request') handleControl(msg);
  else if (msg?.type === 'control_response') runner.controlResponse(msg);
  else if (msg?.type === 'user') runner.input(msg);
});
rl.on('close', () => runner.end());

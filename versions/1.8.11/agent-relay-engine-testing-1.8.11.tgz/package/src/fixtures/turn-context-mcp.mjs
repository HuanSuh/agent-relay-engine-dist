#!/usr/bin/env node
// 턴 문맥 창구(E-22) 통합 테스트용 stdio MCP 서버. 도구 호출마다 core 의 readTurnContext 로 그 호출의 턴 문맥을 읽어 돌려준다.
// `--conditions=source --import tsx` 로 띄워 워크스페이스 core 의 src 를 쓴다.
import { createHash } from 'node:crypto';
import { createInterface } from 'node:readline';
import { readTurnContext } from '@agent-relay-engine/core';

const TOOLS = [
  { name: 'ctx', description: '_meta 를 넘겨 이 호출의 턴 문맥을 읽는다', inputSchema: { type: 'object' } },
  { name: 'ctx_nometa', description: '_meta 없이 읽는다(열린 턴)', inputSchema: { type: 'object' } },
  { name: 'ctx_digest', description: 'context 값 대신 sha256 만 돌려준다(남기지 않음 검사용)', inputSchema: { type: 'object' } },
];
const text = (v) => [{ type: 'text', text: JSON.stringify(v) }];
const reply = (obj) => process.stdout.write(JSON.stringify({ jsonrpc: '2.0', ...obj }) + '\n');

async function call(name, meta) {
  const envTurnId = process.env.AGENT_RELAY_ENGINE_TURN_ID ?? null;
  // 창구가 env 로 왔는지(값은 돌려주지 않는다 — 결과가 원시 로그·이벤트에 실린다)
  const announced = Boolean(process.env.AGENT_RELAY_ENGINE_CONTEXT && process.env.AGENT_RELAY_ENGINE_CONTEXT_TOKEN);
  try {
    const live = await readTurnContext(name === 'ctx_nometa' ? undefined : meta);
    if (name === 'ctx_digest') {
      const digest = createHash('sha256').update(JSON.stringify(live?.context ?? null)).digest('hex');
      return { content: text({ turnId: live?.turnId ?? null, digest }) };
    }
    // 받은 _meta 의 백엔드 키(값이 아니라 id 다). 테스트가 그 키로 엔진에 다시 물어 키 표에 들어갔는지 본다
    const metaKey = meta?.['claudecode/toolUseId'] ?? meta?.['x-codex-turn-metadata']?.turn_id ?? null;
    return { content: text({ live, envTurnId, announced, metaKey }) };
  } catch (e) {
    return { content: text({ error: e.message, envTurnId, announced }), isError: true };
  }
}

createInterface({ input: process.stdin }).on('line', (line) => {
  const msg = JSON.parse(line);
  if (msg.method === undefined || msg.id === undefined) return;
  if (msg.method === 'initialize') {
    reply({ id: msg.id, result: { protocolVersion: msg.params.protocolVersion, capabilities: { tools: {} }, serverInfo: { name: 'turn-context', version: '0.0.0' } } });
  } else if (msg.method === 'tools/list') {
    reply({ id: msg.id, result: { tools: TOOLS } });
  } else if (msg.method === 'tools/call') {
    void call(msg.params.name, msg.params._meta).then((result) => reply({ id: msg.id, result }));
  } else {
    reply({ id: msg.id, error: { code: -32601, message: `모르는 메서드: ${msg.method}` } });
  }
});

#!/usr/bin/env node
// mcp:'spawn' 테스트용 최소 stdio MCP 서버. SDK 없이 줄 단위 JSON-RPC 로 echo·whoami·fail 세 도구만 내놓는다.
import { createInterface } from 'node:readline';

const argv = process.argv.slice(2);
const arg = (name) => {
  const i = argv.indexOf(name);
  return i >= 0 ? argv[i + 1] : undefined;
};
const TOOLS = [
  { name: 'echo', description: '입력을 그대로 돌려준다', inputSchema: { type: 'object' } },
  { name: 'whoami', description: '받은 세션 문맥과 pid', inputSchema: { type: 'object' } },
  { name: 'fail', description: '항상 isError', inputSchema: { type: 'object' } },
  { name: 'hang', description: '답하지 않는다. 취소 알림을 받으면 기록한다', inputSchema: { type: 'object' } },
  { name: 'cancelled', description: '지금까지 받은 취소 알림의 requestId', inputSchema: { type: 'object' } },
  { name: 'pingback', description: '답하기 전에 서버 쪽에서 ping 요청(id 1)을 보낸다', inputSchema: { type: 'object' } },
  { name: 'received', description: '지금까지 tools/call 로 받은 도구 이름(이 호출 전까지)', inputSchema: { type: 'object' } },
];
const cancelled = [];
/** tools/call 로 받은 도구 이름. strictTools 가 목록 밖 호출을 서버에 보내지 않는지 본다. */
const received = [];
let pingAnswered = false;
let waitingPing;
const text = (v) => [{ type: 'text', text: typeof v === 'string' ? v : JSON.stringify(v) }];

function call(name, input) {
  if (name === 'echo') return { content: text(input) };
  if (name === 'whoami') {
    const sessionId = process.env.AGENT_RELAY_ENGINE_SESSION_ID ?? arg('--session-id');
    return { content: text({ sessionId, pid: process.pid }) };
  }
  if (name === 'fail') return { content: text('실패'), isError: true };
  if (name === 'cancelled') return { content: text({ cancelled }) };
  if (name === 'received') return { content: text({ received: [...received] }) };
  return undefined;
}

const reply = (obj) => process.stdout.write(JSON.stringify({ jsonrpc: '2.0', ...obj }) + '\n');
createInterface({ input: process.stdin }).on('line', (line) => {
  const msg = JSON.parse(line);
  if (msg.method === 'notifications/cancelled') cancelled.push(msg.params.requestId);
  if (msg.method === undefined && msg.id === 'srv-1') {
    // 클라이언트가 서버발 ping 에 답했다 → 미뤄 둔 pingback 에 답한다
    pingAnswered = msg.result !== undefined;
    if (waitingPing !== undefined) reply({ id: waitingPing, result: { content: text({ pingAnswered }) } });
    return;
  }
  if (msg.method === undefined) return; // 그 밖의 응답(roots/list 거절 등)
  if (msg.id === undefined) return; // 알림
  if (msg.method === 'initialize') {
    reply({ id: msg.id, result: { protocolVersion: msg.params.protocolVersion, capabilities: { tools: {} }, serverInfo: { name: 'echo', version: '0.0.0' } } });
  } else if (msg.method === 'tools/list') {
    reply({ id: msg.id, result: { tools: TOOLS } });
  } else if (msg.method === 'tools/call' && msg.params.name === 'hang') {
    // 답하지 않는다
  } else if (msg.method === 'tools/call' && msg.params.name === 'pingback') {
    waitingPing = msg.id;
    // 클라이언트 요청 id 와 겹칠 수 있는 숫자 id 도 함께 보낸다 — 응답으로 오인하면 빈 결과가 된다
    process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: msg.id, method: 'roots/list' }) + '\n');
    process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: 'srv-1', method: 'ping' }) + '\n');
  } else if (msg.method === 'tools/call') {
    const res = call(msg.params.name, msg.params.arguments);
    received.push(msg.params.name);
    if (res) reply({ id: msg.id, result: res });
    else reply({ id: msg.id, error: { code: -32602, message: `모르는 도구: ${msg.params.name}` } });
  } else {
    reply({ id: msg.id, error: { code: -32601, message: `모르는 메서드: ${msg.method}` } });
  }
});

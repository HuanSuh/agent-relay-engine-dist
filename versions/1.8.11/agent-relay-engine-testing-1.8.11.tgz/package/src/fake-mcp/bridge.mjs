// 가짜 CLI(fake-claude·fake-codex)가 함께 쓰는 stdio MCP 클라이언트. 설정의 stdio 서버를 실제로 띄워 tools/call 을 돌린다.
// 의존성을 늘리지 않으려고 MCP stdio(줄 단위 JSON-RPC 2.0) 클라이언트를 직접 구현한다. 필요한 것은 initialize·tools/list·tools/call 뿐이다.
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';

const PROTOCOL_VERSION = '2025-06-18';

/**
 * 호출 쪽 이름표와 시한.
 *  - label: stderr 접두어와 clientInfo.name
 *  - envPrefix: 이 접두어로 시작하는 가짜 CLI 전용 변수는 서버에 넘기지 않는다
 *  - connectTimeoutMs: 서버 하나가 initialize·tools/list 에 답할 시한. 넘기면 그 서버는 failed 로 보고 나머지는 계속한다
 *  - callTimeoutMs: tools/call 시한. 답을 떨군 서버가 턴을 말없이 멈추지 않도록 오류 결과로 바꾼다
 *  - envVarsOnly: 부모의 AGENT_RELAY_ENGINE_* 는 spec.env_vars 에 적힌 것만 서버에 넘긴다(codex 의 env_vars, 실측 0.164.0)
 *  - strictTools: 기동 때 받은 tools/list 밖의 mcp__ 도구는 서버에 보내지 않고 "없는 도구" 오류로 답한다(기본 false, E-31)
 */
const DEFAULTS = { label: 'fake-mcp', envPrefix: 'FAKE_MCP_', connectTimeoutMs: 15000, callTimeoutMs: 30000, strictTools: false };

/** 실 Claude CLI(2.1.322)가 목록 밖 도구에 낸 문구(실측). Codex 모양은 추정이라 같은 문구를 쓴다. */
export const noSuchToolText = (fullName) => `<tool_use_error>Error: No such tool available: ${fullName}</tool_use_error>`;

function connectServer(name, spec, o) {
  // 표준 문맥은 인자나 env(AGENT_RELAY_ENGINE_*) 어느 쪽으로도 올 수 있다. 둘 다 spec 에 담겨 오므로 그대로 넘긴다.
  const child = spawn(spec.command, spec.args ?? [], {
    cwd: spec.cwd,
    env: { ...serverEnv(o.envPrefix, o.envVarsOnly ? (spec.env_vars ?? []) : undefined), ...(spec.env ?? {}) },
    stdio: ['pipe', 'pipe', 'pipe'],
  });
  const pending = new Map();
  let seq = 0;
  let closed = false;
  const failAll = (why) => {
    closed = true;
    for (const { reject } of pending.values()) reject(new Error(`MCP 서버 ${name}: ${why}`));
    pending.clear();
  };
  child.on('error', (e) => failAll(e.message));
  child.on('exit', (code, signal) => failAll(`종료됨 (code=${code} signal=${signal})`));
  child.stdin.on('error', () => {});
  // stdout 은 MCP 전용이라 우리 stdout(stream-json)과 섞지 않는다. stderr 는 진단용으로 접두어를 붙여 넘긴다.
  createInterface({ input: child.stderr }).on('line', (l) => process.stderr.write(`${o.label} mcp[${name}]: ${l}\n`));
  createInterface({ input: child.stdout }).on('line', (line) => {
    let msg;
    try {
      msg = JSON.parse(line);
    } catch {
      return;
    }
    if (typeof msg?.method === 'string') {
      // 서버발 요청: ping 만 답하고 나머지는 모른다고 한다(답이 없으면 기다리는 서버가 멈춘다). 알림은 버린다.
      if (msg.id !== undefined) send(msg.method === 'ping' ? { jsonrpc: '2.0', id: msg.id, result: {} } : { jsonrpc: '2.0', id: msg.id, error: { code: -32601, message: `${o.label} 는 ${msg.method} 를 지원하지 않는다` } });
      return;
    }
    if (msg?.id === undefined || !pending.has(msg.id)) return;
    const { resolve, reject } = pending.get(msg.id);
    pending.delete(msg.id);
    if (msg.error) reject(new Error(`MCP 서버 ${name}: ${msg.error.message ?? JSON.stringify(msg.error)}`));
    else resolve(msg.result);
  });
  const send = (obj) => child.stdin.write(JSON.stringify(obj) + '\n');
  /** signal 이 끊기면 notifications/cancelled 를 보내고 대기를 거둔다 — 실 CLI 처럼 interrupt 가 호출을 취소한다. */
  const request = (method, params, signal) => {
    if (closed) return Promise.reject(new Error(`MCP 서버 ${name}: 이미 닫혔다`));
    const id = ++seq;
    return new Promise((resolve, reject) => {
      const onAbort = () => {
        if (!pending.delete(id)) return;
        send({ jsonrpc: '2.0', method: 'notifications/cancelled', params: { requestId: id, reason: 'interrupted' } });
        reject(new Error(`MCP 서버 ${name}: ${method} 취소됨`));
      };
      const settle = (fn) => (v) => {
        signal?.removeEventListener('abort', onAbort);
        fn(v);
      };
      pending.set(id, { resolve: settle(resolve), reject: settle(reject) });
      if (signal?.aborted) return onAbort();
      signal?.addEventListener('abort', onAbort, { once: true });
      send({ jsonrpc: '2.0', id, method, params });
    });
  };
  return {
    name,
    child,
    request,
    notify: (method, params) => send({ jsonrpc: '2.0', method, ...(params && { params }) }),
    close(force = false) {
      if (child.exitCode !== null || child.signalCode !== null) return;
      child.stdin.end();
      child.kill(force ? 'SIGKILL' : 'SIGTERM');
    },
  };
}

function withTimeout(p, ms, what) {
  let timer;
  return Promise.race([
    p,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${what}: ${ms}ms 안에 답이 없다`)), ms);
    }),
  ]).finally(() => clearTimeout(timer));
}

/** 가짜 CLI 전용 변수는 서버에 넘기지 않는다. forward 가 있으면 엔진 문맥 변수는 그 목록에 있는 것만 넘긴다 */
function serverEnv(prefix, forward) {
  const env = { ...process.env };
  for (const k of Object.keys(env)) if (k.startsWith(prefix)) delete env[k];
  if (forward) for (const k of Object.keys(env)) if (k.startsWith('AGENT_RELAY_ENGINE_') && !forward.includes(k)) delete env[k];
  return env;
}

async function handshake(conn, label) {
  await conn.request('initialize', {
    protocolVersion: PROTOCOL_VERSION,
    capabilities: {},
    clientInfo: { name: label, version: '0.0.0' },
  });
  conn.notify('notifications/initialized');
  const list = await conn.request('tools/list', {});
  return (list?.tools ?? []).map((t) => t.name);
}

/**
 * stdio 서버를 모두 띄우고 도구 목록을 받는다. 실패한 서버는 status:'failed' 로 남기고 도구는 없다(실 CLI 의 init 과 같은 모양).
 * http 서버는 띄울 프로세스가 없어 건너뛴다.
 */
export async function startMcpBridge(servers, opts = {}) {
  const o = { ...DEFAULTS, ...opts };
  const conns = new Map();
  const spawned = [];
  // 어떤 경로로 끝나든 자식을 남기지 않는다. 기동 도중 끝나도 거두도록 띄우기 전에 건다.
  // exit 훅 안에서는 기다릴 수 없어 SIGKILL 로 마무리한다. 신호로 죽는 경우는 같은 프로세스 그룹 종료와 stdin EOF 가 맡는다.
  const closeAll = () => spawned.forEach((c) => c.close());
  process.on('exit', () => spawned.forEach((c) => c.close(true)));
  // init 의 순서가 기동 속도에 따라 흔들리지 않게 설정 순서대로 모은다
  const results = await Promise.all(
    Object.entries(servers).map(async ([name, spec]) => {
      if (name.includes('__')) process.stderr.write(`${o.label}: MCP 서버 이름 ${name} 에 '__' 가 있어 도구로 라우팅되지 않는다\n`);
      if (spec?.type === 'http' || typeof spec?.command !== 'string') return { name, status: 'failed', tools: [] };
      const conn = connectServer(name, spec, o);
      spawned.push(conn);
      try {
        const names = await withTimeout(handshake(conn, o.label), o.connectTimeoutMs, `MCP 서버 ${name}`);
        conns.set(name, conn);
        return { name, status: 'connected', tools: names.map((t) => `mcp__${name}__${t}`) };
      } catch (e) {
        process.stderr.write(`${o.label}: ${e.message}\n`);
        conn.close();
        return { name, status: 'failed', tools: [] };
      }
    }),
  );
  const statuses = results.map(({ name, status }) => ({ name, status }));
  const tools = results.flatMap((r) => r.tools);

  const toolSet = new Set(tools);
  return {
    tools,
    servers: statuses,
    /** strictTools 가 켜졌는가 */
    strict: o.strictTools === true,
    closeAll,
    callTool,
    /** 기동 때 받은 목록에 이 서버의 이 도구가 있는가(strictTools 검사용) */
    knowsTool(server, tool) {
      return toolSet.has(`mcp__${server}__${tool}`);
    },
    /** 이 브리지가 실행할 도구인가. mcp__<server>__<tool> 에서 server 는 `__` 를 갖지 않는다(core splitToolName 규칙). strictTools 면 mcp__ 이름은 모두 맡는다(목록 밖은 오류로 답한다). */
    handles(toolName) {
      if (o.strictTools === true) return typeof toolName === 'string' && toolName.startsWith('mcp__');
      return route(toolName) !== undefined;
    },
    /** tools/call 결과를 tool_result 블록 칸으로. 프로토콜 오류도 is_error 결과로 바꿔 턴이 멈추지 않게 한다. */
    /** meta 는 tools/call 의 _meta 다(실 CLI 가 싣는 백엔드 키, E-22) */
    async call(toolName, input, signal, meta) {
      // 목록 밖 도구는 서버에 보내지 않는다(실측: 서버 수신 0건). 결과는 문자열 content 의 is_error 다.
      if (o.strictTools === true && !toolSet.has(toolName)) return { content: noSuchToolText(toolName), is_error: true };
      const r = route(toolName);
      if (!r) throw new Error(`브리지가 모르는 도구: ${toolName}`);
      const timeout = new AbortController();
      const timer = setTimeout(() => timeout.abort(), o.callTimeoutMs);
      const both = signal ? AbortSignal.any([signal, timeout.signal]) : timeout.signal;
      try {
        const res = await r.conn.request('tools/call', { name: r.tool, arguments: input ?? {}, ...(meta && { _meta: meta }) }, both);
        return { content: res?.content ?? [], is_error: res?.isError === true };
      } catch (e) {
        const why = timeout.signal.aborted ? `MCP 서버 ${r.conn.name}: ${r.tool} 가 ${o.callTimeoutMs}ms 안에 답하지 않았다` : e.message;
        return { content: [{ type: 'text', text: why }], is_error: true };
      } finally {
        clearTimeout(timer);
      }
    },
  };

  /**
   * 서버 이름으로 tools/call 을 돌려 원래 결과를 그대로 준다. 실패는 {ok:false, message} 다.
   * call() 과 달리 structuredContent 같은 칸을 버리지 않는다.
   */
  async function callTool(server, tool, args, signal, meta) {
    const conn = conns.get(server);
    if (!conn) return { ok: false, message: `MCP 서버 ${server} 에 연결돼 있지 않다` };
    const timeout = new AbortController();
    const timer = setTimeout(() => timeout.abort(), o.callTimeoutMs);
    const both = signal ? AbortSignal.any([signal, timeout.signal]) : timeout.signal;
    try {
      return { ok: true, result: await conn.request('tools/call', { name: tool, arguments: args ?? {}, ...(meta && { _meta: meta }) }, both) };
    } catch (e) {
      return { ok: false, message: timeout.signal.aborted ? `MCP 서버 ${server}: ${tool} 가 ${o.callTimeoutMs}ms 안에 답하지 않았다` : e.message };
    } finally {
      clearTimeout(timer);
    }
  }

  function route(toolName) {
    if (typeof toolName !== 'string' || !toolName.startsWith('mcp__')) return undefined;
    const at = toolName.indexOf('__', 5);
    if (at <= 5) return undefined;
    const conn = conns.get(toolName.slice(5, at));
    return conn ? { conn, tool: toolName.slice(at + 2) } : undefined;
  }
}

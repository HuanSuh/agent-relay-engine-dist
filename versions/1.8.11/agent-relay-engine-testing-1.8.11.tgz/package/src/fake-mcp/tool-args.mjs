// 도구 인자 변환 훅(E-33)의 자식 쪽. 가짜 CLI(claude·codex)가 tool_use 를 내기 직전에 부모(테스트 프로세스)의 훅에 인자를 묻는다.
// 프로토콜은 연결 하나에 요청 한 줄·응답 한 줄(JSON)이다. node:net 만 쓴다.
import { connect } from 'node:net';

/** 훅 응답 시한(ms). bridge 의 callTimeoutMs 와 같은 방식이며 env `<접두어>TOOL_ARGS_TIMEOUT_MS`(양수, ms)로 바꾼다 */
const DEFAULT_TIMEOUT_MS = 30_000;

/**
 * env 의 창구 주소·토큰으로 묻는 함수를 만든다. 주소가 없으면 undefined — 훅이 없는 것이라 아무것도 묻지 않는다.
 * prefix 는 가짜 CLI 의 env 접두어(FAKE_CLAUDE_ 또는 FAKE_CODEX_)다. 서버 자식에게 넘기지 않도록 같은 접두어를 쓴다.
 * 돌아오는 값은 { input } 또는 { error } 다. 소켓 오류·시한·중단(signal)도 error 로 묶는다.
 * 중단되면 연결을 끊고 { error: 'aborted' } 를 돌려준다. 호출 쪽은 이미 aborted 를 보고 아무것도 내지 않는다.
 */
export function toolArgsClient(env, prefix) {
  const path = env[`${prefix}TOOL_ARGS_SOCK`];
  const token = env[`${prefix}TOOL_ARGS_TOKEN`];
  if (!path) return undefined;
  // 양수가 아닌 값(음수·0·숫자 아님·빈 값)은 기본값이다 — 음수면 setTimeout 이 곧바로 끝나 모든 호출이 시한 오류가 된다
  const raw = Number(env[`${prefix}TOOL_ARGS_TIMEOUT_MS`]);
  const timeoutMs = Number.isFinite(raw) && raw > 0 ? raw : DEFAULT_TIMEOUT_MS;
  return (name, args, ctx, signal) => ask(path, JSON.stringify({ token, name, args, ctx }) + '\n', timeoutMs, signal);
}

function ask(path, line, timeoutMs, signal) {
  return new Promise((resolve) => {
    const sock = connect(path);
    let buf = '';
    let settled = false;
    const onAbort = () => finish({ error: 'aborted' });
    const finish = (res) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
      sock.destroy();
      resolve(res);
    };
    const timer = setTimeout(() => finish({ error: `훅이 ${timeoutMs}ms 안에 답하지 않았다` }), timeoutMs);
    if (signal?.aborted) return onAbort();
    signal?.addEventListener('abort', onAbort, { once: true });
    sock.setEncoding('utf8');
    sock.on('connect', () => sock.write(line));
    sock.on('error', (err) => finish({ error: `훅 창구에 닿지 못했다 (${err.code ?? err.message})` }));
    sock.on('data', (chunk) => {
      buf += chunk;
      const nl = buf.indexOf('\n');
      if (nl >= 0) finish(settle(buf.slice(0, nl)));
    });
    sock.on('end', () => finish(buf ? settle(buf) : { error: '훅 창구가 답 없이 닫았다' }));
  });
}

function settle(text) {
  let res;
  try {
    res = JSON.parse(text);
  } catch {
    return { error: '훅 창구의 응답을 읽지 못했다' };
  }
  if (res?.ok === true && typeof res.input === 'object' && res.input !== null && !Array.isArray(res.input)) return { input: res.input };
  return { error: typeof res?.error === 'string' ? res.error : '훅 창구의 응답 모양이 틀리다' };
}

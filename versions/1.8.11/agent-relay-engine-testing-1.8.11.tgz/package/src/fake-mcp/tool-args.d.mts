// tool-args.mjs 의 타입. 자식 쪽 묻는 함수는 훅 결과를 { input } 또는 { error } 로 돌려준다.
export type ToolArgsAnswer = { input: Record<string, unknown> } | { error: string };
export type ToolArgsAsk = (
  name: string,
  args: Record<string, unknown>,
  ctx: { sessionId?: string; turn: number; inputText: string; toolUseId: string },
  signal?: AbortSignal,
) => Promise<ToolArgsAnswer>;
/** env 의 창구 주소·토큰으로 묻는 함수. 주소가 없으면 undefined */
export function toolArgsClient(env: Readonly<Record<string, string | undefined>>, prefix: string): ToolArgsAsk | undefined;

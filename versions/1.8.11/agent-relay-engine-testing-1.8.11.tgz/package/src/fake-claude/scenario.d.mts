// 테스트가 .mjs 를 직접 import 할 때 쓰는 최소 선언
export function loadScenario(path: string | undefined): unknown;
export function validateScenario(s: unknown, where?: string): unknown;

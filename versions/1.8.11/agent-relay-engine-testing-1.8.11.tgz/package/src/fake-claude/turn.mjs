// 시나리오 턴 재생. 턴 중 들어온 입력(inject/queue)과 interrupt 가 현재 턴에 닿는 지점이 여기다.
import { randomUUID } from 'node:crypto';
import { textOf } from './emit.mjs';

/** abort 되면 예외 대신 일찍 깨어난다 — 단계 루프가 aborted 를 보고 멈춘다. */
function sleep(ms, signal) {
  if (ms <= 0 || signal.aborted) return Promise.resolve();
  return new Promise((resolve) => {
    const timer = setTimeout(done, ms);
    function done() {
      clearTimeout(timer);
      signal.removeEventListener('abort', done);
      resolve();
    }
    signal.addEventListener('abort', done);
  });
}

function hasExpectControl(steps) {
  return steps.some((s) => 'expectControl' in s);
}

/**
 * sessionId 와 toolArgs(fake-mcp/tool-args.mjs 의 묻는 함수, 없으면 undefined)는 인자 변환 훅(E-33)에 넘긴다.
 */
export function createRunner({ out, scenario, mcp, sessionId, toolArgs }) {
  const { behavior } = scenario;
  const queue = [];
  let turnIndex = 0;
  // repeatLastTurn 이면 턴이 모자랄 때 마지막 턴을 다시 쓴다(E-48)
  const turnAt = (i) => scenario.turns[scenario.repeatLastTurn && scenario.turns.length > 0 ? Math.min(i, scenario.turns.length - 1) : i];
  let current = null;
  let running = false;
  let ended = false;
  // 호스트 답을 기다리는 can_use_tool. request_id → resolve
  const asking = new Map();

  function input(msg) {
    out.beginInput();
    // 이미 result 를 냈거나 끊긴 턴에는 흡수하지 않는다 — 실제 CLI 라면 새 턴이 된다
    const open = current && !current.resultSent && !current.abort.signal.aborted;
    if (open && behavior.injectHandling === 'inject') {
      // 현재 턴에 흡수된다. 소비 시점에 replay 하므로 이 턴의 result 보다 앞에 나온다.
      current.injects.push(msg);
      current.uuids.push(msg.uuid);
      if (behavior.replayUserMessages) {
        if (behavior.lateInjectReplay) current.lateReplays.push(msg);
        else out.write(out.replay(msg));
      }
      return;
    }
    queue.push(msg);
    void pump();
  }

  async function pump() {
    if (running) return;
    running = true;
    while (queue.length > 0) {
      const msg = queue.shift();
      // queue 모드에서는 다음 턴이 시작될 때 replay — 앞 턴 result 뒤에 나와 inject 와 구분된다
      if (behavior.replayUserMessages) out.write(out.replay(msg));
      current = { input: msg, turn: turnIndex + 1, inputText: textOf(msg), injects: [], uuids: [msg.uuid].filter(Boolean), lateReplays: [], denials: [], queued: () => queue.length, abort: new AbortController(), startedAt: Date.now(), resultSent: false, lastText: undefined, bridged: new Set(), waitingControl: null, pendingControl: false, expectsControl: hasExpectControl(turnAt(turnIndex)?.steps ?? []) };
      await playTurn(turnAt(turnIndex++), current);
      current = null;
    }
    running = false;
    if (ended) await exit(0);
  }

  async function playTurn(turn, t) {
    if (!turn) {
      out.write(out.result({ subtype: 'error_during_execution', is_error: true, result: 'fake-claude: 남은 시나리오 턴이 없다' }, t));
      return;
    }
    await runSteps(turn.steps, t);
    if (t.abort.signal.aborted) return;
    flushInjects(t);
    if (!t.resultSent) out.write(out.result({}, t));
    for (const msg of t.lateReplays.splice(0)) out.write(out.replay(msg));
  }

  async function runSteps(steps, t) {
    for (const step of steps) {
      if (t.abort.signal.aborted) return;
      await runStep(step, t);
    }
  }

  async function runStep(step, t) {
    const { signal } = t.abort;
    if ('emit' in step) {
      await sleep(step.afterMs ?? 0, signal);
      if (signal.aborted) return;
      // 브리지가 이미 실제 결과를 낸 호출이면 시나리오에 적어 둔 tool_result 는 버린다 — 같은 시나리오를 두 모드에서 쓰게
      if (step.emit.type === 'tool_result' && t.bridged.has(step.emit.tool_use_id)) return;
      // 인자 변환 훅(E-33): tool_use 를 내기 직전에 묻는다. 훅이 없으면 시나리오 줄을 그대로 쓴다
      let spec = step.emit;
      let hookError;
      if (spec.type === 'tool_use' && toolArgs) {
        const r = await askToolArgs(spec, t);
        if (signal.aborted) return;
        if (r.error !== undefined) hookError = r.error;
        else spec = { ...spec, input: r.input };
      }
      const line = out.expand(spec, t);
      if (line.type === 'result') {
        // 끼워 넣은 입력은 턴이 끝나기 전에 응답돼야 inject 로 보인다
        flushInjects(t);
        t.resultSent = true;
      }
      emit(line, t);
      if (hookError !== undefined) {
        // 훅이 던졌거나 객체가 아니면 서버에 보내지 않고 오류 결과로 낸다. 시나리오가 적은 이 호출의 tool_result 는 버린다
        t.bridged.add(spec.id);
        emit(out.expand({ type: 'tool_result', tool_use_id: spec.id, content: hookError, is_error: true, parent: spec.parent }, t), t);
      } else if (spec.type === 'tool_use' && mcp?.handles(spec.name)) await callBridge(spec, t);
    } else if ('hangMs' in step) {
      await sleep(step.hangMs, signal);
    } else if ('partialChunks' in step) {
      for (let i = 0; i < step.partialChunks; i++) {
        await sleep(step.everyMs, signal);
        if (signal.aborted) return;
        out.write(out.expand({ type: 'delta', text: `chunk${i} ` }, t));
      }
    } else if ('exit' in step) {
      await out.flush();
      // 신호로 죽으면 'exit' 이벤트가 없다 — 띄운 MCP 서버를 먼저 내린다
      mcp?.closeAll();
      if (step.exit.signal) process.kill(process.pid, step.exit.signal);
      else process.exit(step.exit.code ?? 0);
      // 신호를 무시하도록 설정돼 있으면 살아남는다 → 멈춰 있지 않고 SIGKILL 로 마무리
      await new Promise((r) => setTimeout(r, 200));
      process.kill(process.pid, 'SIGKILL');
    } else if ('expectControl' in step) {
      // 단계에 닿기 전에 온 interrupt 는 걸어 둔 것을 쓴다
      if (!t.pendingControl) {
        await new Promise((resolve) => {
          t.waitingControl = resolve;
          signal.addEventListener('abort', resolve, { once: true });
        });
      }
      t.waitingControl = null;
      t.pendingControl = false;
      if (signal.aborted) return;
      await runSteps(step.then, t);
    } else if ('controlRequest' in step) {
      await askPermission(step, t);
    }
  }

  /** 실 CLI 처럼 답이 올 때까지 멈춘다. 거절이면 result 의 permission_denials 에 싣는다(실측 #25 의 형식). */
  async function askPermission(step, t) {
    const requestId = randomUUID();
    const toolUseId = step.toolUseId ?? `toolu_fake_${requestId.slice(0, 8)}`;
    const input = step.input ?? {};
    const onAbort = () => asking.get(requestId)?.(undefined);
    const answered = new Promise((resolve) => asking.set(requestId, resolve));
    t.abort.signal.addEventListener('abort', onAbort, { once: true });
    out.write({
      type: 'control_request',
      request_id: requestId,
      request: { subtype: 'can_use_tool', tool_name: step.tool, display_name: step.tool, input, permission_suggestions: [], tool_use_id: toolUseId },
    });
    // wait:false — 답을 받기 전에 턴을 끝내는 CLI(대기 승인이 버려지는 경로)를 흉내 낸다
    if (step.wait === false) {
      asking.delete(requestId);
      t.abort.signal.removeEventListener('abort', onAbort);
      return;
    }
    const res = await answered;
    asking.delete(requestId);
    t.abort.signal.removeEventListener('abort', onAbort);
    if (t.abort.signal.aborted) return;
    if (res?.subtype === 'success' && res.response?.behavior === 'allow') return runSteps(step.then.allow, t);
    t.denials.push({ tool_name: step.tool, tool_use_id: toolUseId, tool_input: input });
    await runSteps(step.then.deny, t);
  }

  /** 훅에 인자를 묻는다. 답은 { input } 또는 { error }(error 는 훅 오류 문구를 담는다). */
  async function askToolArgs(spec, t) {
    const r = await toolArgs(spec.name, spec.input ?? {}, { sessionId, turn: t.turn, inputText: t.inputText, toolUseId: spec.id }, t.abort.signal);
    return r.error !== undefined ? { error: `transformToolArgs 훅 오류: ${r.error}` } : { input: r.input };
  }

  /** mcp:'spawn' — 실제 서버에 tools/call 하고 그 결과를 tool_result 로 낸다. 기다리는 동안 끊긴 턴에는 내지 않는다. */
  async function callBridge(spec, t) {
    // 실 CLI(2.1.322)처럼 _meta 에 tool_use id 를 싣는다 — 서버가 턴 문맥 창구에서 이 호출의 턴을 찾는다(E-22)
    const res = await mcp.call(spec.name, spec.input, t.abort.signal, { 'claudecode/toolUseId': spec.id });
    if (t.abort.signal.aborted) return;
    t.bridged.add(spec.id);
    out.write(out.expand({ type: 'tool_result', tool_use_id: spec.id, content: res.content, is_error: res.is_error, parent: spec.parent }, t));
  }

  function emit(line, t) {
    out.write(line);
    const block = line.type === 'assistant' ? line.message?.content?.[0] : undefined;
    if (block?.type === 'text' && line.parent_tool_use_id === null) t.lastText = block.text;
  }

  function flushInjects(t) {
    for (const msg of t.injects.splice(0)) emit(out.expand({ type: 'text', text: `[injected] ${textOf(msg)}` }, t), t);
  }

  async function exit(code) {
    await out.flush();
    process.exit(code);
  }

  return {
    input,
    /** 호스트의 control_response. 기다리는 can_use_tool 이 없으면 버린다(늦은 답) */
    controlResponse(msg) {
      const r = msg.response ?? {};
      asking.get(r.request_id)?.(r);
    },
    /** stdin 이 닫히면 남은 턴을 마저 재생한 뒤 끝낸다 (실제 CLI 와 같음) */
    end() {
      ended = true;
      if (!running) void exit(0);
    },
    /** 이 턴에 expectControl 단계가 남아 있으면 interrupt 를 그쪽에 넘긴다 (아직 닿지 않았으면 걸어 둔다) */
    claimsControl: () => current != null && (current.waitingControl != null || (current.expectsControl && !current.resultSent)),
    releaseControl() {
      if (!current) return;
      if (current.waitingControl) current.waitingControl();
      else current.pendingControl = true;
    },
    /** honor 경로. 이미 result 를 낸 턴은 건드리지 않는다. 끝낸 턴이 있으면 true. */
    abortTurn() {
      const t = current;
      if (!t || t.resultSent || t.abort.signal.aborted) return false;
      t.abort.abort();
      t.resultSent = true;
      t.injects.length = 0;
      out.write(out.result({ subtype: 'error_during_execution', is_error: true, result: '' }, t));
      return true;
    },
  };
}

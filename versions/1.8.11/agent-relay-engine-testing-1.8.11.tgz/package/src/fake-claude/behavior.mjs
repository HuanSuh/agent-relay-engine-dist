// CLI 비공개 동작 변형 스위치. 실제 CLI 버전마다 다른 동작을 시나리오에서 고를 수 있게 한다.
import { spawn } from 'node:child_process';

const CHOICES = {
  initTiming: ['before-first-input', 'after-first-input'],
  apiKeySource: ['none', 'ANTHROPIC_API_KEY', 'apiKeyHelper'],
  controlInterrupt: ['honor', 'ignore'],
  injectHandling: ['inject', 'queue'],
  // --resume 으로 떴는데 대화가 없다(실측 2.1.322). stderr: 기동 직후 stderr 문구 + result(error_during_execution, num_turns:0) + exit 1. result-only: 첫 입력 뒤 stderr 없이 result + exit 1
  resumeMissing: ['off', 'stderr', 'result-only'],
  // control set_model 에 대한 응답(E-20). honor: 바꾸고 response.model 로 답한다, reject: 오류 응답(error_code not_found), ignore: 답하지 않는다
  setModel: ['honor', 'reject', 'ignore'],
};
const FLAGS = ['ignoreSigterm', 'spawnChild', 'replayUserMessages', 'replayWithoutUuid', 'replayNewUuid', 'initCapabilities', 'resultUuids', 'lateInjectReplay', 'ignoreForkSession'];

// 기본값은 문서화된 CLI 동작 쪽: init 은 첫 입력 뒤, 턴 중 입력은 다음 턴으로
export const DEFAULT_BEHAVIOR = Object.freeze({
  initTiming: 'after-first-input',
  apiKeySource: 'none',
  ignoreSigterm: false,
  spawnChild: false,
  controlInterrupt: 'honor',
  injectHandling: 'queue',
  replayUserMessages: false,
  replayWithoutUuid: false,
  replayNewUuid: false,
  initCapabilities: false,
  resultUuids: true,
  lateInjectReplay: false,
  resumeMissing: 'off',
  setModel: 'honor',
  // --fork-session 을 따르지 않고 --resume 의 원본 id 로 이어 쓰는 CLI 흉내
  ignoreForkSession: false,
});

export function normalizeBehavior(b, where) {
  if (b === undefined) return { ...DEFAULT_BEHAVIOR };
  if (typeof b !== 'object' || b === null || Array.isArray(b)) throw new Error(`${where}.behavior 는 객체여야 한다`);
  for (const [k, v] of Object.entries(b)) {
    if (k in CHOICES) {
      if (!CHOICES[k].includes(v)) throw new Error(`${where}.behavior.${k} 는 ${CHOICES[k].join('|')} 중 하나여야 한다`);
    } else if (FLAGS.includes(k)) {
      if (typeof v !== 'boolean') throw new Error(`${where}.behavior.${k} 는 boolean 이어야 한다`);
    } else {
      throw new Error(`${where}.behavior.${k} 는 모르는 스위치다`);
    }
  }
  return { ...DEFAULT_BEHAVIOR, ...b };
}

/** 프로세스 수준 스위치를 적용하고, 띄운 자식이 있으면 pid 를 돌려준다. */
export function applyProcessBehavior(behavior) {
  if (behavior.ignoreSigterm) {
    // 핸들러가 있으면 node 기본 종료가 일어나지 않는다 → SIGKILL fallback 검증용
    process.on('SIGTERM', () => process.stderr.write('fake-claude: SIGTERM 무시\n'));
  }
  if (!behavior.spawnChild) return undefined;
  // MCP 서버 자식을 흉내. detached 를 주지 않아 부모와 같은 프로세스 그룹에 남긴다.
  // 그룹 종료가 빠졌을 때 고아가 영원히 남지 않도록 스스로 끝나는 시한을 둔다.
  const child = spawn(process.execPath, ['-e', 'setTimeout(() => {}, 60000)'], { stdio: 'ignore' });
  child.unref();
  return child.pid;
}

// stdin control_request 처리. interrupt 는 비공개 프로토콜이라 응답 여부를 스위치로 바꿔 2단 중지 fallback 을 검증한다.

export function createControl({ out, runner, behavior }) {
  // set_model(E-20). honor: 바꾸고 {model: 해석한 이름}, reject: 모르는 모델 오류(실측 2.1.322 모양: error_code 'not_found', 지금 model), ignore: 답하지 않는다
  const setModel = (requestId, request) => {
    if (behavior.setModel === 'ignore') return;
    if (behavior.setModel === 'reject') {
      out.write(out.controlError(requestId, `Model '${request.model}' not found`, { error_code: 'not_found', model: out.model() }));
      return;
    }
    out.write(out.controlResponse(requestId, { model: out.setModel(request.model) }));
  };
  return function handle(msg) {
    const requestId = typeof msg.request_id === 'string' ? msg.request_id : '';
    if (msg.request?.subtype === 'set_model') return setModel(requestId, msg.request);
    if (msg.request?.subtype !== 'interrupt') {
      // initialize 등 다른 요청은 SDK 식 엔진이 막히지 않도록 빈 성공으로 답한다
      out.write(out.controlResponse(requestId, {}));
      return;
    }
    const respond = () => out.write(out.controlResponse(requestId));
    // 시나리오가 expectControl 로 interrupt 뒤 동작을 직접 적었으면 그쪽이 우선
    if (runner.claimsControl()) {
      if (behavior.controlInterrupt !== 'ignore') respond();
      runner.releaseControl();
      return;
    }
    // 구버전 CLI 처럼 아무 응답도 하지 않는다 → 엔진은 grace 뒤 신호로 내려야 한다
    if (behavior.controlInterrupt === 'ignore') return;
    respond();
    runner.abortTurn();
  };
}

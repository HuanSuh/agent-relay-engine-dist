// 시나리오 로드·검증. 잘못 쓴 시나리오는 재생 도중이 아니라 시작 시점에 실패시켜 원인을 바로 보이게 한다.
import { readFileSync } from 'node:fs';
import { normalizeBehavior } from './behavior.mjs';
import { mcpStatusProblem } from './emit.mjs';

const isObj = (v) => typeof v === 'object' && v !== null && !Array.isArray(v);
const isMs = (v) => typeof v === 'number' && Number.isFinite(v) && v >= 0;

export function loadScenario(path) {
  if (!path) throw new Error('FAKE_CLAUDE_SCENARIO 가 비어 있다');
  let raw;
  try {
    raw = JSON.parse(readFileSync(path, 'utf8'));
  } catch (e) {
    throw new Error(`시나리오를 읽을 수 없다 (${path}): ${e.message}`);
  }
  return validateScenario(raw, path);
}

export function validateScenario(s, where = 'scenario') {
  if (!isObj(s)) throw new Error(`${where} 는 객체여야 한다`);
  if (!Array.isArray(s.turns)) throw new Error(`${where}.turns 는 배열이어야 한다`);
  if (s.description !== undefined && typeof s.description !== 'string') {
    throw new Error(`${where}.description 은 문자열이어야 한다`);
  }
  if (s.mcpStrictTools !== undefined && typeof s.mcpStrictTools !== 'boolean') {
    throw new Error(`${where}.mcpStrictTools 는 boolean 이어야 한다`);
  }
  if (s.repeatLastTurn !== undefined && typeof s.repeatLastTurn !== 'boolean') {
    throw new Error(`${where}.repeatLastTurn 은 boolean 이어야 한다`);
  }
  if (s.mcpStatus !== undefined && mcpStatusProblem(s.mcpStatus)) throw new Error(`${where}.mcpStatus 는 ${mcpStatusProblem(s.mcpStatus)}`);
  if (s.startupExit !== undefined) {
    const e = s.startupExit;
    if (!isObj(e) || !Number.isInteger(e.code) || (e.stderr !== undefined && typeof e.stderr !== 'string')) {
      throw new Error(`${where}.startupExit 는 {code: 정수, stderr?: 문자열} 이어야 한다`);
    }
  }
  s.turns.forEach((turn, i) => {
    const at = `${where}.turns[${i}]`;
    if (!isObj(turn) || !Array.isArray(turn.steps)) throw new Error(`${at}.steps 는 배열이어야 한다`);
    checkSteps(turn.steps, at);
  });
  return { ...s, behavior: normalizeBehavior(s.behavior, where) };
}

function checkSteps(steps, at) {
  steps.forEach((step, i) => checkStep(step, `${at}.steps[${i}]`));
}

function checkStep(step, at) {
  if (!isObj(step)) throw new Error(`${at} 는 객체여야 한다`);
  if ('emit' in step) {
    if (!isObj(step.emit) || typeof step.emit.type !== 'string') throw new Error(`${at}.emit 은 type 이 있는 객체여야 한다`);
    if (step.afterMs !== undefined && !isMs(step.afterMs)) throw new Error(`${at}.afterMs 는 0 이상 숫자여야 한다`);
  } else if ('hangMs' in step) {
    if (!isMs(step.hangMs)) throw new Error(`${at}.hangMs 는 0 이상 숫자여야 한다`);
  } else if ('partialChunks' in step) {
    if (!Number.isInteger(step.partialChunks) || step.partialChunks < 0 || !isMs(step.everyMs)) {
      throw new Error(`${at} 는 partialChunks(정수)와 everyMs 가 필요하다`);
    }
  } else if ('exit' in step) {
    const { code, signal } = isObj(step.exit) ? step.exit : {};
    if (!isObj(step.exit) || (code !== undefined && !Number.isInteger(code)) || (signal !== undefined && typeof signal !== 'string')) {
      throw new Error(`${at}.exit 는 {code?: 정수, signal?: 문자열} 이어야 한다`);
    }
  } else if ('expectControl' in step) {
    if (step.expectControl !== 'interrupt' || !Array.isArray(step.then)) {
      throw new Error(`${at} 는 expectControl:'interrupt' 와 then 배열이 필요하다`);
    }
    checkSteps(step.then, `${at}.then`);
  } else if ('controlRequest' in step) {
    const then = step.then;
    if (step.controlRequest !== 'can_use_tool' || typeof step.tool !== 'string' || !isObj(then) || !Array.isArray(then.allow) || !Array.isArray(then.deny) || (step.wait !== undefined && typeof step.wait !== 'boolean') || (step.unlisted !== undefined && typeof step.unlisted !== 'boolean')) {
      throw new Error(`${at} 는 controlRequest:'can_use_tool', tool(문자열), then:{allow:[], deny:[]} 가 필요하다(wait·unlisted 는 boolean)`);
    }
    checkSteps(then.allow, `${at}.then.allow`);
    checkSteps(then.deny, `${at}.then.deny`);
  } else {
    throw new Error(`${at} 는 emit|hangMs|partialChunks|exit|expectControl|controlRequest 중 하나여야 한다`);
  }
}

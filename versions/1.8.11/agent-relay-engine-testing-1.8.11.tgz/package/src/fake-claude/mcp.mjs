// mcp:'spawn' 모드. --mcp-config 의 stdio 서버를 실제로 띄워 시나리오의 mcp__<server>__<tool> 호출을 tools/call 로 돌린다.
// MCP 클라이언트는 fake-codex 와 함께 쓰려고 ../fake-mcp/bridge.mjs 로 옮겼다. 여기는 --mcp-config 해석과 이름표만 둔다.
import { readFileSync } from 'node:fs';
import { startMcpBridge as startShared } from '../fake-mcp/bridge.mjs';

/** 서버 하나가 initialize·tools/list 에 답할 시한. 넘기면 그 서버는 failed 로 보고 나머지는 계속한다. */
const CONNECT_TIMEOUT_MS = Number(process.env.FAKE_CLAUDE_MCP_TIMEOUT_MS) || 15000;
/** tools/call 시한. 답을 떨군 서버가 턴을 말없이 멈추지 않도록 is_error 결과로 바꾼다. */
const CALL_TIMEOUT_MS = Number(process.env.FAKE_CLAUDE_MCP_CALL_TIMEOUT_MS) || 30000;

/** 실 CLI 처럼 --mcp-config 는 여러 번 올 수 있고 값은 JSON 문자열이나 파일 경로다. 뒤에 온 같은 이름이 앞을 덮는다. */
export function parseMcpConfigArgs(args) {
  const values = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--mcp-config' && i + 1 < args.length) values.push(args[++i]);
    else if (a.startsWith('--mcp-config=')) values.push(a.slice('--mcp-config='.length));
  }
  const servers = {};
  for (const v of values) {
    const text = v.trimStart().startsWith('{') ? v : readFileSync(v, 'utf8');
    const parsed = JSON.parse(text);
    Object.assign(servers, parsed?.mcpServers ?? {});
  }
  return servers;
}

/** 공용 브리지를 fake-claude 이름표·env 접두어·시한으로 띄운다. strictTools 면 목록 밖 도구를 서버에 보내지 않는다(E-31) */
export function startMcpBridge(servers, strictTools = false) {
  return startShared(servers, {
    label: 'fake-claude',
    envPrefix: 'FAKE_CLAUDE_',
    connectTimeoutMs: CONNECT_TIMEOUT_MS,
    callTimeoutMs: CALL_TIMEOUT_MS,
    strictTools,
  });
}

// 테스트가 .mjs 를 직접 import 할 때 쓰는 최소 선언
export function loadScenario(source: string | undefined): any;
export function validateScenario(s: unknown, where?: string): any;
export function createTurnPicker(scenario: any): (inputText: string) => { match?: string; steps: unknown[] };

// {mcp} 단계: -c mcp_servers 로 받은 stdio 서버에 실제로 tools/call 한다.
// 승인(C8): 서버 default_tools_approval_mode 나 도구 tools.<t>.approval_mode 가 "approve" 가 아니고 단계가 approval 을 요구하면 묻는다.
// 끄기(D-067): 서버 enabled=false 이거나 disabled_tools 에 있으면 모델이 그 도구를 보지 못한다 — 항목 없이 단계를 건너뛴다.
//  - 승인 정책 never → 묻지 않고 failed("MCP tool call requires approval, but approval policy is never")
//  - 그 밖 → mcpServer/elicitation/request(form). accept 면 호출, decline·cancel 이면 failed

import { noSuchToolText } from '../fake-mcp/bridge.mjs';

export const NEVER_MESSAGE = 'MCP tool call requires approval, but approval policy is never';

/**
 * @param env 턴 실행기 env(mcp 브리지, mcpServers, nextItemId, approvalPolicy)
 * @param io {{ ctx, started, completed, ask }}
 */
export async function runMcpStep(env, io, spec) {
  const { ctx, started, completed, ask } = io;
  const serverSpec = env.mcpServers[spec.server];
  if (env.disabledServers?.includes(spec.server) || serverSpec?.disabled_tools?.includes(spec.tool)) return undefined;
  const itemId = env.nextItemId('call');
  // 인자 변환 훅(E-33): 이름은 원래 것(mcp__<server>__<tool>)으로 묻고, 바뀐 인자를 항목과 서버 호출에 똑같이 쓴다.
  // 훅이 던지면 서버에 보내지 않고 실패 항목으로 낸다. 턴은 이어 간다.
  let args = spec.arguments ?? {};
  let hookError;
  if (env.toolArgs) {
    // sessionId 는 엔진 세션 쪽 값이다(subThread 의 sub 는 policyThreadId 로 부모 세션을 싣는다)
    const r = await env.toolArgs(`mcp__${spec.server}__${spec.tool}`, args, { sessionId: ctx.policyThreadId ?? ctx.threadId, turn: ctx.turn, inputText: ctx.inputText, toolUseId: itemId }, ctx.abort.signal);
    if (ctx.abort.signal.aborted) return { status: 'interrupted' };
    if (r.error !== undefined) hookError = `transformToolArgs 훅 오류: ${r.error}`;
    else args = r.input;
  }
  const item = { type: 'mcpToolCall', id: itemId, server: spec.server, tool: spec.tool, status: 'inProgress', arguments: args, appContext: null, mcpAppUi: null, pluginId: null, readOnlyHint: null, result: null, error: null, durationMs: null };
  const fail = (message) => {
    completed(ctx, { ...item, status: 'failed', error: { message }, durationMs: 0 });
    return undefined;
  };
  started(ctx, item);
  if (hookError !== undefined) return fail(hookError);
  // strictTools: 기동 때 목록에 없는 도구는 서버에 보내지 않고 실패로 낸다(Codex 모양은 추정 — 실측 전)
  if (env.mcp?.strict && !env.mcp.knowsTool(spec.server, spec.tool)) return fail(noSuchToolText(`mcp__${spec.server}__${spec.tool}`));

  const approved = serverSpec?.default_tools_approval_mode === 'approve' || serverSpec?.tools?.[spec.tool]?.approval_mode === 'approve';
  const needsApproval = spec.approval === true && !approved;
  if (needsApproval) {
    if (env.approvalPolicy(ctx) === 'never') return fail(NEVER_MESSAGE);
    const r = await ask(ctx, 'mcpServer/elicitation/request', {
      serverName: spec.server,
      mode: 'form',
      message: `Allow the ${spec.server} MCP server to run tool "${spec.tool}"?`,
      requestedSchema: { type: 'object', properties: {} },
      _meta: { codex_approval_kind: 'mcp_tool_call', tool_params: args, tool_description: spec.description ?? null, persist: ['session', 'always'] },
    });
    if (r === undefined) return { status: 'interrupted' };
    env.wire.notify('serverRequest/resolved', { threadId: ctx.threadId, requestId: r.requestId });
    // C19: cancel 은 턴을 끝낸다
    if (r.result?.action === 'cancel') {
      completed(ctx, { ...item, status: 'failed', error: { message: 'user cancelled MCP tool call' }, durationMs: 0 });
      return { status: 'interrupted' };
    }
    const action = r.result?.action;
    if (action !== 'accept') return fail(action === 'decline' ? 'user rejected MCP tool call' : 'user cancelled MCP tool call');
  }

  if (!env.mcp) return fail(`MCP 서버 ${spec.server} 가 설정에 없다`);
  const t0 = Date.now();
  // 실 codex(0.164.0)처럼 _meta 에 app-server 턴 id 를 싣는다 — 서버가 턴 문맥 창구에서 이 호출의 턴을 찾는다(E-22)
  const meta = { callId: item.id, itemId: item.id, threadId: ctx.threadId, 'x-codex-turn-metadata': { turn_id: ctx.turnId, thread_id: ctx.threadId } };
  const res = await env.mcp.callTool(spec.server, spec.tool, args, ctx.abort.signal, meta);
  if (ctx.abort.signal.aborted) return { status: 'interrupted' };
  if (!res.ok) return fail(res.message);
  const result = { content: res.result?.content ?? [], structuredContent: res.result?.structuredContent ?? null, _meta: res.result?._meta ?? null };
  completed(ctx, { ...item, status: res.result?.isError === true ? 'failed' : 'completed', result, durationMs: Date.now() - t0 });
  return undefined;
}

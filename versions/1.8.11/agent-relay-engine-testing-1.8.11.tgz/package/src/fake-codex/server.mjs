// 클라이언트 요청 처리. 줄 형식은 실제 app-server 처럼 `jsonrpc` 칸이 없다(C1).
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { createTurnPicker } from './scenario.mjs';
import { createTurnRunner } from './turn.mjs';
import { uuidv7 } from './store.mjs';

const WEEK_SECS = 7 * 24 * 3600;

/** stdout 쓰기와 서버발 요청의 응답 대조 */
export function createWire() {
  const pending = new Map();
  let seq = 0;
  const write = (obj) => process.stdout.write(JSON.stringify(obj) + '\n');
  return {
    respond: (id, result) => write({ id, result }),
    fail: (id, code, message) => write({ id, error: { code, message } }),
    notify: (method, params) => write({ method, params }),
    /** 돌려준 Promise 의 requestId 가 보낸 id 다. signal 이 끊기면 대기를 거둔다 */
    request(method, params, signal) {
      const id = seq++;
      const p = new Promise((resolve, reject) => {
        const onAbort = () => {
          pending.delete(id);
          reject(new Error('중단됨'));
        };
        if (signal?.aborted) return onAbort();
        signal?.addEventListener('abort', onAbort, { once: true });
        pending.set(id, { resolve, reject, done: () => signal?.removeEventListener('abort', onAbort) });
        write({ id, method, params });
      });
      p.requestId = id;
      return p;
    },
    /** 응답이면 대기에 넘기고 true */
    onResponse(msg) {
      const p = pending.get(msg.id);
      if (!p) return 'result' in msg || 'error' in msg;
      pending.delete(msg.id);
      p.done();
      if (msg.error) p.reject(Object.assign(new Error(msg.error.message ?? 'error'), { code: msg.error.code }));
      else p.resolve(msg.result);
      return true;
    },
  };
}

class ReqError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

const platformOs = () => ({ darwin: 'macos', win32: 'windows' })[process.platform] ?? process.platform;
const sandboxPolicy = (mode) =>
  mode === 'workspace-write'
    ? { type: 'workspaceWrite', writableRoots: [], networkAccess: false, excludeTmpdirEnvVar: false, excludeSlashTmp: false }
    : mode === 'danger-full-access'
      ? { type: 'dangerFullAccess' }
      : { type: 'readOnly', networkAccess: false };
const textOf = (input) => (Array.isArray(input) ? input.filter((i) => i?.type === 'text').map((i) => i.text).join('\n') : '');
const usage = (u = {}) => {
  const input = u.input ?? 100;
  const cached = u.cached ?? 0;
  const output = u.output ?? 20;
  const reasoning = u.reasoning ?? 0;
  return { totalTokens: input + output, inputTokens: input, cachedInputTokens: cached, cacheWriteInputTokens: 0, outputTokens: output, reasoningOutputTokens: reasoning };
};
const addUsage = (a, b) => Object.fromEntries(Object.keys(b).map((k) => [k, (a?.[k] ?? 0) + b[k]]));

/** cwd 위로 가장 가까운 git 루트(.git 이 있는 폴더). 없으면 undefined */
function gitRootOf(cwd) {
  for (let dir = resolve(cwd); ; dir = dirname(dir)) {
    if (existsSync(join(dir, '.git'))) return dir;
    if (dirname(dir) === dir) return undefined;
  }
}

/**
 * 진짜 app-server 처럼 git 저장소 cwd 의 thread/start 때 홈 config.toml 에 trust 기록을 쓴다(실측 13절):
 * `[projects."<git 루트>"]` 표에 `trust_level = "trusted"` 하나. 이미 있으면 그대로 둔다
 */
function recordTrust(codexHome, cwd) {
  const root = gitRootOf(cwd);
  if (!root || !codexHome) return;
  const file = join(codexHome, 'config.toml');
  const header = `[projects.${JSON.stringify(root)}]`;
  const cur = existsSync(file) ? readFileSync(file, 'utf8') : '';
  if (cur.includes(header)) return;
  writeFileSync(file, `${cur}${cur && !cur.endsWith('\n') ? '\n' : ''}${header}\ntrust_level = "trusted"\n`);
}

export function createServer({ wire, scenario, parsed, store, mcp, mcpServers, disabledServers = [], announced = Object.keys(mcpServers), codexHome, exit, toolArgs }) {
  const model = scenario.model ?? (typeof parsed.config.model === 'string' ? parsed.config.model : 'gpt-fake');
  const pick = createTurnPicker(scenario);
  const threads = new Map(); // 이 프로세스에 올린 스레드
  const active = new Map(); // threadId → 진행 중인 턴 문맥
  let itemSeq = 0;
  let initResponded = false;
  let initialized = false;

  const rateLimits = () =>
    scenario.rateLimits ?? {
      limitId: 'codex',
      limitName: null,
      primary: { usedPercent: 2, windowDurationMins: 10080, resetsAt: Math.floor(Date.now() / 1000) + WEEK_SECS },
      secondary: null,
      planType: 'plus',
      rateLimitReachedType: null,
    };

  const runner = createTurnRunner({
    wire,
    mcp,
    mcpServers,
    disabledServers,
    model,
    cwd: process.cwd(),
    exit,
    // 인자 변환 훅(E-33). 없으면 undefined 라 mcp 단계는 지금과 같다
    toolArgs,
    nextItemId: (prefix) => `${prefix}_${++itemSeq}`,
    approvalPolicy: (ctx) => threads.get(ctx.policyThreadId ?? ctx.threadId)?.approvalPolicy ?? 'on-request',
  });

  const threadView = (t, withTurns) => ({ id: t.id, sessionId: t.id, forkedFromId: null, parentThreadId: null, preview: t.preview ?? '', ephemeral: t.ephemeral, modelProvider: 'openai', model: t.model ?? model, createdAt: t.createdAt, updatedAt: t.updatedAt, status: { type: 'idle' }, path: null, cwd: t.cwd, cliVersion: '0.164.0', source: 'appServer', name: null, turns: withTurns ? t.turns : [] });
  const threadResponse = (t, withTurns) => ({ thread: threadView(t, withTurns), model: t.model ?? model, modelProvider: 'openai', serviceTier: null, disabledPluginIds: [], cwd: t.cwd, instructionSources: [], approvalPolicy: t.approvalPolicy, approvalsReviewer: 'user', sandbox: t.sandbox, reasoningEffort: null });

  const loaded = (threadId) => {
    const t = threads.get(threadId);
    if (!t) throw new ReqError(-32600, `thread not found: ${threadId}`);
    return t;
  };

  async function runTurn(t, ctx, turnSpec) {
    let end;
    try {
      end = await runner.runSteps(ctx, turnSpec.steps);
    } catch (e) {
      // 가짜 서버 자체의 오류는 프로세스를 죽이지 않고 failed 턴으로 드러낸다
      process.stderr.write(`fake-codex: 턴 실행 오류: ${e.stack ?? e}\n`);
      end = { status: 'failed', error: { message: `fake-codex 내부 오류: ${e.message}`, codexErrorInfo: 'other', additionalDetails: null } };
    }
    active.delete(t.id);
    const status = end?.status ?? 'completed';
    if (status === 'completed') {
      const last = usage(turnSpec.usage);
      t.totalUsage = addUsage(t.totalUsage, last);
      wire.notify('thread/tokenUsage/updated', { threadId: t.id, turnId: ctx.turnId, tokenUsage: { total: t.totalUsage, last, modelContextWindow: 272000 } });
      wire.notify('account/rateLimits/updated', { rateLimits: rateLimits() });
    }
    const turn = { id: ctx.turnId, items: [], itemsView: 'notLoaded', status, error: end?.error ?? null, startedAt: ctx.startedAt, completedAt: Math.floor(Date.now() / 1000), durationMs: Date.now() - ctx.startedAtMs };
    t.turns.push({ ...turn, items: ctx.items, itemsView: 'full' });
    t.updatedAt = Math.floor(Date.now() / 1000);
    store.save(t);
    wire.notify('turn/completed', { threadId: t.id, turn });
    // C20: 승인 대기 중 interrupt 된 요청의 resolved 는 turn/completed 뒤에 온다
    for (const requestId of ctx.unresolved ?? []) wire.notify('serverRequest/resolved', { threadId: t.id, requestId });
  }

  /**
   * 스레드에 MCP 서버를 붙인다(starting → ready|failed). 실제 app-server 의 mcpServer/startupStatus/updated 와 같은 모양이다.
   * 시나리오 mcpStartup 으로 서버별 상태를 바꾸거나('none' 이면 알림 없음) 늦출 수 있다.
   */
  function announceMcp(threadId) {
    const spec = scenario.mcpStartup ?? {};
    for (const name of announced) {
      // http 서버는 연결을 흉내 내지 않아 ready 로 본다
      const bridged = mcp?.servers.find((x) => x.name === name);
      const want = spec[name] ?? (!(name in mcpServers) || bridged?.status === 'connected' ? 'ready' : 'failed');
      if (want === 'none') continue;
      wire.notify('mcpServer/startupStatus/updated', { threadId, name, status: 'starting', error: null, failureReason: null });
      wire.notify('mcpServer/startupStatus/updated', { threadId, name, status: want, error: want === 'failed' ? 'fake: 연결 실패' : null, failureReason: null });
    }
  }

  function userMessage(ctx, input, clientId) {
    const item = { type: 'userMessage', id: uuidv7(), clientId: clientId ?? null, content: input };
    runner.started(ctx, item);
    runner.completed(ctx, item);
  }

  /** 진행 중 턴에 입력을 넣는다(steer·C17). awaitSteer 단계를 깨운다 */
  function steerInto(ctx, input, clientId) {
    userMessage(ctx, input, clientId);
    const w = ctx.steerWaiters.shift();
    if (w) w();
    else ctx.steered++;
  }

  const handlers = {
    initialize: async () => {
      await new Promise((r) => setTimeout(r, scenario.behavior.initDelayMs));
      initResponded = true;
      return { userAgent: 'fake-codex/0.164.0', codexHome, platformFamily: process.platform === 'win32' ? 'windows' : 'unix', platformOs: platformOs() };
    },
    'account/read': () => ({ account: scenario.account === undefined ? { type: 'chatgpt', email: null, planType: 'plus' } : scenario.account, requiresOpenaiAuth: true }),
    'account/rateLimits/read': () => ({ rateLimits: rateLimits(), rateLimitsByLimitId: { codex: rateLimits() }, rateLimitResetCredits: null, ordinaryUsageAllowed: true, accountId: null, rateLimitUpsell: null }),
    'thread/start': (p = {}) => {
      const now = Math.floor(Date.now() / 1000);
      const t = {
        id: uuidv7(),
        createdAt: now,
        updatedAt: now,
        cwd: p.cwd ?? process.cwd(),
        approvalPolicy: p.approvalPolicy ?? 'on-request',
        // 시나리오 threadSandbox 가 있으면 응답 sandbox 를 그것으로(엔진이 모르는 설정이 쓰기 범위를 넓힌 경우 흉내)
        sandbox: scenario.threadSandbox ?? sandboxPolicy(p.sandbox),
        ephemeral: p.ephemeral === true,
        developerInstructions: p.developerInstructions ?? null,
        config: p.config ?? null,
        // 시나리오 model 이 있으면 그것이 이긴다(기존 시나리오). 없으면 요청 model, 그것도 없으면 기본
        model: scenario.model ?? (typeof p.model === 'string' ? p.model : model),
        turns: [],
      };
      threads.set(t.id, t);
      store.save(t);
      recordTrust(codexHome, t.cwd);
      const res = threadResponse(t, false);
      setImmediate(() => {
        wire.notify('thread/started', { thread: threadView(t, false) });
        announceMcp(t.id);
      });
      return res;
    },
    'thread/resume': (p = {}) => {
      const t = threads.get(p.threadId) ?? store.load(p.threadId);
      if (!t) throw new ReqError(-32600, `no rollout found for thread id ${p.threadId}`);
      // C11: resume 때 준 developerInstructions 는 반영하지 않는다(받은 값은 FAKE_CODEX_LOG 에 남는다)
      if (p.approvalPolicy) t.approvalPolicy = p.approvalPolicy;
      if (p.sandbox) t.sandbox = scenario.threadSandbox ?? sandboxPolicy(p.sandbox);
      if (typeof p.model === 'string') t.model = p.model;
      threads.set(t.id, t);
      setImmediate(() => announceMcp(t.id));
      // C22: 이력 전체를 받는 resume 은 폐기 예정 알림을 낸다
      if (p.excludeTurns !== true) setImmediate(() => wire.notify('deprecationNotice', { summary: 'Full-history hydration is deprecated for paginated threads; use `excludeTurns: true`.', details: null }));
      return threadResponse(t, p.excludeTurns !== true);
    },
    // 실측 4절(0.164.0): 원본 스레드를 디스크에서 읽어 새 id 의 스레드로 복사한다. 원본은 바뀌지 않는다. 분기 때 준 sandbox·approvalPolicy 가 응답에 반영된다
    'thread/fork': (p = {}) => {
      const src = threads.get(p.threadId) ?? store.load(p.threadId);
      if (!src) throw new ReqError(-32600, `no rollout found for thread id ${p.threadId}`);
      if (scenario.forkSameThread) return threadResponse(src, p.excludeTurns !== true);
      const now = Math.floor(Date.now() / 1000);
      const t = {
        ...JSON.parse(JSON.stringify(src)),
        id: uuidv7(),
        createdAt: now,
        updatedAt: now,
        forkedFrom: src.id,
        cwd: p.cwd ?? src.cwd,
        approvalPolicy: p.approvalPolicy ?? src.approvalPolicy,
        sandbox: p.sandbox ? (scenario.threadSandbox ?? sandboxPolicy(p.sandbox)) : src.sandbox,
        ephemeral: p.ephemeral === true,
        developerInstructions: p.developerInstructions ?? src.developerInstructions ?? null,
        model: scenario.model ?? (typeof p.model === 'string' ? p.model : src.model),
      };
      threads.set(t.id, t);
      store.save(t);
      recordTrust(codexHome, t.cwd);
      const res = threadResponse(t, p.excludeTurns !== true);
      setImmediate(() => {
        wire.notify('thread/started', { thread: threadView(t, false) });
        announceMcp(t.id);
      });
      return res;
    },
    'turn/start': (p = {}) => {
      const t = loaded(p.threadId);
      const running = active.get(t.id);
      if (running) {
        // C17: 오류가 아니다. 진행 중인 같은 턴으로 성공하고 입력은 그 턴에 들어간다(steer 와 같다)
        setImmediate(() => steerInto(running, p.input ?? [], p.clientUserMessageId));
        return { turn: { id: running.turnId, items: [], itemsView: 'notLoaded', status: 'inProgress', error: null, startedAt: running.startedAt, completedAt: null, durationMs: null } };
      }
      if (p.approvalPolicy) t.approvalPolicy = p.approvalPolicy;
      if (p.sandboxPolicy) t.sandbox = p.sandboxPolicy;
      // 턴의 model 덮어쓰기는 스레드에 남는다(app-server 와 같게 — 엔진이 다음 턴에 되돌려야 한다)
      if (typeof p.model === 'string') t.model = p.model;
      // turn 은 1부터 세는 이 스레드의 턴 번호다(끝난 턴이 turns 에 쌓이므로 지금 것은 다음 번호). inputText 는 인자 변환 훅 문맥용이다
      const ctx = { threadId: t.id, sandbox: t.sandbox, turnId: uuidv7(), turn: t.turns.length + 1, inputText: textOf(p.input ?? []), items: [], abort: new AbortController(), steerWaiters: [], steered: 0, startedAt: Math.floor(Date.now() / 1000), startedAtMs: Date.now() };
      active.set(t.id, ctx);
      const input = p.input ?? [];
      t.preview ||= textOf(input);
      const turnSpec = pick(textOf(input));
      setImmediate(() => {
        wire.notify('turn/started', { threadId: t.id, turn: { id: ctx.turnId, items: [], itemsView: 'notLoaded', status: 'inProgress', error: null, startedAt: ctx.startedAt, completedAt: null, durationMs: null } });
        userMessage(ctx, input, p.clientUserMessageId);
        void runTurn(t, ctx, turnSpec);
      });
      return { turn: { id: ctx.turnId, items: [], itemsView: 'notLoaded', status: 'inProgress', error: null, startedAt: ctx.startedAt, completedAt: null, durationMs: null } };
    },
    'turn/steer': (p = {}) => {
      const ctx = active.get(p.threadId);
      if (!ctx) throw new ReqError(-32600, 'no active turn to steer');
      if (p.expectedTurnId !== ctx.turnId) throw new ReqError(-32600, `expected active turn id \`${p.expectedTurnId}\` but found \`${ctx.turnId}\``);
      setImmediate(() => steerInto(ctx, p.input ?? [], p.clientUserMessageId));
      return { turnId: ctx.turnId };
    },
    'turn/interrupt': (p = {}) => {
      const ctx = active.get(p.threadId);
      // C16: 백틱 없는 문구다(steer 와 다르다)
      if (!ctx) throw new ReqError(-32600, 'no active turn to interrupt');
      if (ctx.turnId !== p.turnId) throw new ReqError(-32600, `expected active turn id ${p.turnId} but found ${ctx.turnId}`);
      // C10: 응답 {} 가 먼저 나가고 turn/completed(interrupted) 가 뒤따른다. 알림은 모두 setImmediate 로 미뤄 응답 뒤에 나가게 한다
      if (!scenario.behavior.interruptIgnored) setImmediate(() => ctx.abort.abort());
      return {};
    },
    'mcpServerStatus/list': () => ({
      data: Object.keys(mcpServers).map((name) => {
        const status = mcp?.servers.find((s) => s.name === name)?.status;
        const tools = Object.fromEntries((mcp?.tools ?? []).filter((n) => n.startsWith(`mcp__${name}__`)).map((n) => n.slice(`mcp__${name}__`.length)).map((tool) => [tool, { name: tool }]));
        return { name, runtimeStatus: status === 'connected' ? 'connected' : 'failed', pluginId: null, tools, toolsError: null, resources: [], resourceTemplates: [], authStatus: 'unsupported' };
      }),
      nextCursor: null,
    }),
  };

  /** 받은 메시지 하나 */
  return async function handle(msg) {
    if (typeof msg?.method !== 'string') {
      wire.onResponse(msg);
      return;
    }
    if (msg.id === undefined) {
      if (msg.method === 'initialized' && initResponded) initialized = true;
      return;
    }
    const { id, method, params } = msg;
    try {
      if (method !== 'initialize' && !initialized) throw new ReqError(-32002, initResponded ? 'Not initialized: initialized 알림 전이다' : 'Not initialized');
      if (method === 'initialize' && initResponded) throw new ReqError(-32600, 'Already initialized');
      const h = handlers[method];
      if (!h) throw new ReqError(-32601, `Method not found: ${method}`);
      wire.respond(id, await h(params));
    } catch (e) {
      wire.fail(id, e instanceof ReqError ? e.code : -32603, e.message);
    }
  };
}

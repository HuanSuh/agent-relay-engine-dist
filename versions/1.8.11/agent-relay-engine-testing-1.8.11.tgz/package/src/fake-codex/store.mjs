// 스레드 상태. CODEX_HOME 아래 fake-threads/<threadId>.json 에 남겨 프로세스를 바꿔도 thread/resume 이 되게 한다(C11).
// ephemeral 스레드는 파일로 남기지 않는다 — 실제 codex 처럼 resume 대상이 아니다.
import { randomBytes } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

/** UUIDv7 모양: 앞 48비트가 ms 시각, 버전 7, variant 10 */
export function uuidv7() {
  const b = randomBytes(16);
  let ts = BigInt(Date.now());
  for (let i = 5; i >= 0; i--) {
    b[i] = Number(ts & 0xffn);
    ts >>= 8n;
  }
  b[6] = (b[6] & 0x0f) | 0x70;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = b.toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

export function createStore(codexHome) {
  const dir = join(codexHome, 'fake-threads');
  const file = (id) => join(dir, `${id.replace(/[^\w.-]/g, '_')}.json`);
  return {
    dir,
    save(thread) {
      if (thread.ephemeral) return;
      mkdirSync(dir, { recursive: true });
      // 쓰는 도중에 프로세스가 내려가도(중지·시간 초과) 다음 프로세스가 반쯤 쓴 파일을 읽지 않게 tmp+rename 으로 쓴다
      const tmp = `${file(thread.id)}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`;
      writeFileSync(tmp, JSON.stringify(thread));
      renameSync(tmp, file(thread.id));
    },
    /** 없으면 undefined */
    load(id) {
      if (typeof id !== 'string' || !existsSync(file(id))) return undefined;
      return JSON.parse(readFileSync(file(id), 'utf8'));
    },
  };
}

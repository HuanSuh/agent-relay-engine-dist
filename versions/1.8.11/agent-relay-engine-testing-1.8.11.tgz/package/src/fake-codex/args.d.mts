// 테스트가 .mjs 를 직접 import 할 때 쓰는 최소 선언
export function parseArgs(argv: string[]): {
  subcommand: string | undefined;
  overrides: { key: string; value: unknown }[];
  config: Record<string, any>;
  disabled: string[];
  enabled: string[];
  rest: string[];
};
export function mcpServersFromConfig(config: unknown): Record<string, { command: unknown; args: string[]; env: Record<string, string>; cwd?: unknown; default_tools_approval_mode?: unknown }>;
export function parseTomlValue(text: string): unknown;

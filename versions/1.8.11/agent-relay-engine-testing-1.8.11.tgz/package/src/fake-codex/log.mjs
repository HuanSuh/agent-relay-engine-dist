// FAKE_CODEX_LOG 가 있으면 기동 인자·env 유무·받은 메시지 전부를 JSONL 로 남긴다. 엔진 테스트가 단언에 쓴다.
import { appendFileSync } from 'node:fs';

export function createLog(path) {
  const write = (rec) => {
    if (!path) return;
    try {
      appendFileSync(path, JSON.stringify({ at: Date.now(), pid: process.pid, ...rec }) + '\n');
    } catch {
      // 기록 실패로 가짜 서버가 죽지 않게 한다
    }
  };
  return {
    start(parsed, argv) {
      write({
        type: 'start',
        argv,
        subcommand: parsed.subcommand,
        overrides: parsed.overrides,
        config: parsed.config,
        disabled: parsed.disabled,
        enabled: parsed.enabled,
        env: {
          CODEX_HOME: process.env.CODEX_HOME ?? null,
          // 값은 남기지 않는다(유무만)
          OPENAI_API_KEY: process.env.OPENAI_API_KEY !== undefined,
          CODEX_API_KEY: process.env.CODEX_API_KEY !== undefined,
        },
      });
    },
    recv(msg) {
      write({ type: 'recv', msg });
    },
  };
}

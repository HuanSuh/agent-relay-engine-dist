// 시나리오 턴 재생. 단계마다 item/* 알림과 서버 요청(승인·질문)을 낸다.
// 단계 사이와 모든 대기는 ctx.abort 로 깨어난다 — turn/interrupt 가 닿는 지점이다.
import { runMcpStep } from './mcp-step.mjs';
import { uuidv7 } from './store.mjs';

/** abort 되면 예외 대신 일찍 깨어난다 */
export function sleep(ms, signal) {
  if (ms <= 0 || signal?.aborted) return Promise.resolve();
  return new Promise((resolve) => {
    const done = () => {
      clearTimeout(timer);
      signal?.removeEventListener('abort', done);
      resolve();
    };
    const timer = setTimeout(done, ms);
    signal?.addEventListener('abort', done, { once: true });
  });
}

/** abort 되거나 register 가 받은 wake 가 불릴 때까지 기다린다. 어느 쪽이든 abort 리스너는 거둔다 */
function untilAbort(signal, register) {
  return new Promise((resolve) => {
    const done = () => {
      signal.removeEventListener('abort', done);
      resolve();
    };
    signal.addEventListener('abort', done, { once: true });
    register?.(done);
  });
}

/** 글을 몇 조각으로 나눈다(delta 여러 개) */
function chunks(text) {
  const n = Math.max(1, Math.min(3, text.length));
  const size = Math.ceil(text.length / n);
  const out = [];
  for (let i = 0; i < text.length; i += size) out.push(text.slice(i, i + size));
  return out.length > 0 ? out : [''];
}

const DECLINED = new Set(['decline', 'cancel']);
const INTERRUPTED = { status: 'interrupted' };

/**
 * @param env {{ wire, mcp, mcpServers, nextItemId(prefix): string, approvalPolicy(ctx): unknown, cwd: string, model: string }}
 */
export function createTurnRunner(env) {
  const { wire } = env;
  const scoped = (ctx) => ({ threadId: ctx.threadId, turnId: ctx.turnId });
  const started = (ctx, item) => wire.notify('item/started', { item, ...scoped(ctx), startedAtMs: Date.now() });
  const completed = (ctx, item) => {
    ctx.items.push(item);
    wire.notify('item/completed', { item, ...scoped(ctx), completedAtMs: Date.now() });
  };

  /**
   * 서버 요청을 보내고 답을 기다린다. 끊기면 undefined, 오류 응답이면 { error }.
   * C20: interrupt 로 끊긴 요청은 turn/completed(interrupted) 뒤에 serverRequest/resolved 를 낸다 — 턴 문맥에 남겨 runTurn 이 보낸다.
   */
  async function ask(ctx, method, params) {
    const pending = wire.request(method, { ...scoped(ctx), ...params }, ctx.abort.signal);
    try {
      return { result: await pending, requestId: pending.requestId };
    } catch (e) {
      if (ctx.abort.signal.aborted) {
        (ctx.unresolved ??= []).push(pending.requestId);
        return undefined;
      }
      return { error: e, requestId: pending.requestId };
    }
  }

  /** 승인 요청. accept·acceptForSession 이면 'accept', 끊기면 undefined */
  async function approve(ctx, method, params) {
    const r = await ask(ctx, method, params);
    if (r === undefined) return undefined;
    const d = r.result?.decision;
    const decision = r.error ? 'cancel' : typeof d === 'string' ? d : d && typeof d === 'object' ? 'accept' : 'cancel';
    wire.notify('serverRequest/resolved', { threadId: ctx.threadId, requestId: r.requestId });
    return DECLINED.has(decision) ? decision : 'accept';
  }

  async function command(ctx, spec) {
    const item = { type: 'commandExecution', id: env.nextItemId('call'), command: spec.command, cwd: spec.cwd ?? env.cwd, processId: null, source: 'agent', status: 'inProgress', commandActions: [], aggregatedOutput: null, exitCode: null, durationMs: null };
    started(ctx, item);
    if (spec.approval) {
      const d = await approve(ctx, 'item/commandExecution/requestApproval', { itemId: item.id, kind: 'command', command: spec.command, cwd: item.cwd, reason: spec.reason ?? null, startedAtMs: Date.now() });
      if (d === undefined) return INTERRUPTED;
      if (d !== 'accept') {
        completed(ctx, { ...item, status: 'declined' });
        return d === 'cancel' ? INTERRUPTED : undefined;
      }
    }
    await sleep(spec.ms ?? 0, ctx.abort.signal);
    if (ctx.abort.signal.aborted) return INTERRUPTED;
    // 쓰는 명령은 이 턴의 스레드 샌드박스가 읽기 전용이면 OS 가 막는다(실측 D-143: operation not permitted)
    const blocked = spec.writes === true && ctx.sandbox?.type === 'readOnly';
    const exitCode = blocked ? 1 : (spec.exitCode ?? 0);
    completed(ctx, { ...item, status: exitCode === 0 ? 'completed' : 'failed', exitCode, aggregatedOutput: blocked ? 'operation not permitted' : (spec.output ?? ''), durationMs: spec.ms ?? 1 });
    return undefined;
  }

  async function fileChange(ctx, spec) {
    const changes = spec.changes ?? [{ path: spec.path ?? 'file.txt', kind: { type: 'add' }, diff: spec.diff ?? '+fake\n' }];
    const item = { type: 'fileChange', id: env.nextItemId('call'), changes, status: 'inProgress' };
    started(ctx, item);
    if (spec.approval) {
      const d = await approve(ctx, 'item/fileChange/requestApproval', { itemId: item.id, reason: spec.reason ?? null, grantRoot: null, startedAtMs: Date.now() });
      if (d === undefined) return INTERRUPTED;
      if (d !== 'accept') {
        completed(ctx, { ...item, status: 'declined' });
        return d === 'cancel' ? INTERRUPTED : undefined;
      }
    }
    completed(ctx, { ...item, status: 'completed' });
    return undefined;
  }

  async function userInput(ctx, spec) {
    const questions = spec.questions.map((q, i) => ({ id: q.id ?? `q${i + 1}`, header: q.header ?? '', question: q.question ?? '', isOther: q.isOther ?? false, isSecret: q.isSecret ?? false, options: q.options ?? null }));
    const r = await ask(ctx, 'item/tool/requestUserInput', { itemId: env.nextItemId('call'), questions, isBlocking: true, autoResolutionMs: null });
    if (r === undefined) return INTERRUPTED;
    wire.notify('serverRequest/resolved', { threadId: ctx.threadId, requestId: r.requestId });
    return undefined;
  }

  /** C14: 같은 연결로 다른 threadId 의 턴을 내고, 부모 턴에는 subAgentActivity·collabAgentToolCall 을 낸다 */
  async function subThread(ctx, spec) {
    const agentThreadId = uuidv7();
    const activity = { type: 'subAgentActivity', id: env.nextItemId('call'), kind: 'started', agentThreadId, agentPath: spec.agentPath ?? '/root/worker', model: env.model, reasoningEffort: null };
    started(ctx, activity);
    completed(ctx, activity);
    // turn·inputText 는 부모 턴 것을 싣는다(인자 변환 훅 문맥, M3)
    const sub = { threadId: agentThreadId, policyThreadId: ctx.policyThreadId ?? ctx.threadId, turn: ctx.turn, inputText: ctx.inputText, turnId: uuidv7(), items: [], abort: ctx.abort, steerWaiters: [], steered: 0 };
    wire.notify('turn/started', { threadId: sub.threadId, turn: { id: sub.turnId, items: [], status: 'inProgress', error: null } });
    const end = await runSteps(sub, spec.steps);
    const status = end?.status ?? 'completed';
    wire.notify('turn/completed', { threadId: sub.threadId, turn: { id: sub.turnId, items: [], status, error: end?.error ?? null } });
    if (status === 'interrupted') return INTERRUPTED;
    const done = { ...activity, id: env.nextItemId('call'), kind: 'completed' };
    started(ctx, done);
    completed(ctx, done);
    const wait = { type: 'collabAgentToolCall', id: env.nextItemId('call'), tool: 'wait', status: 'completed', senderThreadId: ctx.threadId, receiverThreadIds: [agentThreadId], prompt: null, model: null, reasoningEffort: null, agentsStates: {} };
    started(ctx, { ...wait, status: 'inProgress' });
    completed(ctx, wait);
    return undefined;
  }

  /** 단계 하나. 턴을 멈춰야 하면 {status, error?} 를 돌려준다 */
  async function step(ctx, s) {
    const signal = ctx.abort.signal;
    if ('text' in s) {
      const item = { type: 'agentMessage', id: env.nextItemId('msg'), text: '', phase: null };
      started(ctx, item);
      for (const delta of chunks(s.text)) {
        wire.notify('item/agentMessage/delta', { ...scoped(ctx), itemId: item.id, delta });
        await sleep(s.everyMs ?? 0, signal);
        if (signal.aborted) return INTERRUPTED;
      }
      completed(ctx, { ...item, text: s.text });
    } else if ('reasoning' in s) {
      const item = { type: 'reasoning', id: env.nextItemId('rs'), summary: [], content: [] };
      started(ctx, item);
      wire.notify('item/reasoning/summaryTextDelta', { ...scoped(ctx), itemId: item.id, delta: s.reasoning, summaryIndex: 0 });
      completed(ctx, { ...item, summary: [s.reasoning] });
    } else if ('item' in s) {
      const item = { id: env.nextItemId('item'), ...s.item };
      started(ctx, item);
      completed(ctx, item);
    } else if ('command' in s) return command(ctx, s.command);
    else if ('fileChange' in s) return fileChange(ctx, s.fileChange);
    else if ('mcp' in s) return runMcpStep(env, { ctx, started, completed, ask }, s.mcp);
    else if ('userInput' in s) return userInput(ctx, s.userInput);
    else if ('sleepItems' in s) {
      // C12: 모델이 질문을 쓴 뒤 sleep 항목을 반복하며 기다린다
      for (let i = 0; i < s.sleepItems; i++) {
        const item = { type: 'sleep', id: env.nextItemId('call'), durationMs: s.ms ?? 0 };
        started(ctx, item);
        await sleep(s.ms ?? 0, signal);
        if (signal.aborted) return INTERRUPTED;
        completed(ctx, item);
      }
    } else if ('subThread' in s) return subThread(ctx, s.subThread);
    else if ('awaitSteer' in s) {
      if (ctx.steered > 0) ctx.steered--;
      else await untilAbort(signal, (wake) => ctx.steerWaiters.push(wake));
      if (signal.aborted) return INTERRUPTED;
    } else if ('hang' in s) {
      await untilAbort(signal);
      return INTERRUPTED;
    } else if ('error' in s) {
      const e = s.error;
      wire.notify('error', { error: { message: e.message, codexErrorInfo: e.codexErrorInfo ?? null, additionalDetails: null }, willRetry: e.willRetry ?? false, ...scoped(ctx) });
    } else if ('fail' in s) {
      const f = s.fail;
      return { status: 'failed', error: { message: f.message ?? 'fake failure', codexErrorInfo: f.codexErrorInfo ?? null, additionalDetails: f.additionalDetails ?? null } };
    } else if ('exit' in s) {
      env.exit(s.exit);
      await new Promise(() => {});
    } else if ('delayMs' in s) {
      await sleep(s.delayMs, signal);
    }
    return signal.aborted ? INTERRUPTED : undefined;
  }

  async function runSteps(ctx, steps) {
    for (const s of steps) {
      if (ctx.abort.signal.aborted) return INTERRUPTED;
      const end = await step(ctx, s);
      if (end) return end;
    }
    return ctx.abort.signal.aborted ? INTERRUPTED : undefined;
  }

  return { runSteps, started, completed };
}

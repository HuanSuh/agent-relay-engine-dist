// 시나리오 로드·검증·턴 고르기. 잘못 쓴 시나리오는 재생 도중이 아니라 시작할 때 실패시킨다.
import { readFileSync } from 'node:fs';

const isObj = (v) => typeof v === 'object' && v !== null && !Array.isArray(v);
const isMs = (v) => typeof v === 'number' && Number.isFinite(v) && v >= 0;

const BEHAVIOR = { initDelayMs: isMs, ignoreSigterm: (v) => typeof v === 'boolean', interruptIgnored: (v) => typeof v === 'boolean', exitOnStart: (v) => typeof v === 'boolean' || Number.isInteger(v), stderrOnStart: (v) => typeof v === 'string' };

/** 서버별 기동 결과. none 이면 기동 알림을 내지 않는다(엔진의 시한 경로 시험용) */
const MCP_STARTUP = ['ready', 'failed', 'cancelled', 'starting', 'none'];

/** step 이름 → 값 검사. 이 표에 없는 키의 step 은 오류다 */
const STEPS = {
  text: (v) => typeof v === 'string',
  reasoning: (v) => typeof v === 'string',
  item: (v) => isObj(v) && typeof v.type === 'string',
  command: (v) => isObj(v) && typeof v.command === 'string',
  fileChange: (v) => isObj(v) && (v.changes === undefined || Array.isArray(v.changes)),
  mcp: (v) => isObj(v) && typeof v.server === 'string' && typeof v.tool === 'string',
  userInput: (v) => isObj(v) && Array.isArray(v.questions) && v.questions.every(isObj),
  sleepItems: (v) => Number.isInteger(v) && v >= 0,
  subThread: (v) => isObj(v) && Array.isArray(v.steps),
  awaitSteer: () => true,
  hang: () => true,
  error: (v) => isObj(v) && typeof v.message === 'string',
  fail: (v) => isObj(v),
  exit: (v) => Number.isInteger(v),
  delayMs: isMs,
};

/** env 값은 파일 경로 또는 JSON 문자열이다 */
export function loadScenario(source) {
  if (!source) throw new Error('FAKE_CODEX_SCENARIO 가 비어 있다');
  let raw;
  try {
    raw = JSON.parse(source.trimStart().startsWith('{') ? source : readFileSync(source, 'utf8'));
  } catch (e) {
    throw new Error(`시나리오를 읽을 수 없다 (${source.slice(0, 120)}): ${e.message}`);
  }
  return validateScenario(raw);
}

export function validateScenario(s, where = 'scenario') {
  if (!isObj(s)) throw new Error(`${where} 는 객체여야 한다`);
  if (!Array.isArray(s.turns)) throw new Error(`${where}.turns 는 배열이어야 한다`);
  if (s.behavior !== undefined && !isObj(s.behavior)) throw new Error(`${where}.behavior 는 객체여야 한다`);
  for (const [k, v] of Object.entries(s.behavior ?? {})) {
    if (!(k in BEHAVIOR)) throw new Error(`${where}.behavior.${k} 는 모르는 스위치다`);
    if (!BEHAVIOR[k](v)) throw new Error(`${where}.behavior.${k} 값이 잘못됐다`);
  }
  if (s.account !== undefined && s.account !== null && !isObj(s.account)) throw new Error(`${where}.account 는 객체나 null 이어야 한다`);
  if (s.mcpStrictTools !== undefined && typeof s.mcpStrictTools !== 'boolean') throw new Error(`${where}.mcpStrictTools 는 boolean 이어야 한다`);
  if (s.threadSandbox !== undefined && (!isObj(s.threadSandbox) || typeof s.threadSandbox.type !== 'string')) throw new Error(`${where}.threadSandbox 는 type 이 있는 객체여야 한다`);
  if (s.forkSameThread !== undefined && typeof s.forkSameThread !== 'boolean') throw new Error(`${where}.forkSameThread 는 boolean 이어야 한다`);
  if (s.mcpStartup !== undefined) {
    if (!isObj(s.mcpStartup)) throw new Error(`${where}.mcpStartup 은 객체여야 한다`);
    for (const [k, v] of Object.entries(s.mcpStartup)) if (!MCP_STARTUP.includes(v)) throw new Error(`${where}.mcpStartup.${k} 는 ${MCP_STARTUP.join('|')} 중 하나다`);
  }
  s.turns.forEach((turn, i) => {
    const at = `${where}.turns[${i}]`;
    if (!isObj(turn) || !Array.isArray(turn.steps)) throw new Error(`${at}.steps 는 배열이어야 한다`);
    if (turn.match !== undefined) {
      if (typeof turn.match !== 'string') throw new Error(`${at}.match 는 정규식 문자열이어야 한다`);
      new RegExp(turn.match);
    }
    checkSteps(turn.steps, at);
  });
  return { ...s, behavior: { initDelayMs: 0, ignoreSigterm: false, interruptIgnored: false, exitOnStart: false, ...s.behavior } };
}

function checkSteps(steps, at) {
  steps.forEach((step, i) => {
    const here = `${at}.steps[${i}]`;
    if (!isObj(step)) throw new Error(`${here} 는 객체여야 한다`);
    const key = Object.keys(STEPS).find((k) => k in step);
    if (!key) throw new Error(`${here} 는 ${Object.keys(STEPS).join('|')} 중 하나여야 한다`);
    if (!STEPS[key](step[key])) throw new Error(`${here}.${key} 값이 잘못됐다`);
    if (key === 'sleepItems' && !isMs(step.ms ?? 0)) throw new Error(`${here}.ms 는 0 이상 숫자여야 한다`);
    if (key === 'subThread') {
      // turn/steer 는 부모 턴에만 닿는다 — 서브 스레드 안의 awaitSteer 는 풀리지 않는다
      if (step.subThread.steps.some((x) => isObj(x) && 'awaitSteer' in x)) throw new Error(`${here}.subThread 안에는 awaitSteer 를 둘 수 없다`);
      checkSteps(step.subThread.steps, `${here}.subThread`);
    }
  });
}

/** 기본 턴: 시나리오에 고를 턴이 없을 때 */
const DEFAULT_TURN = { steps: [{ text: 'ok' }] };

/**
 * 턴 고르기. match 가 입력 텍스트에 맞는 첫 턴을 쓰고, 없으면 match 없는 턴을 순서대로 쓴다.
 * 순서 턴을 다 쓰면 마지막 순서 턴을 반복한다. 고를 턴이 하나도 없으면 기본 턴이다.
 */
export function createTurnPicker(scenario) {
  const ordered = scenario.turns.filter((t) => t.match === undefined);
  const matched = scenario.turns.filter((t) => t.match !== undefined).map((t) => ({ turn: t, re: new RegExp(t.match) }));
  let next = 0;
  return (inputText) => {
    const hit = matched.find((m) => m.re.test(inputText));
    if (hit) return hit.turn;
    if (ordered.length === 0) return DEFAULT_TURN;
    return ordered[Math.min(next++, ordered.length - 1)];
  };
}

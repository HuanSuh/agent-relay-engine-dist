// 기동 인자 해석: `app-server`, `-c key=value`(TOML 값), `--disable <feature>`, `--enable <feature>`.
// 실제 codex 처럼 TOML 로 읽히지 않는 값은 문자열 그대로 쓴다.

/** @returns {{ subcommand: string|undefined, overrides: {key:string, value:unknown}[], config: object, disabled: string[], enabled: string[], rest: string[] }} */
export function parseArgs(argv) {
  const overrides = [];
  const disabled = [];
  const enabled = [];
  const rest = [];
  let subcommand;
  const takeValue = (i, flag) => {
    const a = argv[i];
    if (a.startsWith(`${flag}=`)) return [a.slice(flag.length + 1), i];
    if (i + 1 >= argv.length) throw new Error(`${flag} 뒤에 값이 없다`);
    return [argv[i + 1], i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-c' || a === '--config' || a.startsWith('--config=')) {
      const [kv, at] = takeValue(i, a === '-c' ? '-c' : '--config');
      i = at;
      const eq = kv.indexOf('=');
      if (eq <= 0) throw new Error(`-c 값은 key=value 여야 한다: ${kv}`);
      overrides.push({ key: kv.slice(0, eq).trim(), value: parseTomlValue(kv.slice(eq + 1).trim()) });
    } else if (a === '--disable' || a.startsWith('--disable=')) {
      const [v, at] = takeValue(i, '--disable');
      i = at;
      disabled.push(v);
    } else if (a === '--enable' || a.startsWith('--enable=')) {
      const [v, at] = takeValue(i, '--enable');
      i = at;
      enabled.push(v);
    } else if (subcommand === undefined && !a.startsWith('-')) {
      subcommand = a;
    } else {
      rest.push(a);
    }
  }
  const config = {};
  for (const { key, value } of overrides) setPath(config, splitKey(key), value);
  return { subcommand, overrides, config, disabled, enabled, rest };
}

/** config.mcp_servers 중 stdio 서버(command 가 있는 것)를 브리지 입력 모양으로 모은다 */
export function mcpServersFromConfig(config) {
  const out = {};
  for (const [name, spec] of Object.entries(config?.mcp_servers ?? {})) {
    // http 서버(url)는 프로세스가 없어 브리지 대상이 아니다
    if (typeof spec !== 'object' || spec === null || typeof spec.command !== 'string') continue;
    out[name] = {
      command: spec.command,
      args: Array.isArray(spec.args) ? spec.args.map(String) : [],
      env: typeof spec.env === 'object' && spec.env !== null ? spec.env : {},
      ...(Array.isArray(spec.env_vars) && { env_vars: spec.env_vars.map(String) }),
      cwd: spec.cwd,
      default_tools_approval_mode: spec.default_tools_approval_mode,
      enabled: spec.enabled !== false,
      disabled_tools: Array.isArray(spec.disabled_tools) ? spec.disabled_tools.map(String) : [],
      tools: typeof spec.tools === 'object' && spec.tools !== null ? spec.tools : {},
    };
  }
  return out;
}

/**
 * --strict-config(D-067)가 받는 -c 키. 실제 codex 의 전체 스키마가 아니라 엔진·테스트가 쓰는 키만 둔다.
 * 각 항목은 키 칸 배열의 정규식 묶음이다(`*` 는 아무 한 칸).
 */
const KNOWN_KEYS = [
  ['forced_login_method'],
  ['model'],
  ['model_reasoning_effort'],
  ['tools', 'web_search'],
  ['features', '*'],
  ['mcp_servers', '*', 'command'],
  ['mcp_servers', '*', 'args'],
  ['mcp_servers', '*', 'env'],
  ['mcp_servers', '*', 'env_vars'],
  ['mcp_servers', '*', 'cwd'],
  ['mcp_servers', '*', 'url'],
  ['mcp_servers', '*', 'http_headers'],
  ['mcp_servers', '*', 'env_http_headers'],
  ['shell_environment_policy', 'exclude'],
  ['shell_environment_policy', 'inherit'],
  ['sandbox_workspace_write', 'writable_roots'],
  ['sandbox_workspace_write', 'exclude_tmpdir_env_var'],
  ['sandbox_workspace_write', 'exclude_slash_tmp'],
  ['mcp_servers', '*', 'enabled'],
  ['mcp_servers', '*', 'enabled_tools'],
  ['mcp_servers', '*', 'disabled_tools'],
  ['mcp_servers', '*', 'default_tools_approval_mode'],
  ['mcp_servers', '*', 'tools', '*', 'approval_mode'],
];

/** 모르는 키(실제 codex 의 'unknown configuration field' 대상). 값이 인라인 테이블이면 그 안의 칸까지 본다 */
export function unknownConfigKeys(overrides) {
  const out = [];
  const known = (path) => KNOWN_KEYS.some((k) => k.length === path.length && k.every((p, i) => p === '*' || p === path[i]));
  const prefix = (path) => KNOWN_KEYS.some((k) => k.length > path.length && path.every((p, i) => k[i] === '*' || k[i] === p));
  const walk = (path, value) => {
    if (known(path)) return;
    if (typeof value === 'object' && value !== null && !Array.isArray(value) && prefix(path)) {
      for (const [k, v] of Object.entries(value)) walk([...path, k], v);
      return;
    }
    out.push(path.join('.'));
  };
  for (const { key, value } of overrides) walk(splitKey(key), value);
  return out;
}

/** `a.b."c.d"` → ['a','b','c.d'] */
function splitKey(key) {
  const parts = [];
  let cur = '';
  let quote = null;
  for (const ch of key) {
    if (quote) {
      if (ch === quote) quote = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'") quote = ch;
    else if (ch === '.') {
      parts.push(cur.trim());
      cur = '';
    } else cur += ch;
  }
  parts.push(cur.trim());
  return parts;
}

function setPath(obj, path, value) {
  let o = obj;
  for (const p of path.slice(0, -1)) {
    if (typeof o[p] !== 'object' || o[p] === null || Array.isArray(o[p])) o[p] = {};
    o = o[p];
  }
  o[path[path.length - 1]] = value;
}

/** 문자열·배열·인라인 테이블·숫자·불리언. 못 읽으면 원문 문자열 */
export function parseTomlValue(text) {
  try {
    const p = { s: text, i: 0 };
    const v = value(p);
    ws(p);
    if (p.i !== p.s.length) throw new Error('남은 글자');
    return v;
  } catch {
    return text;
  }
}

function ws(p) {
  while (p.i < p.s.length && /\s/.test(p.s[p.i])) p.i++;
}

function value(p) {
  ws(p);
  const ch = p.s[p.i];
  if (ch === '"') return basicString(p);
  if (ch === "'") return literalString(p);
  if (ch === '[') return array(p);
  if (ch === '{') return table(p);
  const m = /^(true|false|[+-]?\d[\d_]*(\.\d+)?([eE][+-]?\d+)?)/.exec(p.s.slice(p.i));
  if (!m) throw new Error('값이 아니다');
  p.i += m[0].length;
  if (m[0] === 'true') return true;
  if (m[0] === 'false') return false;
  return Number(m[0].replace(/_/g, ''));
}

function basicString(p) {
  p.i++;
  let out = '';
  const esc = { n: '\n', t: '\t', r: '\r', '"': '"', '\\': '\\', b: '\b', f: '\f' };
  while (p.i < p.s.length) {
    const ch = p.s[p.i++];
    if (ch === '"') return out;
    if (ch !== '\\') {
      out += ch;
      continue;
    }
    const e = p.s[p.i++];
    if (e === 'u') {
      out += String.fromCharCode(parseInt(p.s.slice(p.i, p.i + 4), 16));
      p.i += 4;
    } else if (e in esc) out += esc[e];
    else throw new Error('모르는 escape');
  }
  throw new Error('닫히지 않은 문자열');
}

function literalString(p) {
  const end = p.s.indexOf("'", p.i + 1);
  if (end < 0) throw new Error('닫히지 않은 문자열');
  const out = p.s.slice(p.i + 1, end);
  p.i = end + 1;
  return out;
}

function array(p) {
  p.i++;
  const out = [];
  for (;;) {
    ws(p);
    if (p.s[p.i] === ']') {
      p.i++;
      return out;
    }
    out.push(value(p));
    ws(p);
    if (p.s[p.i] === ',') p.i++;
    else if (p.s[p.i] !== ']') throw new Error('배열 구분자');
  }
}

function table(p) {
  p.i++;
  const out = {};
  for (;;) {
    ws(p);
    if (p.s[p.i] === '}') {
      p.i++;
      return out;
    }
    const key = tableKey(p);
    ws(p);
    if (p.s[p.i++] !== '=') throw new Error('= 가 없다');
    setPath(out, key, value(p));
    ws(p);
    if (p.s[p.i] === ',') p.i++;
    else if (p.s[p.i] !== '}') throw new Error('테이블 구분자');
  }
}

function tableKey(p) {
  const parts = [];
  for (;;) {
    ws(p);
    const ch = p.s[p.i];
    if (ch === '"') parts.push(basicString(p));
    else if (ch === "'") parts.push(literalString(p));
    else {
      const m = /^[A-Za-z0-9_-]+/.exec(p.s.slice(p.i));
      if (!m) throw new Error('키가 아니다');
      parts.push(m[0]);
      p.i += m[0].length;
    }
    ws(p);
    if (p.s[p.i] !== '.') return parts;
    p.i++;
  }
}

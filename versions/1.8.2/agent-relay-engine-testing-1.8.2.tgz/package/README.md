# @agent-relay-engine/testing

실제 CLI 없이 엔진을 돌리고 검증하는 도구를 담는다: 가짜 Claude CLI, 가짜 Codex app-server, 내장 시나리오, 가짜 백엔드 설명자, 계약 스위트, 메모리 엔진, 엔진 하네스.

| 진입점 | 내용 | vitest | 쓰는 곳 |
|---|---|---|---|
| `@agent-relay-engine/testing` | 계약 스위트·하네스·메모리 엔진 | 끌어온다 | 테스트 파일 |
| `@agent-relay-engine/testing/claude` | 가짜 Claude CLI `fakeClaudeSpawn`, 시나리오 타입 | 없음 | 테스트·예제의 `--fake` |
| `@agent-relay-engine/testing/codex` | 가짜 Codex app-server `fakeCodexSpawn`, 시나리오 타입, 가짜 홈 폴더 `codexTestDir` | 없음 | 테스트·예제의 `--backend codex --fake` |
| `@agent-relay-engine/testing/fake` | 백엔드 중립 가짜 `fakeBackends`·`recordFakeAsk`(최상위에도 있다) | 없음 | 예제·개발 서버의 `--fake` |

## 가장 짧은 예제

```ts check
import { createSideChannel, MemorySideStore } from '@agent-relay-engine/core';
import { createClaudeEngine } from '@agent-relay-engine/claude';
import { fakeClaudeSpawn } from '@agent-relay-engine/testing/claude';

const side = createSideChannel(new MemorySideStore(), 'test');
const engine = createClaudeEngine({ cwd: process.cwd(), namespace: 'test' }, { side, spawn: fakeClaudeSpawn('tool-roundtrip') });

const kinds: string[] = [];
for await (const ev of engine.turn('s1', '안녕')) kinds.push(ev.type);
console.log(kinds);   // started … tool-start tool … text … done
await engine.dispose();
```

## 가짜 Claude CLI

`fakeClaudeSpawn(scenario: FakeScenarioInput, opts?: FakeSpawnOptions): SpawnFn` 는 `EngineDeps.spawn` 에 넣는다. 명령이 무엇이든 가짜 CLI(`FAKE_CLAUDE_MAIN`)를 띄우고 엔진이 조립한 인자를 그대로 받는다. 시나리오는 내장 이름, 파일 경로, 객체 중 하나다. 없는 이름은 호출 자리에서 던진다.

### 세션별 시나리오

`scenario` 에 함수를 주면 spawn 마다 불러 시나리오를 고른다. 가짜 CLI 는 프로세스마다 시나리오를 처음부터 재생하므로, 다중 세션은 세션 id 로, 재시작 뒤 이어 받는 경우는 `resume` 으로 가른다.

```ts check
import { claudeCliSessionId } from '@agent-relay-engine/claude';
import { fakeClaudeSpawn } from '@agent-relay-engine/testing/claude';

export const spawn = fakeClaudeSpawn(({ sessionId, resume }) => {
  if (resume) return 'basic-text';
  return sessionId === claudeCliSessionId('writer') ? 'partial-slow' : 'tool-roundtrip';
});
```

`sessionId` 는 CLI 인자의 세션 id 다. 엔진 sessionId 가 UUID 가 아니면 `claudeCliSessionId(id)` 로 바뀐 UUID 라 그 값과 비교한다. 같은 규칙의 파서는 `claudeScenarioContext(args)` 다.

### 실제 MCP 서버 실행 — `mcp: 'spawn'`

기본 가짜 CLI 는 MCP 서버를 띄우지 않고 시나리오의 `tool_result` 를 재생한다. `fakeClaudeSpawn(scenario, { mcp: 'spawn' })` 이면:

1. `--mcp-config` 의 stdio 서버를 실제로 띄우고 `initialize`·`tools/list` 를 한다. 띄우지 못하거나 `FAKE_CLAUDE_MCP_TIMEOUT_MS`(15초) 안에 답하지 않는 서버와 http 서버는 `failed` 다.
2. 시나리오의 `tool_use` 가 연결된 서버의 도구면 `tools/call` 로 실행하고 결과를 `tool_result` 로 낸다. 같은 id 의 시나리오 `tool_result` 는 버리므로 한 시나리오를 두 모드에서 쓸 수 있다. `FAKE_CLAUDE_MCP_CALL_TIMEOUT_MS`(30초) 안에 답이 없으면 오류 결과다.
3. 가짜 CLI 가 끝나면 띄운 서버를 내린다. 서버 stderr 는 `fake-claude mcp[<name>]:` 접두로 나온다.

ask 서버를 실제로 띄우면 질문 기록을 서버가 남기므로 `recordFakeAsk` 가 필요 없다. 사이드 저장소는 서버 프로세스와 공유할 수 있어야 한다(`FsSideStore`). 이 모드는 CLI 의 권한 판단을 흉내 내지 않는다 — 필요하면 `controlRequest` 단계를 둔다.

### 목록 밖 도구 막기 — `mcpStrictTools`

`mcp: 'spawn'` 에서 기동 때 받은 `tools/list` 에 없는 `mcp__<서버>__<도구>` 는 기본(끔)이면 그대로 서버에 보낸다. 켜면 서버에 보내지 않고 실측 모양의 오류로 답한다.

| 두는 곳 | 기본 | 뜻 |
|---|---|---|
| 시나리오 최상위 `mcpStrictTools` | `false` | 이 시나리오를 재생하면 켠다(Claude·Codex 공통 칸) |
| `fakeClaudeSpawn(…, opts)` 의 `mcpStrictTools`, `startFakeClaude` 옵션 | `false` | 가짜 CLI 옵션. 시나리오 칸과 OR 로 켜진다 |
| `fakeCodexSpawn(…, opts)` 의 `mcpStrictTools` | `false` | Codex 가짜 app-server 옵션. 시나리오 칸과 OR 로 켜진다 |

켜면 Claude 모양은 실측이다(Claude Code 2.1.322). 모델이 목록에 없는 도구를 부르면 `tool_result` 는 `is_error: true` 이고, `content` 는 배열이 아니라 문자열 `<tool_use_error>Error: No such tool available: mcp__<서버>__<도구></tool_use_error>` 다. 서버는 그 호출을 받지 않는다(수신 0건). 턴은 이어져서, 모델은 도구가 없다고 답하고 정상 종료한다.

Codex 모양은 **실측 전**이다. 같은 문구를 `mcpToolCall` 실패 item 의 `error.message` 로 낸 추정이며, 실제 app-server 가 같은 모양을 내는지는 확인하지 않았다.

### 도구 인자 바꾸기 — `transformToolArgs`

도구 인자에 그 턴에만 생기는 값(작업 id 등)을 채워야 할 때 쓴다. 시나리오는 고정이라 채울 수 없기 때문이다.

| 옵션 | 기본 | 뜻 |
|---|---|---|
| `transformToolArgs(name, args, ctx)` (`fakeClaudeSpawn`·`fakeCodexSpawn`·`startFakeClaude`) | 없음 | tool_use 를 내기 직전에 **테스트 프로세스**에서 부른다. `name` 은 tool_use 의 전체 이름(`mcp__s__t`)이고, 돌려준 객체가 tool_use 의 `input` 과 서버 호출 인자가 된다. 비동기 가능. 이름으로 골라 바꾸며 MCP 가 아닌 도구에도 쓴다 |

`ctx` 는 `{ sessionId?, turn, inputText, toolUseId }` 다. `inputText` 는 그 턴의 사람 입력 글이다. `sessionId` 는 두 백엔드 모두 엔진 세션 쪽 값이며, Codex 의 서브 스레드 안 호출도 부모 세션 값을 싣는다. `turn` 의 뜻은 백엔드마다 다르다(값을 맞추지 않았다): Claude 는 프로세스마다 시나리오를 재생하는 순번(1부터, 재사용 프로세스가 입력을 받을 때마다 하나씩 늘어난다)이고, Codex 는 스레드 안에서 누적되는 턴 번호(1부터, 끝난 턴 수 + 1)다. 훅이 던지거나 객체가 아닌 값을 돌려주면 그 호출은 서버에 가지 않고 `is_error` 결과(메시지에 `transformToolArgs 훅 오류` 를 담는다)가 나오며, 턴은 이어진다. `mcpStrictTools` 판정은 바뀌기 전 이름으로 한다. Codex 는 `mcp` 단계(`mcpToolCall`)에 같은 규칙을 쓴다.

훅은 30초 안에 답해야 한다. 넘으면(`FAKE_CLAUDE_TOOL_ARGS_TIMEOUT_MS`·`FAKE_CODEX_TOOL_ARGS_TIMEOUT_MS` 로 바꾼다. 양수가 아닌 값은 30초다. 훅을 주지 않은 `fakeSpawn` 은 물려받은 이 값을 빈 값으로 덮는다) 그 호출은 `is_error` 가 된다. 답을 기다리는 동안 턴이 중단(interrupt)되면 훅 호출은 바로 끊기고 턴은 중단으로 끝난다. 결과를 JSON 으로 만들 수 없으면(BigInt·순환 참조) 역시 `is_error` 다. 훅을 준 `fakeSpawn` 은 처음 spawn 할 때 로컬 소켓을 열고, `close()` 로 닫는다(소켓 파일도 지운다). 닫은 뒤 다시 spawn 하면 새 소켓을 연다. 훅이 없으면 소켓을 열지 않는다.

```ts check
import { fakeClaudeSpawn } from '@agent-relay-engine/testing/claude';

// 테스트 중 만든 작업 id 를 jobs__start 의 인자에 넣는다. 다른 도구는 그대로 둔다
export const spawn = fakeClaudeSpawn('tool-roundtrip', {
  mcp: 'spawn',
  transformToolArgs: async (name, args, ctx) => (name === 'mcp__jobs__start' ? { ...args, jobId: `job-${ctx.turn}` } : args),
});
```

테스트가 끝나면 `await spawn.close()` 를 부른다. `startFakeClaude` 의 `kill()` 도 훅 소켓을 닫는다.

### 턴마다 init — `initEachTurn`

가짜 Claude CLI 는 사용자 메시지마다 `init` 을 낸다(기본 `true`, 실측 모양: init 은 턴마다 온다). 옛 동작(init 은 기동 때 한 번)은 `fakeClaudeSpawn(…, { initEachTurn: false })` 로 되돌린다. env `FAKE_CLAUDE_INIT_EACH_TURN` 도 같은 뜻이며 `0` 이면 끈다. `init` 개수를 세는 기대값은 턴 수만큼 나온다.

### init 의 MCP 서버 상태 — `mcpStatus`

가짜 Claude CLI 는 실제 CLI 처럼 `--mcp-config` 로 넘긴 서버를 모두 init `mcp_servers` 에 싣는다. `mcp: 'spawn'` 이면 실제로 띄운 상태이고, 띄우지 않는 `mcp: 'off'` 면 `connected` 다. 시나리오의 `mcp__<서버>__<도구>` 이름에만 나온 서버도 `connected` 로 뒤에 붙는다. 그래서 `claude.mcpServersCheck` 는 `'strict'` 여도 기본 그대로 통과한다. 연결 실패를 흉내 내려면 `mcpStatus` 로 상태를 바꾼다.

연결된 서버의 도구는 init `tools` 에도 실린다. `mcp: 'spawn'` 은 서버가 내놓은 실제 목록이고, `mcp: 'off'` 는 시나리오의 `tool_use` 에 나온 그 서버 도구다. 시나리오에 그 서버 도구가 없으면 대표 도구 하나(`mcp__<서버>__fake_tool`)를 싣는다. 가짜 CLI 는 엔진 전용 칸인 `McpServerSpec.tools` 를 받지 못하므로(`--mcp-config` 에 실리지 않는다) 그 이름은 쓰지 않는다.

| 두는 곳 | 뜻 |
|---|---|
| `fakeClaudeSpawn(…, opts)` 의 `mcpStatus`, `startFakeClaude` 옵션 | 이 가짜 CLI 가 띄우는 모든 프로세스에 쓴다. env `FAKE_CLAUDE_MCP_STATUS`(JSON)와 같다 |
| 시나리오 최상위 `mcpStatus` | 이 시나리오를 재생하는 프로세스에 쓴다. 옵션보다 우선한다. 프로세스마다 다른 상태는 시나리오 선택 함수로 고른다(예: `ctx.resume` 이면 연결된 시나리오) |

값은 한 벌 또는 그 배열이다(`FakeMcpStatus`).

- `{이름: 상태}`: 기본 목록에 있는 이름은 상태를 바꾸고, 없는 이름은 뒤에 덧붙인다. 상태는 문자열 그대로 나간다(`'connected'`·`'failed'`·`'needs-auth'` 등). `null` 이면 그 이름을 목록에서 뺀다.
- 상태 `'no-tools'`: `tools/list` 가 실패한 서버 흉내다. `mcp_servers` 에는 `connected` 로 싣고 init `tools` 에서 그 서버 도구를 뺀다(`mcpServersCheck` 가 `status:'no-tools'` 로 본다). `connected` 가 아닌 상태와 `null` 도 그 서버 도구를 init `tools` 에서 뺀다.
- `'omit'`: init 에 `mcp_servers` 칸을 싣지 않는다(칸이 없는 CLI 흉내).
- 배열: N번째(1부터) 사용자 메시지의 init 에 N번째 벌을 쓴다. 모자라면 마지막 벌을 쓴다. 턴마다 상태가 바뀌는 재사용 프로세스를 흉내 낸다.

```ts
// 첫 프로세스는 tools 가 failed, 다시 띄운(--resume) 프로세스는 connected
const spawn = fakeClaudeSpawn((ctx) => ({ turns, mcpStatus: { tools: ctx.resume ? 'connected' : 'failed' } }));
```

주지 않으면 init 은 기본 목록 그대로다.

### 시스템 프롬프트

가짜 CLI 는 실제 CLI 처럼 `--append-system-prompt-file <경로>`(엔진 기본, 1.8.0) 또는 인라인 `--append-system-prompt <글>` 을 기동 때 한 번 읽고, 읽은 글을 init 의 `fake_system_prompt` 칸으로 알린다(파서는 `init.raw` 에 둔다). 그 뒤 파일을 지워도 그 글을 쓴다. 파일을 읽지 못하면 stderr 에 이유를 남기고 exit 1 로 끝난다.

### 시나리오 형식(`FakeCliScenario`)

```json
{
  "description": "사람이 읽는 설명",
  "behavior": { "controlInterrupt": "honor" },
  "turns": [
    { "steps": [
      { "emit": { "type": "text", "text": "작업 중" } },
      { "hangMs": 10000 },
      { "emit": { "type": "text", "text": "받음: {{input}}" }, "afterMs": 50 }
    ] }
  ]
}
```

입력 줄을 받을 때마다 `turns` 를 하나씩 소비한다. 턴에 `result` 가 없으면 기본 결과를 붙이고, `text` 의 `{{input}}` 은 그 턴 입력으로 바꾼다.

| step | 뜻 |
|---|---|
| `{emit, afterMs?}` | stdout 한 줄. 짧은 표기는 실제 CLI 줄로 편다. 그 밖의 `type` 은 원문 그대로 |
| `{hangMs}` | 무응답 |
| `{partialChunks, everyMs}` | `text_delta` 조각 흘리기 |
| `{exit: {code?, signal?}}` | 결과 없이 프로세스 종료 |
| `{expectControl: 'interrupt', then}` | control interrupt 가 올 때까지 기다렸다가 `then` 실행 |
| `{controlRequest: 'can_use_tool', tool, input?, toolUseId?, then: {allow, deny}, wait?}` | 승인 요청을 내고 답을 기다린다. allow 면 `then.allow`, 그 밖이면 `then.deny`. `wait:false` 면 기다리지 않는다 |

가짜 CLI 는 `permissions.approval` 과 무관하게 `controlRequest` 를 낸다(실제 CLI 는 `{kind:'control'}` 일 때만 묻는다).

`emit` 짧은 표기: `text{text}`, `thinking{text}`, `tool_use{id, name, input}`, `tool_result{tool_use_id, content, is_error?}`, `delta{text}`, `rate_limit{info}`, `result{…}`. `parent` 를 주면 서브에이전트 이벤트가 된다.

### behavior 스위치

CLI 비공개 동작의 변형을 고른다. 모르는 스위치나 잘못된 값은 시작할 때 오류다.

| 스위치 | 기본 | 쓰임 |
|---|---|---|
| `initTiming` | `after-first-input` | `before-first-input` = 입력 전에 init |
| `apiKeySource` | `none` | `ANTHROPIC_API_KEY`·`apiKeyHelper` — 구독 전용 정책 거부 검증 |
| `controlInterrupt` | `honor` | `ignore` = 무응답(신호 fallback 검증) |
| `injectHandling` | `queue` | `inject` = 턴 중 입력을 현재 턴에 흡수 |
| `replayUserMessages` | `false` | 받은 입력을 replay 로 되돌린다(`accepted` 근거) |
| `replayWithoutUuid` | `false` | replay 에 uuid 칸이 없다(옛 CLI) — 내용 대조 경로 검증 |
| `replayNewUuid` | `false` | replay 에 다른 uuid — 내용으로 대조하지 않음 검증 |
| `resultUuids` | `true` | 결과에 처리한 입력 목록·밀린 입력 수를 싣는다 |
| `lateInjectReplay` | `false` | 흡수한 입력의 replay 를 결과 뒤에 낸다 |
| `initCapabilities` | `false` | init 에 interrupt 기능 목록을 싣는다 |
| `ignoreSigterm` | `false` | SIGTERM 무시 — SIGKILL fallback 검증 |
| `spawnChild` | `false` | 자식 프로세스를 띄운다 — 그룹 종료 검증 |
| `setModel` | `honor` | control `set_model` 응답. `honor` = 바꾸고 `response.model` 로 답한다, `reject` = 오류(실측 모양 `error_code:'not_found'`, 지금 `model`), `ignore` = 무응답(재시작 경로 검증). 모델 이름은 `--model` 값(없으면 `claude-fake-1`)을 init·assistant 에 싣는다 |

### 내장 시나리오

`src/scenarios/`: `basic-text` · `partial-slow` · `tool-roundtrip` · `subagent-events` · `ask-and-answer` · `ask-bundle` · `ask-then-long-output` · `inject-honored` · `inject-queued` · `inject-late-replay` · `interrupt-honored` · `interrupt-ignored` · `hang` · `stubborn-hang` · `exit-143` · `init-before-input` · `api-key-set` · `permission-denied` · `permission-allow` · `permission-deny` · `permission-timeout` · `permission-abandon` · `tool-scope-read-only` · `rate-limit` · `big-usage`. 각 파일의 `description` 이 쓰임을 적는다. 경로는 `claudeScenarioPath(name)`.

### 내장 도구와 `basic-text` 의 기본 동작

- `fakeClaudeSpawn(…, {builtinTools})` 의 기본은 `'honor'` 다. 엔진이 `--tools ''`(`claude.builtinTools:'none'`)를 주면 init.tools 에 내장 도구 이름이 없다(실제 CLI 와 같다). `'ignore'` 는 인자를 무시하고 내장 도구를 남긴다 — 'none' 을 어긴 CLI 를 흉내 내 보장 검사를 실패시킬 때 명시한다.
- `--tools a,b` 를 주면 그 내장 이름만 남긴다. 실측(2.1.325)처럼 `Agent` 를 주면 `Task` 로 보이고, 가짜 CLI 목록에 없는 이름은 실패 없이 빠진다. `{extraBuiltins: ['CronCreate', …]}` 는 기본 목록에 내장 이름을 더한다 — 실제 CLI 기본 목록의 확인 밖 도구를 흉내 내 read-only 턴의 `unverified-tools` 를 시험한다. 엔진이 `--tools` 로 띄우면 빠진다.
- 시나리오 최상위 `repeatLastTurn:true` 는 입력이 턴 수보다 많아도 마지막 턴을 되풀이한다. 내장 `basic-text` 가 켜 두어 같은 프로세스의 둘째 턴 이후에도 답한다. 직접 준 시나리오(이름·경로·객체)는 기본 `false` 라 턴이 모자라면 지금처럼 `error_during_execution`("남은 시나리오 턴이 없다")이다. 다른 내장 시나리오는 턴마다 이야기가 다르거나 끝을 시험하는 것이라 반복하지 않는다.
- 가짜 CLI 는 `--mcp-config` 에 JSON 문자열과 파일 경로를 둘 다 받는다(엔진은 경로를 준다). 파일은 프로세스가 끝나면 지워지므로 테스트가 내용을 보려면 spawn 때 읽어 둔다.

## 가짜 Codex app-server

`fakeCodexSpawn(scenario, opts?)` 는 같은 방식으로 가짜 app-server(`FAKE_CODEX_MAIN`)를 띄운다. 내장 시나리오는 `src/scenarios-codex/`: `basic-text` · `command-approval` · `mcp-tool` · `steer` · `interrupt` · `resume` · `subagent` · `ask-sleep` · `rate-limit-error`. 경로는 `codexScenarioPath(name)`. 엔진은 시작할 때 로그인 파일을 보므로, 가짜 모드에서는 임시 폴더에 가짜 `auth.json` 을 만들어 `codex.authSource` 로 준다(`fakeBackends` 는 이것을 스스로 한다).

## `recordFakeAsk`

기본 가짜 CLI 는 ask 서버를 띄우지 않아 서버가 남겼을 질문 기록이 없다. 그러면 답 턴이 `ask-mismatch` 가 되므로, 가짜 모드에서는 `ask` 이벤트를 받은 자리에서 같은 키·모양의 기록을 남긴다.

```ts check
import type { Engine, SideChannel } from '@agent-relay-engine/core';
import { recordFakeAsk } from '@agent-relay-engine/testing/fake';

export async function turnWithFakeAsk(engine: Engine, side: SideChannel, sid: string) {
  for await (const ev of engine.turn(sid, '안녕')) {
    if (ev.type === 'ask') await recordFakeAsk(side, sid, ev, { ttlMs: 60 * 60_000 });
  }
}
```

## 가짜 백엔드 설명자 — `fakeBackends`

`createRelayEngine`·`detectBackends` 를 실제 CLI 없이 돌린다. 엔진은 실제 백엔드 엔진에 가짜 CLI 를 붙이고, 점검은 결과를 흉내 낸다(기본 `available`·`protocol:'ok'`·구독 로그인).

```ts check
import { createRelayEngine, createSideChannel, MemorySideStore } from '@agent-relay-engine/core';
import { claudeBackend } from '@agent-relay-engine/claude';
import { codexBackend } from '@agent-relay-engine/codex';
import { fakeBackends } from '@agent-relay-engine/testing/fake';

const backends = fakeBackends({ claude: 'basic-text', codex: 'basic-text', unavailable: ['codex'], base: [claudeBackend, codexBackend] });
const side = createSideChannel(new MemorySideStore(), 'test');
export const engine = createRelayEngine({ cwd: process.cwd(), namespace: 'test', prefer: ['codex', 'claude'] }, { side, backends });
// 첫 턴: ext{core.backend, {chosen:'claude', skipped:[{backend:'codex', reason:'not-installed'}]}}
```

- 시나리오를 준 백엔드만, 준 순서대로 설명자를 만든다. 이름·`expected` 는 실제 설명자 그대로다.
- `base`(감쌀 실제 설명자)는 필수다. 중립 모듈이라 특정 백엔드를 기본으로 고르지 않는다. 시나리오를 준 백엔드가 `base` 에 없으면 던진다.
- `unavailable` 은 `not-installed` 로 답한다. `status: {codex: {available:false, reason:'not-logged-in'}}`(또는 이름을 받는 함수)로 점검 결과를 덮는다. `onDetect(name)` 으로 점검 횟수를 센다.
- 점검 캐시는 설명자 객체별이다. 같은 설명자로 엔진을 여러 번 만들면 `detectCacheMs: 0` 으로 끈다.

## 계약 스위트

### Engine — `engineContractSuite(make, caps)`

새 Engine 구현은 이 스위트를 통과해야 한다. 가짜 CLI 는 입력으로 분기할 수 없어 `make(need)` 가 응답 모양(`'text' | 'tools' | 'ask' | 'hang'`)을 받는다.

```ts check
import { createSideChannel, MemorySideStore } from '@agent-relay-engine/core';
import { createStubEngine, engineContractSuite } from '@agent-relay-engine/testing';

engineContractSuite(async (need) => {
  // need: 'text' | 'tools' | 'ask' | 'hang' — 구현이 그 모양의 응답을 고른다
  const factory = createStubEngine(need === 'tools' ? { tools: [{ name: 'Read', args: { path: 'a.txt' } }] } : { text: '받음: {{input}}' });
  const engine = factory({ cwd: process.cwd(), namespace: 'test' }, { side: createSideChannel(new MemorySideStore(), 'test') });
  return { engine, teardown: () => engine.dispose() };
}, { tools: true });   // 지원하지 않는 항목(hang·ask·askCut·permission)은 빼면 건너뛴다
```

- 단언은 모든 구현이 지킬 것만이다: `started` 가 첫 이벤트, Envelope·turnId 일관, `done` 하나로 끝, delta 뒤 text, tool-start↔tool 짝, 두 번째 턴 `resumed`, lease 충돌은 `started` 없는 `error(busy)`, gate 대기 중 stop → `'pending'`, dispose 뒤 거부, 모르는 ext 허용, ask 뒤 `done(ask)`, 모든 `error.reason` 이 선언된 값인지, `core.*` payload 모양(`checkCoreExt`).
- `askCut` 은 `done(ask)` 자리에서 턴을 끝내는 구현에 켠다. 켜면 `done(ask)` 뒤 500ms 안에 busy 가 풀리길 요구한다.
- 스트림 하나만 검사하려면 `checkTurn(events, sessionId)`, 기대 기능은 `checkExpectedCapabilities(started, expected, measured?)`.

### SideStore·SideChannel

```ts check
import { MemorySideStore } from '@agent-relay-engine/core';
import { sideChannelContractSuite, sideStoreContractSuite } from '@agent-relay-engine/testing';

sideStoreContractSuite(() => new MemorySideStore());     // get/put/delete, ifAbsent 경합, consume 원자성, ttl, watch
sideChannelContractSuite(() => new MemorySideStore());   // 승인 record/consume/clear, secrets, lease, artifacts
```

## 메모리 엔진

프로세스 없이 계약을 지키는 엔진이다. UI·서버 테스트에서 가짜 CLI 보다 빠르다. 큐를 흉내 내지 않아 동시 턴은 `error(busy)` 다.

- `createStubEngine({ text?, deltaSize?, tools?, ask? })` 는 `EngineFactory` 를 돌려준다 — 고정 응답(`{{input}}` 치환), 앞에 도구 호출, 뒤에 질문.
- `createScriptedEngine(script(...))` — 턴마다 낼 이벤트를 `Script` 로 적는다. 생략한 `started.backend`(`'memory'`)·`kind`·`questions` 는 엔진이 채운다.

## 하네스

`makeEngine(scenario, configOverrides?, side?, deps?, fake?)` 는 가짜 Claude CLI·메모리 사이드 저장소로 실제 엔진을 만든다. `{ engine, side, spawns, close }` 를 돌려주며, `close()` 는 `fake.transformToolArgs` 훅 소켓을 닫는다(엔진은 따로 `dispose()`). `collect`·`kinds`·`find`·`exts`·`waitFor`·`seedAsk`(질문 기록 심기)·`echoTurns` 는 엔진 테스트용 도우미다.

## 공개 API

<!-- gen:api @agent-relay-engine/testing . -->
`@agent-relay-engine/testing` — 40개, 공개 API 스냅샷 1.8.2 기준.

| 종류 | 이름 |
|---|---|
| function | `all` · `checkCoreExt` · `checkExpectedCapabilities` · `checkTurn` · `collect` · `coreExtProblem` · `engineContractSuite` · `fakeBackends` · `find` · `makeEngine` · `recordedMcpConfig` · `recordFakeAsk` · `seedAsk` · `sideChannelContractSuite` · `sideStoreContractSuite` · `track` · `waitFor` |
| class | `MemoryEngine` · `Script` · `ScriptedEngine` · `StubEngine` |
| const | `createScriptedEngine` · `createStubEngine` · `echoTurns` · `exts` · `inputText` · `kinds` · `script` |
| type | `EngineContractCaps` · `EngineNeed` · `FakeBackendsOptions` · `FakeBackendStatus` · `MadeEngine` · `ScriptEvent` · `ScriptFn` · `ScriptItem` · `Spawned` · `StubOptions` · `StubTool` · `TurnContext` |
<!-- /gen -->

<!-- gen:api @agent-relay-engine/testing ./claude -->
`@agent-relay-engine/testing/claude` — 19개, 공개 API 스냅샷 1.8.2 기준.

| 종류 | 이름 |
|---|---|
| function | `claudeScenarioContext` · `claudeScenarioPath` · `fakeClaudeSpawn` · `startFakeClaude` |
| const | `countKind` · `FAKE_CLAUDE_MAIN` · `hasKind` |
| type | `FakeCliScenario` · `FakeMcpStatus` · `FakeRun` · `FakeScenarioContext` · `FakeScenarioInput` · `FakeScenarioSource` · `FakeSpawn` · `FakeSpawnOptions` · `FakeStep` · `FakeToolArgsContext` · `FakeToolArgsHook` · `FakeTurn` |
<!-- /gen -->

<!-- gen:api @agent-relay-engine/testing ./codex -->
`@agent-relay-engine/testing/codex` — 18개, 공개 API 스냅샷 1.8.2 기준.

| 종류 | 이름 |
|---|---|
| function | `codexScenarioPath` · `codexTestDir` · `fakeCodexSpawn` · `removeCodexTestDir` · `removeCodexTestDirs` |
| const | `CODEX_TEST_DIR` · `codexTestRoot` · `FAKE_CODEX_MAIN` |
| type | `FakeCodexContext` · `FakeCodexInput` · `FakeCodexScenario` · `FakeCodexSource` · `FakeCodexSpawn` · `FakeCodexSpawnOptions` · `FakeCodexStep` · `FakeCodexTurn` · `FakeToolArgsContext` · `FakeToolArgsHook` |
<!-- /gen -->

<!-- gen:api @agent-relay-engine/testing ./fake -->
`@agent-relay-engine/testing/fake` — 4개, 공개 API 스냅샷 1.8.2 기준.

| 종류 | 이름 |
|---|---|
| function | `fakeBackends` · `recordFakeAsk` |
| type | `FakeBackendsOptions` · `FakeBackendStatus` |
<!-- /gen -->

## 설정

| 의존 | 범위 |
|---|---|
| `vitest`(peer) | `^5.0.4`. 최상위 진입점만 쓴다 |
| `@agent-relay-engine/core`·`@agent-relay-engine/claude` | 같은 버전 |

실제 CLI 스위트는 이 패키지가 아니라 저장소의 비공개 워크스페이스 `packages/real-tests` 에 있다(`npm run test:real`, [구조 문서](../../docs/ARCHITECTURE.md#테스트-구조)).

## 다른 문서

- [구조 문서](../../docs/ARCHITECTURE.md#새-백엔드-붙이기) — 새 백엔드에 계약 스위트 붙이기
- [core README](../core/README.md) · [ask README](../ask/README.md#가짜-cli-에서)

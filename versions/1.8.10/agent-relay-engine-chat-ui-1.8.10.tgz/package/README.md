# @agent-relay-engine/chat-ui

웹 컴포넌트 `<agent-relay-engine-chat>`. [`@agent-relay-engine/chat-client`](../chat-client/README.md) 스토어를 구독해 그린다 — 세션 목록, 말풍선·스트리밍, 도구 카드(접기, 승인 경로 배지), ask 카드, 승인 카드(허용/거부/항상 허용 + 접두 편집), 거부 목록, 상태줄·큐·capabilities·사용률. Shadow DOM 이라 페이지 CSS 와 섞이지 않는다. 의존성은 chat-client 뿐이다.

## 가장 짧은 예제

```ts check
import '@agent-relay-engine/chat-ui';
import { TAG, type AgentRelayEngineChat } from '@agent-relay-engine/chat-ui';

const chat = document.createElement(TAG) as AgentRelayEngineChat;
chat.setAttribute('endpoint', '/api');
chat.setAttribute('sync-hash', '');
document.body.append(chat);
chat.addEventListener('ce-permission', (e) => console.log((e as CustomEvent).detail));
```

번들러가 있으면 위처럼 `import '@agent-relay-engine/chat-ui'` 한 줄로 요소가 등록된다. 번들러 없이 브라우저에 바로 쓰면 두 패키지의 `dist/` 를 서빙하고 import map 으로 이어 준다:

```html
<script type="importmap">{ "imports": { "@agent-relay-engine/chat-client": "/vendor/chat-client/index.js" } }</script>
<script type="module" src="/vendor/chat-ui/index.js"></script>

<agent-relay-engine-chat endpoint="/api" sync-hash>
  <strong slot="header">내 채팅</strong>
  <p slot="empty">무엇이든 물어보세요</p>
</agent-relay-engine-chat>
```

요소는 부모 높이를 채운다(`:host { height: 100% }`) — 부모에 높이를 준다.

클래스는 `AgentRelayEngineChat`, 태그 이름 상수는 `TAG` 다. 테마 변수는 `--ce-*`, 이벤트는 `ce-*` 다.

## 개념

### 설치와 빌드

소비자는 [설치 가이드](../../docs/consumers/packaging.md)대로 chat-ui·chat-client tarball 을 설치한다. 이 저장소 안에서는 dist 를 먼저 만든다.

```sh
npm run build -w @agent-relay-engine/chat-ui   # tsc -b 로 chat-client 까지 dist/ ESM 을 만든다 (루트 npm run typecheck 도 같다)
```

### 파트

밖에서 `agent-relay-engine-chat::part(<이름>)` 으로 꾸민다. 공통 이름 + 종류를 함께 붙인 것은 어느 쪽으로도 고를 수 있다(`::part(card)` 는 모든 카드, `::part(tool)` 은 도구 카드만).

| part | 요소 |
|---|---|
| `header` | 위 막대 전체(슬롯 `header`·배지·사용률·연결 상태를 담는다) |
| `capabilities` · `usage` · `connection` | 위 막대의 capability 배지 묶음 · 사용률 · 연결 상태(`data-state` 는 스토어의 `connection` 값. 서버가 연결을 거부하면 `denied` 이고 '연결 거부됨' 으로 멈춘다 — 다시 시도는 `reconnect()`, 1.7.0) |
| `sidebar` | 세션 목록 |
| `messages` | 메시지 목록(말풍선·카드를 담는 열, 폭 제한 대상) |
| `message user` · `message assistant` | 사람·모델 말풍선 |
| `card tool` · `card ask` · `card permission` | 도구·질문·승인 카드. 도구 카드는 `data-tool-name`(·`data-tool-server`)을 달아 CSS 로 고를 수 있다 |
| `tool-server` · `tool-count` | 도구 카드 summary 의 ` · <server>` · 묶은 카드의 `×N`(`group-tools`) (1.6.0) |
| `question` · `question-header` | ask 카드 안의 질문 한 칸(묶음이면 질문마다) · 그 질문의 짧은 꼬리표 |
| `note` | 알림 줄(거부·중지·오류 등). 다음 입력에서 밀려난 오류는 접힌 `details` 한 줄로 `data-superseded` 를 단다(1.2.0) |
| `author` | 남의 사람 말풍선 위의 이름 줄(`viewer` 를 줬을 때만, 1.7.0). 말풍선 안의 첫 자식이다 |
| `message-actions` | 실패한 사람 말풍선 아래 [다시 보내기]·[지우기] 줄(1.2.0) |
| `time` | 말풍선 아래 시각 줄(`show-time`). 시각이 없는 칸은 비어 숨는다 |
| `date-divider` | 날짜 구분선(`date-dividers`, `role="separator"`) |
| `new-messages` · `new-messages-count` | 위로 올려 읽는 동안 새 내용이 오면 스크롤 상자 위에 뜨는 "새 메시지" 버튼(`<button>`, 1.6.0) · 그 안의 개수 |
| `status` | 아래 상태줄 글. 상태 코드를 `data-code`(`idle`·`busy`·`queued`·`turn-error` 등 chat-client `Status['code']`, 1.6.0)로, 색 갈래를 `data-tone` 으로 단다 |
| `composer` · `input` · `send` · `inject` · `stop` | 입력 영역(폭 제한 대상) · 입력창 · 보내기 · 끼워 넣기 · 중지 버튼 |

헤더 전체를 숨기지 않고 배지만 숨기기 — 속성 하나면 된다(`::part(capabilities) { display: none }` 도 같다):

```html
<agent-relay-engine-chat endpoint="/api" hide-capabilities hide-usage>
  <strong slot="header">내 채팅</strong>
</agent-relay-engine-chat>
```

```css
agent-relay-engine-chat::part(connection) { font-size: 11px; }
agent-relay-engine-chat::part(message assistant) { border-color: transparent; }
```

상태줄의 `data-code`·`data-tone` 은 Shadow DOM 안의 속성이라 밖에서 `::part(status)[data-code="idle"]` 처럼 속성 선택자를 붙일 수 없다(`::part()` 뒤에는 속성 선택자가 오지 못한다). 대기일 때 숨기기는 `hide-idle-status` 속성으로 하고, `data-code` 는 테스트 셀렉터나 스크립트(`el.shadowRoot.getElementById('status').dataset.code`)에서 읽는다.

메시지 목록과 입력칸 폭을 880px 로 제한하고 가운데 두기(넓은 화면의 읽기 폭):

```css
agent-relay-engine-chat { --ce-content-max-width: 880px; }
```

서버 재시작(`hello.bootId` 변경)을 보면 `ce-restart` 를 낸 뒤 **페이지를 다시 받는다** — 옛 코드가 남아 새 이벤트를 못 그리는 것을 막는다. 기다리던 승인은 `sessionStorage` 표식으로 새 페이지가 resume 턴을 보내 다시 요청하게 한다.

### 보내기 중·실패·접힌 오류 (1.2.0)

| 표시 | 어떻게 그리나 |
|---|---|
| 사람 말풍선 `data-delivery="pending"` | 서버가 받았다는 확인 전(보내기 중·큐 대기). 흐리게(`--ce-pending-opacity`). 서버 항목이 오면 속성이 지워지고 같은 노드에서 평소대로 된다 |
| 사람 말풍선 `data-delivery="failed"` | 보내지 못함. `--ce-danger` 테두리와 아래 [다시 보내기]·[지우기] 줄. 이유는 상태줄 `보내기 실패` 로 본다 |
| `note[data-superseded]` | 다음 입력을 시작하며 접힌 오류. 한 줄로 접혀 있고, 펼치면 전문이 보인다. 다시 펼쳐지지 않는다 |

입력칸의 첫 `input` 에서 `beginInput()` 을 부른다. 상태가 오류면 `idle` 로 돌아가고 [이어서 하기]는 사라진다.

### ask 카드

질문 묶음(최대 4개)을 질문마다 한 칸(`part="question"`)으로 그린다. 선택 상태는 스토어(`item.selected`)가 쥐고 카드는 그것을 비춘다.

- **단일 선택**(기본): 칸은 `role="radiogroup"`, 선택지는 `role="radio"` — 하나만 켜진다. **복수 선택**(`multiSelect`): `role="group"`, 선택지는 `role="checkbox"` — 켜고 끈다. 상태는 `aria-checked`, 선택 훅은 `[data-selected="true|false"]` 다(Shadow DOM 안이라 테스트 셀렉터·내부 스타일용, 페이지에서 색을 바꾸려면 `--ce-accent`·`--ce-accent-fg`).
- 선택지 `description` 은 라벨 아래 작은 글(`aria-describedby`). 질문마다 기타 입력칸이 있다.
- 모든 질문에 답(선택 또는 기타)이 있어야 [답 보내기] 가 켜진다. 기타 입력칸에서 Enter 로 보낸다(한글 조합 중 Enter 는 제외).
- 키보드: Tab 은 질문마다 선택지 하나(고른 것, 없으면 첫째)에 멈춘다. 방향키로 같은 질문의 선택지를 돌고(단일 선택은 옮긴 곳을 고른다), Space 로 고르거나 켜고 끈다.

### 마크다운

모델 말풍선은 내장 렌더러(의존성 없음)로 그린다. 사람 말풍선은 친 그대로 원문이다.

- **범위**: 문단(한 줄 바꿈은 줄바꿈), 제목 `#`~`######`, `**굵게**`·`*기울임*`·`~~취소선~~`, `` `인라인 코드` ``, 코드펜스(` ``` `·`~~~`, 언어는 `class="language-<lang>"` 만 — 하이라이트 없음), 순서·비순서 목록(중첩 1단, 더 깊은 것은 1단으로 붙는다), GFM 표(`:--`·`:-:`·`--:` 정렬), 인용 `>`, 링크 `[글](url)`, 수평선. HTML 태그·이미지·각주·자동 링크는 범위 밖이라 글자로 보인다.
- **보안**: 모델 글을 `innerHTML` 로 넣지 않는다 — 파서가 토큰을 만들고 DOM 노드를 직접 만든다. 글은 항상 텍스트 노드라 `<img onerror>` 같은 입력은 글자로만 보인다. 링크는 `http:`·`https:`·`mailto:` 만 `<a target="_blank" rel="noopener noreferrer">` 가 되고, 나머지(`javascript:`, `data:`, 상대 경로)는 링크 글만 남는다.
- **스트리밍**: 조각이 올 때마다가 아니라 화면 프레임(`requestAnimationFrame`)당 한 번 다시 그리고, 확정된 글은 바로 그린다. 닫는 펜스가 아직 안 온 코드블록은 열린 코드블록(`pre[data-open]`, 아래 점선)으로 보인다. 짝이 안 맞은 `**` 등은 짝이 올 때까지 글자로 보인다. 스트리밍 중에는 말풍선 내용을 프레임마다 새로 만들므로 그 사이 링크 클릭·글 선택은 끊길 수 있다(확정 뒤에는 그대로). 목록이 바닥에 붙어 있으면 늦게 그려진 글을 따라 내려간다.
- **링크 끄기**: `render-markdown="no-links"` 는 AI 답에 섞인 피싱 링크를 막는다. 링크가 `a` 가 되지 않고 `글 (주소)` 글자로만 보인다. 글은 `<bdi>`, 주소는 `<bdi dir="ltr">` 로 가둬 방향 문자(RLO 등)로 주소가 뒤집혀 보이지 않게 한다. 모르는 값은 기본(켬)으로 그리고 `console.warn` 한다. 이미지·HTML·맨 URL 은 원래 글자라 그대로다. `.markdown` 교체 렌더러를 넣으면 그것이 우선이고(같이 쓰면 `console.warn` 한 번), no-links 는 적용되지 않는다.
- **교체**: `chat.markdown = (text) => myRenderer(text)` — 다른 라이브러리를 쓰고 싶으면 노드를 돌려준다. HTML 문자열을 돌려주는 라이브러리라면 소독(sanitize)은 소비자 몫이다.
- **스타일**: 표·코드·인용은 `--ce-code`·`--ce-line`·`--ce-muted`·`--ce-accent` 를 쓰므로 테마 변수·다크 모드를 그대로 따른다. 말풍선에 `md` 클래스가 붙는다.

### 이벤트

모두 `bubbles`·`composed` 라 문서에서 받을 수 있다.

| 이벤트 | detail | 언제 |
|---|---|---|
| `ce-permission` | `{sessionId, requestId, toolName, input}` | 새 승인 요청(어느 세션이든) — 알림·소리 등에 |
| `ce-ask` | `{sessionId, askId, question}` | 새 질문 |
| `ce-error` | `{sessionId, status, text}` | 상태줄이 오류로 바뀜(보내기·중지·승인 실패, 턴 오류). `text` 는 상태줄 글과 같다(턴 오류는 `.errorLabel` 앞머리를 따른다). 턴 오류 `status` 에 `why?`(1.8.9) |
| `ce-session` | `{sessionId}` | 세션을 열었다 |
| `ce-restart` | `{}` | 서버 재시작을 봤다 — 바로 뒤에 페이지를 다시 받는다 |
| `ce-store-change` | `{store}` | 안의 `ChatStore` 를 새로 만들었다(1.6.0) — 첫 연결, `reconnect()`, `endpoint` 변경 때 한 번씩. `detail.store` 는 그 순간의 `el.store` 다 |

```js
document.querySelector('agent-relay-engine-chat').addEventListener('ce-permission', (e) => {
  if (document.hidden) new Notification(`승인 요청: ${e.detail.toolName}`);
});
```

`ce-store-change` 는 스토어가 연결을 시작하기(`start()`) 전에 낸다. 리스너에서 `subscribe` 하면 새 스토어의 첫 상태 변화부터 받는다. 옛 스토어는 이미 정리돼 더 바뀌지 않지만, 구독 해제 함수는 리스너가 들고 있다가 부른다. 요소를 문서에서 떼면 스토어를 정리하고 `el.store` 가 `undefined` 가 되지만 이 이벤트는 내지 않는다(떼어진 요소의 이벤트는 문서 리스너에 닿지 않는다). 다시 붙이면 새 스토어로 한 번 낸다. 이벤트는 화면을 다 붙인 뒤에 내므로 리스너 안에서 `reconnect()` 하거나 요소를 떼도 요소 자체는 괜찮다 — 버려진 스토어는 시작하지 않고, 요소의 화면·입력은 마지막 스토어에 붙는다. 다만 리스너 안에서 `reconnect()` 하면 이벤트 순서가 뒤바뀔 수 있다: 새 스토어의 이벤트가 모든 리스너에 먼저 닿고, 그 뒤 버려진 스토어의 이벤트가 남은 리스너에 이어서 닿는다. 그래서 리스너는 `e.detail.store` 가 지금의 `el.store` 와 같을 때만 쓴다(아래 예시의 가드). 요소를 이벤트 리스너보다 먼저 붙였으면 첫 이벤트는 놓치니 `el.store` 를 먼저 읽는다.

```js
const el = document.querySelector('agent-relay-engine-chat');
let off;
const watch = (store) => {
  off?.();
  off = store?.subscribe((s) => console.log(s.status.code));
};
watch(el.store);
el.addEventListener('ce-store-change', (e) => {
  // 다른 리스너가 안에서 reconnect() 했으면 이미 버려진 스토어다 — 새 스토어 이벤트를 이미 받았다
  if (e.detail.store !== el.store) return;
  watch(e.detail.store);
});
```

## 공개 API

<!-- gen:api @agent-relay-engine/chat-ui . -->
`@agent-relay-engine/chat-ui` — 7개, 공개 API 스냅샷 1.8.10 기준.

| 종류 | 이름 |
|---|---|
| function | `outcomeText` · `statusText` · `usageText` |
| class | `AgentRelayEngineChat` |
| const | `TAG` · `THEME_VARS` |
| type | `ScrollFollow` |
<!-- /gen -->

## 설정

### 속성·프로퍼티

| 이름 | 뜻 |
|---|---|
| `endpoint` | 서버 API 앞부분(기본 `/api`). 계약은 [PROTOCOL.md](../chat-client/PROTOCOL.md). 붙은 뒤에 바꾸면 기존 SSE 구독과 스토어를 정리하고 **지금 세션 id 그대로** 새 접두어에 다시 구독한다(세션 목록·기록을 새로 읽는다). 프로젝트별 접두어(`/api/projects/<id>/chat`)처럼 서버가 바뀔 때 쓴다 |
| `session` | 열 세션 id. 바꾸면 같은 연결에서 그 세션으로 간다(`select`, 재구독 없음). 없으면 새 id. `endpoint` 와 함께 바꾸면 순서와 무관하게 새 접두어의 그 세션에 닿는다 |
| `sync-hash` | 주소의 `#s=<id>` 와 지금 세션을 맞춘다(새로고침·링크 공유) |
| `render-markdown` | 모델 말풍선의 마크다운 렌더(기본 켬). `"off"` 면 원문 그대로, `"no-links"` 면 서식은 살리고 링크 `[글](url)` 를 `a` 대신 `글 (주소)` 글자로 둔다(글과 주소가 같으면 하나만). 바꾸면 이미 그린 말풍선도 다시 그린다 |
| `hide-capabilities` | 위 막대의 capability 배지를 숨긴다(불리언 속성) |
| `hide-usage` | 위 막대의 사용률을 숨긴다(불리언 속성). 연결 표시는 오른쪽 끝으로 간다 |
| `hide-connection` | 위 막대의 연결 표시(`part="connection"`)를 숨긴다(불리언 속성, 1.6.0). `hide-usage` 와 함께 쓰면 둘 다 빠지고 배지는 제자리다 |
| `hide-idle-status` | 상태줄 글이 대기(`data-code="idle"`, 글 `대기`)일 때만 숨긴다(불리언 속성, 1.6.0). 응답 중·대기열·오류 같은 다른 상태는 그대로 보인다. 상태줄 칸은 글이 숨어도 한 줄 높이를 지켜 상태가 바뀔 때 화면이 뛰지 않는다. 실행 중에 켜고 꺼도 된다 |
| `.toolLabel` (프로퍼티, 1.2.0) | `(tool: {name, server?}) => string \| null \| undefined`. 도구 카드의 이름 자리에 쓸 글을 돌려준다. `undefined` 면 원래 이름, `null` 이면 그 카드를 숨긴다. 빈 문자열은 원래 이름으로 그린다. 던지면 원래 이름으로 그리고 `console.warn` 한다(함수마다 한 번만, 1.2.1). 결과는 (이름, 서버) 키로 캐시하고 함수를 바꾸면 캐시를 버린다(1.2.1). 바꾸면 이미 그린 카드도 다시 그린다(펼친 상태는 잇는다). 속성이 아니라 JS 프로퍼티다. Shadow DOM 이라 `::part` 로는 이름을 고칠 수 없으니 이 프로퍼티를 권장하고, CSS 는 `data-tool-name` 으로 고른다 |
| `.errorLabel` (프로퍼티, 1.5.0) | `(e: {reason, message, resumable?, why?}) => string \| null \| undefined`. 오류 칸·상태줄의 턴 오류·`ce-error` 의 `text` 에서 `오류 · <reason>` 자리에 쓸 앞머리를 돌려준다. 문자열이면 `<앞머리>: <메시지>`(접힌 이전 오류는 `이전 <앞머리>`, 상태줄은 `<앞머리> (이어서 할 수 있음): <메시지>`), `null` 이면 앞머리 없이 메시지만(접힌 이전 오류는 `이전 오류`, 상태줄의 `(이어서 할 수 있음)` 은 메시지 뒤로 간다), `undefined` 나 빈 문자열이면 지금 모양이다. 던지거나 문자열·`null`·`undefined` 가 아닌 값을 돌려주면 지금 모양으로 그리고 `console.warn` 한다(함수마다 한 번만). 바꾸면 이미 그린 오류 칸과 상태줄도 다시 그린다(펼친 이전 오류는 펼친 채로 둔다). 상태줄은 같은 오류를 보는 동안(같은 상태·같은 함수) 함수를 다시 부르지 않는다. 보내기·중지·승인 실패 같은 다른 상태줄 글은 바뀌지 않는다. 속성이 아니라 JS 프로퍼티다. `why`(1.8.9)는 엔진 error 의 `detail.why` 가 있을 때만 오는 짧은 사유 문자열이라, 같은 reason 안에서 문구를 가를 수 있다 — `el.errorLabel = (e) => (e.why === 'unlisted-tool' ? '허용되지 않은 도구' : undefined)`. 없으면 칸이 없다 |
| `.viewer` (프로퍼티, 1.7.0) | `{id: string} \| undefined`. 지금 보는 사람. 주면 사람 글의 보낸 사람(chat-client `ViewItem` 의 `author`·`authors`)을 표시한다 — 아래 "보낸 사람 표시". 안 주면(기본) author 가 있어도 지금 모양 그대로다. 바꾸면 이미 그린 사람 글도 다시 그린다. 속성이 아니라 JS 프로퍼티다 |
| `hide-tool-server` · `.hideToolServer` | 도구 카드 summary 끝의 ` · <server>` 를 그리지 않는다(불리언, 기본 꺼짐, 1.6.0). `data-tool-server` 는 그대로 단다. 바꾸면 이미 그린 카드도 다시 그린다(펼친 상태는 잇는다) |
| `group-tools` · `.groupTools` | 바로 이어진 같은 도구(`name`·`server` 가 같은) 호출을 카드 하나로 묶는다(불리언, 기본 꺼짐, 1.6.0). 아래 "도구 카드 묶기" |
| `scroll-follow` · `.scrollFollow` | 새 항목이 생기거나 목록이 자랄 때 바닥으로 따라갈지(1.6.0). `'near-bottom'`(기본): 바닥 범위 안일 때만 따라가고, 위로 올려 읽는 중이면 위치를 그대로 두고 "새 메시지" 버튼을 띄운다. `'always'`: 늘 바닥으로(1.5.0 까지의 동작). `'never'`: 자동으로 내리지 않고, 바닥 범위 밖이 되면 버튼을 띄운다. 모르는 값은 `console.warn` 후 기본으로 읽는다. 타입은 `ScrollFollow` |
| `scroll-threshold` · `.scrollThreshold` | 바닥 범위(px, 기본 `32`, 1.6.0). 바닥까지 남은 거리(`scrollHeight - scrollTop - clientHeight`)가 이 값 이하면 바닥 범위다. 숫자가 아니거나 0 보다 작으면 기본 |
| `new-message-button` · `.newMessageButton` | "새 메시지" 버튼을 띄울지(기본 보임, 1.6.0). 속성은 `"off"` 면 숨김, 프로퍼티는 boolean. 끄면 떠 있던 버튼도 바로 숨는다 |
| `new-message-label` · `.newMessageLabel` | 버튼 문구(기본 `새 메시지`, 빈 문자열이면 기본, 1.6.0) |
| `send-label` · `inject-label` · `stop-label` | 보내기·끼워 넣기·중지 버튼의 글(기본 `보내기`·`끼워 넣기`·`■ 중지`, 1.8.0). 빈 값이거나 공백뿐이면 기본이다. 실행 중에 바꾸면 바로 반영된다. 버튼의 접근 가능한 이름은 이 글을 따라간다 |
| `send-title` · `inject-title` · `stop-title` | 세 버튼의 툴팁(`title`, 1.8.0). 기본은 `inject-title` 만 `진행 중인 턴에 끼워 넣기` 이고 나머지는 툴팁이 없다. 빈 값·공백뿐이면 기본으로 돌아간다. 툴팁은 접근 가능한 이름을 바꾸지 않는다 |
| `show-time` · `.showTime` | 사람·모델 말풍선 아래에 시각(`ViewItem.at`)을 적는다(불리언, 기본 꺼짐, 1.1.0). 오늘이면 시:분, 다른 날이면 월·일, 다른 해면 연도까지 붙인다. 형식은 가장 가까운 `lang`(없으면 브라우저 기본)으로 `Intl.DateTimeFormat` 이 정한다. 스트리밍 중인 말풍선은 확정될 때 시각이 붙는다 |
| `date-dividers` · `.dateDividers` | 첫 날짜와 날짜가 바뀌는 곳에 날짜 구분선을 넣는다(불리언, 기본 꺼짐, 1.1.0). 시각이 없는 칸은 앞 칸의 날짜를 따른다 |
| `.transport` (프로퍼티) | 붙이기 전에 넣으면 `endpoint` 대신 이 `Transport` 를 쓴다(그때는 `endpoint` 변경을 무시한다). 붙은 뒤 바꿨으면 `reconnect()` 를 부른다 |
| `.reconnect()` (메서드) | 지금 연결을 정리하고 같은 세션으로 다시 붙는다. 붙기 전이면 아무것도 하지 않는다. 화면의 말풍선은 새 기록으로 다시 그린다. 응답을 기다리던 보내기·승인 요청은 결과를 받지 못한다(서버에는 이미 갔을 수 있다) |
| `.store` (프로퍼티, 읽기) | 안의 `ChatStore` — 헤드리스 액션을 직접 부를 때. 붙기 전과 분리된 뒤에는 `undefined` 다. 재연결·`endpoint` 변경 때 새 스토어로 바뀌므로 구독은 `ce-store-change` 에서 다시 건다 |
| `.markdown` (프로퍼티) | `(text: string) => Node`. 넣으면 내장 렌더러 대신 이것으로 모델 말풍선을 그린다(`render-markdown="off"` 가 우선). 던지면 원문으로 보인다 |

슬롯: `header`(위 막대 왼쪽, 기본 "채팅"), `empty`(대화가 비었을 때). `empty` 에 넣은 버튼·링크는 누를 수 있다(1.6.0) — 빈 상태 상자 자체는 클릭을 아래로 통과시키고 슬롯에 넣은 요소(와 그 안)만 클릭을 받는다. 슬롯 요소가 넓으면(`width: 100%` 상자 등) 그 넓이만큼 아래 메시지 영역의 클릭·휠을 가리니 누를 것만 넣거나 감싼 상자에 `pointer-events: none` 을 주고 버튼에만 `auto` 를 준다.

스크롤 속성은 실행 중에 바꿔도 되고 다음 변화부터 따른다. 속성과 프로퍼티는 서로 비친다(프로퍼티에 넣으면 속성이 바뀐다).

### 보낸 사람 표시 (1.7.0)

서버가 사람 글에 보낸 사람(`author`)을 실어 주는 서비스(chat-server 의 `identify`)에서, `el.viewer = {id}` 를 주면 누구의 글인지 보인다.

- 보낸 사람이 viewer 와 같으면 말풍선에 `data-mine` 을 단다(이름 줄은 없다).
- 다르면 말풍선 안 맨 위에 이름 줄 `<div part="author">이름</div>` 을 단다. 이름이 없으면 id 다. 합쳐진 입력(`authors` 여럿)은 이름을 `·` 로 잇는다(`Alice·Bob`). 합쳐진 입력은 보낸 사람이 **모두** viewer 일 때만 `data-mine` 이다.
- 보내는 중·실패한 임시 말풍선은 보낸 사람을 모르므로 viewer 의 글로 보고 `data-mine` 을 단다. 서버 항목으로 확정되면 서버의 author 로 바뀐다.
- author 가 없는 서버 글에는 아무것도 달지 않는다. 그래서 `identify` 가 없는 서버에서는 확정 뒤 `data-mine` 이 없다 — `viewer` 만으로는 내 글을 알 수 없다. 이름 줄이 있는 끼워 넣은 글은 "이름 · 끼워 넣음" 으로 한 줄에 보인다. 빈 `name` 은 id 로 보인다.
- `viewer` 를 주지 않으면 DOM 이 지금과 같다.

```css
agent-relay-engine-chat::part(author) { font-weight: 600; }
```

`data-mine` 은 Shadow DOM 안의 속성이라 `::part()` 뒤에 속성 선택자를 붙일 수 없다. 테스트 셀렉터와 스크립트(`el.shadowRoot.querySelector('[data-mine]')`)에서 읽는 용도이고, 밖에서 이름 줄은 `::part(author)` 로 꾸민다.

### 도구 카드 묶기 (1.6.0)

`group-tools` 를 켜면 목록에서 바로 이어진 tool 항목 중 `name` 과 `server` 가 같은 것들을 카드 하나로 그린다.

- 다른 칸(말풍선·다른 도구·알림 줄·질문·승인 카드)이나 날짜 구분선이 사이에 끼면 묶음이 끊긴다. `toolLabel` 이 `null` 을 돌려 숨긴 카드는 그리지 않으므로 묶음을 끊지 않는다.
- summary 는 `🔧 <이름> ×N`(N≥2 일 때만, `×N` 은 `part="tool-count"`)이고 그 뒤에 ` · <server>`(`hide-tool-server` 면 없음)가 온다. 이름은 `toolLabel` 을 따른다. N=1 이면 묶지 않은 카드와 DOM 이 같다.
- 하나라도 실행 중이면 카드가 실행 중(`pending`)이고, 오류가 있으면 ` · 오류`(둘 이상이면 ` · 오류 k`)와 error 표시를 단다. 승인 배지는 모든 호출의 표시가 같을 때만 summary 에 하나 달고, 다르면 펼친 안쪽 호출마다 보인다.
- 펼치면 호출마다 순서대로 `#i` 소제목과 `인자`·`결과` 를 보인다(실행 중인 호출은 인자·결과 없이). 새 호출이 끝에 붙거나 호출이 끝나면 같은 카드를 고쳐 쓴다 — 펼친 상태가 남는다.
- 데이터 속성: `data-tool-id` 는 첫 호출, `data-tool-ids` 는 묶인 호출 id 들(공백 구분), `data-tool-count="N"`. N=1 이면 뒤의 둘은 없다. 펼친 안쪽 호출 블록은 `data-call-id` 를 단다(`[data-tool-id]` 는 카드만 고른다).
- "새 메시지" 버튼 개수는 원래 도구 카드를 세지 않으므로 묶어도 같다.
- 위로 올려 읽는 동안 묶음에 호출이 붙어 카드가 자라면 "새 메시지" 버튼은 개수 없이 뜬다 — 내용이 자란 것과 같아 개수는 늘지 않는다.

```css
agent-relay-engine-chat::part(tool-server) { display: none; }   /* hide-tool-server 와 같은 모양 */
agent-relay-engine-chat::part(tool-count) { font-weight: 600; }
```

### 스크롤 따라가기 (1.6.0)

- **바닥 범위**: 바닥까지 남은 거리가 `scroll-threshold` 이하. 사람이 스크롤해 바닥 범위에 들어오면 다시 붙고(버튼이 숨고 개수가 0 이 된다), 위로 굴리면(휠·키·터치·스크롤바 모두) 바닥 범위 안이어도 떨어진다.
- **강제로 바닥에 붙는 경우**(모든 모드): 처음 불러오기(첫 기록 반영), 세션 전환, 이 화면에서 보낸 사람 글이 목록에 새로 생김(컴포저 보내기·끼워 넣기, 밖에서 `store.send` 를 불러도 같다). 서버가 확정한 내 메시지(같은 `clientMessageId`)는 새로 생긴 것으로 보지 않는다. 다른 탭·기기에서 보낸 사람 글은 보통 새 항목처럼 따라가거나 버튼 개수에 든다.
- **재연결**: 같은 세션의 기록을 다시 읽으면(빈틈을 채우지 못한 재연결) 바닥으로 끌어내리지 않고 읽던 자리(바닥에서의 거리)로 돌아간다. 끊긴 사이 온 항목은 버튼 개수로 알린다. `always` 모드는 바닥으로 간다.
- 키보드로 버튼을 누르면 숨는 버튼 대신 입력칸에 포커스를 둔다(탭·클릭은 모바일 가상 키보드가 뜨지 않게 옮기지 않는다).
- 뷰포트 위 내용이 줄어 브라우저가 scrollTop 을 함께 줄인 것(scroll anchoring)은 위로 굴린 것으로 보지 않는다.
- **"새 메시지" 버튼**: `part="new-messages"` 인 `<button type="button">`. 문구는 `<label> ↓` 이고, 떨어져 있는 동안 새로 생긴 사람·모델 말풍선이 있으면 개수를 함께 적는다(`새 메시지 3 ↓`, 개수는 `part="new-messages-count"`). 도구 카드·구분선·알림 줄은 버튼만 띄우고 개수에 넣지 않는다. 스트리밍으로 자라기만 하면 개수 없이 문구만 보인다. `aria-label` 은 개수를 포함한 문구이고, 숨길 때는 `hidden` 이다. 누르면 바닥으로 가서 다시 붙는다.

```css
agent-relay-engine-chat { --ce-new-messages-bottom: 20px; --ce-scroll-behavior: smooth; }
agent-relay-engine-chat::part(new-messages) { font-weight: 600; }
```

### 테마 변수

밖에서 `agent-relay-engine-chat { --ce-accent: hotpink; }` 처럼 준다. 주면 밝은·어두운 테마 모두 그 값을 쓴다(따로 주려면 페이지에서 `prefers-color-scheme` 로 나눠 준다). 안 주면 `prefers-color-scheme` 을 따른다.

| 변수 | 밝음 / 어두움 | 쓰임 |
|---|---|---|
| `--ce-bg` | `#f7f7f8` / `#15161a` | 바탕, 입력칸 |
| `--ce-panel` | `#ffffff` / `#1d1f24` | 위 막대·카드·입력 영역 |
| `--ce-fg` | `#1d1d1f` / `#e8e8ec` | 글자 |
| `--ce-muted` | `#6b6b75` / `#9a9aa6` | 보조 글자 |
| `--ce-line` | `#e2e2e6` / `#2e3038` | 테두리 |
| `--ce-accent` · `--ce-accent-fg` | `#3b5bdb`·`#fff` / `#7c93ff`·`#0e1020` | 주 버튼, ask 카드, 고른 선택지 |
| `--ce-user` · `--ce-bot` | `#e7ecff`·`#fff` / `#26304f`·`#1d1f24` | 사람·모델 말풍선 |
| `--ce-danger` · `--ce-ok` · `--ce-warn` | `#c92a2a`·`#2b8a3e`·`#b7791f` / `#ff6b6b`·`#69db7c`·`#ffd43b` | 오류·거부 / 연결됨·켜진 배지 / 바쁨·승인 카드 |
| `--ce-code` | `#f1f1f4` / `#24262d` | 도구 인자·명령 |
| `--ce-font` | `15px/1.5 system-ui, …` | 글꼴(`font` 단축 값) |
| `--ce-radius` | `8px` | 모서리 |
| `--ce-content-max-width` | `none` | 메시지 목록·입력칸 최대 폭(가운데 정렬). 길이 값(`880px`·`60rem`)을 준다 |
| `--ce-time` | `--ce-muted` 값 | 말풍선 아래 시각 글자(`show-time`, 1.1.0) |
| `--ce-pending-opacity` | `0.6` | 보내기 중인 사람 말풍선의 투명도(1.2.0) |
| `--ce-new-messages-bg` · `--ce-new-messages-fg` | `--ce-accent` · `--ce-accent-fg` 값 | "새 메시지" 버튼 바탕·글자(1.6.0) |
| `--ce-new-messages-bottom` | `12px` | "새 메시지" 버튼과 스크롤 상자 아래 끝 사이(1.6.0) |
| `--ce-scroll-behavior` | `auto` | 스크롤 상자의 `scroll-behavior`. `smooth` 면 따라가기·버튼 클릭이 부드럽게 굴러간다(1.6.0) |

## 다른 문서

- [chat-client](../chat-client/README.md) — 헤드리스 스토어 · [PROTOCOL.md](../chat-client/PROTOCOL.md) — 서버 계약
